//! Phantom Protocol node daemon — Phase 2.
//!
//! Commands:
//!   phantom node       — start full mix node with circuit building and hidden service
//!   phantom client     — start as client node
//!   phantom keygen     — generate and display a node identity
//!   phantom status     — show runtime status
//!   phantom hs-create  — create a new hidden service and print its .phantom address

use anyhow::Result;
use std::sync::Arc;
use tracing::{info, warn, error};
use phantom_core::crypto::HybridKeypair;
use phantom_core::mix::MixNode;
use phantom_core::cover::CoverEngine;
use phantom_core::circuit::{CircuitBuilder, CircuitPool, CircuitPath, CircuitHop, HopRole, CircuitId};
use phantom_core::hidden_service::{HiddenServiceManager, PhantomAddress};
use phantom_core::reputation::ReputationStore;
use phantom_dpki::identity::NodeIdentity;
use phantom_dpki::dht::PhantomKademlia;
use phantom_dpki::epoch::EpochManager;
use phantom_dpki::bootstrap;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("phantom=info".parse()?)
        )
        .init();

    let args: Vec<String> = std::env::args().collect();
    let cmd = args.get(1).map(|s| s.as_str()).unwrap_or("help");

    match cmd {
        "node"      => run_node().await,
        "client"    => run_client().await,
        "keygen"    => run_keygen(),
        "status"    => run_status(),
        "hs-create" => run_hs_create(),
        _           => { print_help(); Ok(()) }
    }
}

async fn run_node() -> Result<()> {
    info!("═══════════════════════════════════════════");
    info!(" Phantom Protocol — Mix Node");
    info!(" Version: {}", env!("CARGO_PKG_VERSION"));
    info!("═══════════════════════════════════════════");

    // ── Identity ──────────────────────────────────────────────────────────
    info!("Generating node identity (static PoW puzzle, ~50ms)...");
    let identity = NodeIdentity::generate()
        .map_err(|e| anyhow::anyhow!("Identity generation failed: {}", e))?;
    info!("node_id:  {}", identity.keypair.node_id);

    let keypair_arc = Arc::new(HybridKeypair::generate());

    // ── Bootstrap ─────────────────────────────────────────────────────────
    info!("Bootstrapping DHT...");
    let bootstrap_result = bootstrap::bootstrap().await;
    info!("Bootstrap: {} peers found", bootstrap_result.descriptors.len());

    let mut dht = PhantomKademlia::new(identity.keypair.node_id);
    for desc in &bootstrap_result.descriptors {
        dht.try_add_peer(desc);
    }

    // ── Mix node ──────────────────────────────────────────────────────────
    let mix_kp   = HybridKeypair::generate();
    let mut mix  = MixNode::new(mix_kp);

    // ── Cover traffic ─────────────────────────────────────────────────────
    let (cover_tx, mut cover_rx) = tokio::sync::mpsc::channel(512);
    let cover = CoverEngine::new(identity.keypair.node_id, cover_tx);
    let _cover_handle = cover.spawn();

    // ── Circuit pool ──────────────────────────────────────────────────────
    let mut circuit_pool = CircuitPool::new(Arc::clone(&keypair_arc));
    let circuit_builder  = CircuitBuilder::new(Arc::clone(&keypair_arc));

    // ── Hidden service ────────────────────────────────────────────────────
    let hs_mgr = HiddenServiceManager::new(Arc::clone(&keypair_arc));
    info!("Hidden service: {}", hs_mgr.address);

    // ── Reputation ────────────────────────────────────────────────────────
    let mut reputation = ReputationStore::new();

    // ── Epoch manager ─────────────────────────────────────────────────────
    let mut epoch_mgr = EpochManager::new();

    info!("Node online. Press Ctrl+C to stop.");
    info!("Circuits: {} | Cover: active | Mode: Standard+Extreme",
          circuit_pool.circuit_count());

    // ── Main event loop ───────────────────────────────────────────────────
    let mut batch_timer = tokio::time::interval(
        tokio::time::Duration::from_millis(phantom_core::BATCH_WINDOW_MS)
    );
    let mut epoch_timer = tokio::time::interval(
        tokio::time::Duration::from_secs(10)
    );
    let mut status_timer = tokio::time::interval(
        tokio::time::Duration::from_secs(60)
    );

    loop {
        tokio::select! {
            // Cover traffic → mix input
            Some(pkt) = cover_rx.recv() => {
                let full = mix.ingest(pkt);
                if full {
                    process_batch(&mut mix, &mut reputation).await;
                }
            }

            // Batch window tick
            _ = batch_timer.tick() => {
                if mix.window_elapsed() {
                    process_batch(&mut mix, &mut reputation).await;
                }
            }

            // Epoch tick
            _ = epoch_timer.tick() => {
                if epoch_mgr.tick() {
                    info!("Epoch boundary. C2 difficulty={}", epoch_mgr.c2_bits);
                }
                dht.purge_expired();
            }

            // Status report
            _ = status_timer.tick() => {
                info!(
                    "Status: circuits={} reputation_nodes={} eligible_guards={}",
                    circuit_pool.circuit_count(),
                    reputation.total_nodes(),
                    reputation.eligible_guards(),
                );
            }

            // Ctrl+C
            _ = tokio::signal::ctrl_c() => {
                info!("Shutting down gracefully...");
                break;
            }
        }
    }

    info!("Node stopped.");
    Ok(())
}

async fn process_batch(mix: &mut MixNode, reputation: &mut ReputationStore) {
    match mix.process_batch() {
        Ok(output) => {
            info!(
                "Batch: {} pkts | epoch={} | proof_ok=true",
                output.packets.len(), output.epoch
            );
            // In production: publish C_in, C_out, proof to DHT
            // Update reputations for nodes involved in this batch
        }
        Err(e) => error!("Batch error: {}", e),
    }
}

async fn run_client() -> Result<()> {
    info!("Phantom Protocol — Client Node");

    let identity = NodeIdentity::generate()
        .map_err(|e| anyhow::anyhow!("{}", e))?;
    info!("node_id: {}", identity.keypair.node_id);

    let bootstrap_result = bootstrap::bootstrap().await;
    info!("Connected to {} bootstrap peers", bootstrap_result.descriptors.len());
    info!("Client ready. Standard Mode and Extreme Mode available.");

    tokio::signal::ctrl_c().await?;
    info!("Client stopped.");
    Ok(())
}

fn run_keygen() -> Result<()> {
    println!("Phantom Protocol — Key Generation");
    println!();
    let kp = HybridKeypair::generate();
    println!("node_id:    {}", kp.node_id);
    println!("pk_ed25519: {}", hex::encode(kp.ed25519_public().as_bytes()));
    println!("pk_x25519:  {}", hex::encode(kp.x25519_public().as_bytes()));
    println!("epoch:      {}", phantom_core::crypto::current_epoch());
    println!();
    println!("WARNING: Private keys are not saved. Run 'phantom node' to start.");
    Ok(())
}

fn run_hs_create() -> Result<()> {
    println!("Phantom Protocol — Hidden Service Creation");
    println!();
    let kp  = Arc::new(HybridKeypair::generate());
    let mgr = HiddenServiceManager::new(Arc::clone(&kp));
    println!("address:   {}", mgr.address);
    println!("node_id:   {}", kp.node_id);
    println!();
    println!("Share your .phantom address with clients.");
    println!("Run 'phantom node' to start the hidden service.");
    Ok(())
}

fn run_status() -> Result<()> {
    println!("Phantom Protocol v{}", env!("CARGO_PKG_VERSION"));
    println!("epoch:  {}", phantom_core::crypto::current_epoch());
    println!("status: not connected (run 'phantom node' to start)");
    Ok(())
}

fn print_help() {
    println!("Phantom Protocol — Anonymous Communication Network");
    println!();
    println!("USAGE:  phantom <command>");
    println!();
    println!("COMMANDS:");
    println!("  node       Start a full mix node (circuit building, hidden service)");
    println!("  client     Start as client-only node");
    println!("  keygen     Generate and display a node identity");
    println!("  hs-create  Create a new .phantom hidden service address");
    println!("  status     Show current epoch and connection status");
    println!();
    println!("ENVIRONMENT:");
    println!("  RUST_LOG=phantom=debug   Enable debug logging");
    println!("  RUST_LOG=phantom=trace   Enable trace logging (very verbose)");
}
