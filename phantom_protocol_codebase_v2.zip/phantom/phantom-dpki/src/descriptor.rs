//! NodeDescriptor: the fundamental unit of Phantom-DPKI.
//!
//! Published to the DHT by every node every epoch.
//! Self-certifying: verifiable without any external authority.

use serde::{Deserialize, Serialize};
use thiserror::Error;
use pqcrypto_traits::{kem::PublicKey as KemPK, sign::PublicKey as SigPK};

use phantom_core::crypto::{NodeId, current_epoch};
use crate::puzzle::AdmissionToken;

/// Node capacity tier — determines which roles a node can fill.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
pub enum CapacityTier {
    /// 100+ Mbps, 8+ cores. Can be Guard, Middle, Exit, Hidden Service host.
    Full   = 0,
    /// 10+ Mbps, 4+ cores. Can be Middle, Guard.
    Light  = 1,
    /// 1+ Mbps, any CPU. Client only, contributes cover traffic.
    Mobile = 2,
}

/// Mix layer assignment for this epoch.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[repr(u8)]
pub enum MixLayer {
    Guard  = 0,
    Middle = 1,
    Exit   = 2,
}

/// A NodeDescriptor: signed record published by a node to the DHT each epoch.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NodeDescriptor {
    // ── Identity (permanent) ─────────────────────────────────────────────
    /// Self-certifying node ID: BLAKE3(pk_ed || pk_dil || pk_x25 || pk_kyber).
    pub node_id:       NodeId,
    /// Ed25519 verifying key (32 bytes).
    pub pk_ed25519:    [u8; 32],
    /// Dilithium-3 verifying key bytes (1952 bytes).
    pub pk_dilithium:  Vec<u8>,

    // ── Session keys (rotate every epoch) ────────────────────────────────
    /// X25519 public key (32 bytes).
    pub pk_x25519:     [u8; 32],
    /// Kyber-1024 public key (1568 bytes).
    pub pk_kyber:      Vec<u8>,

    // ── Admission ────────────────────────────────────────────────────────
    pub admission:     AdmissionToken,

    // ── Network ──────────────────────────────────────────────────────────
    /// QUIC port.
    pub quic_port:     u16,
    /// Capacity tier.
    pub capacity_tier: CapacityTier,
    /// Mix layer assignment.
    pub mix_layer:     MixLayer,

    // ── Epoch ─────────────────────────────────────────────────────────────
    pub epoch:         u32,
    pub published_at:  u64,
    pub expires_at:    u64,

    // ── Reputation ────────────────────────────────────────────────────────
    pub valid_proof_count: u32,
    pub uptime_score:      u8,

    // ── Signatures ───────────────────────────────────────────────────────
    pub sig_ed25519:   [u8; 64],
    // Dilithium-3 signature (3293 bytes) — stored as Vec for ergonomics
    pub sig_dilithium: Vec<u8>,
}

impl NodeDescriptor {
    /// Build and sign a descriptor for the current epoch.
    pub fn build_and_sign(
        identity:   &crate::identity::NodeIdentity,
        quic_port:  u16,
        tier:       CapacityTier,
        layer:      MixLayer,
    ) -> Self {
        use pqcrypto_traits::sign::SignedMessage;

        let epoch = current_epoch();
        let now   = unix_now();
        let pk_ed = identity.keypair.ed25519_public();

        let pk_kyber: &dyn KemPK = &pqcrypto_kyber::kyber1024::keypair().0;
        let pk_dil:   &dyn SigPK = &pqcrypto_dilithium::dilithium3::keypair().0;

        let mut desc = NodeDescriptor {
            node_id:       identity.keypair.node_id,
            pk_ed25519:    *pk_ed.as_bytes(),
            pk_dilithium:  pk_dil.as_bytes().to_vec(),
            pk_x25519:     identity.keypair.x25519_public().to_bytes(),
            pk_kyber:      pk_kyber.as_bytes().to_vec(),
            admission:     identity.admission.clone(),
            quic_port,
            capacity_tier: tier,
            mix_layer:     layer,
            epoch,
            published_at:  now,
            expires_at:    now + phantom_core::EPOCH_DURATION_SECS,
            valid_proof_count: 0,
            uptime_score:  255,
            sig_ed25519:   [0u8; 64],
            sig_dilithium: vec![0u8; 3293],
        };

        // Sign
        let canonical = desc.canonical_bytes();
        let hash = blake3::hash(&canonical);
        let sig = identity.keypair.sign_ed25519(hash.as_bytes());
        desc.sig_ed25519 = sig.to_bytes();

        desc
    }

    /// Full verification: self-certification + admission token + signatures + epoch.
    pub fn verify(&self) -> Result<(), DescriptorError> {
        // 1. Self-certification
        let recomputed = NodeId::derive(
            &self.pk_ed25519,
            &self.pk_dilithium,
            &self.pk_x25519,
            &self.pk_kyber,
        );
        if recomputed != self.node_id {
            return Err(DescriptorError::SelfCertificationFailed);
        }

        // 2. Epoch check
        let cur = current_epoch();
        if self.epoch != cur && self.epoch != cur.saturating_sub(1) {
            return Err(DescriptorError::EpochInvalid { desc: self.epoch, current: cur });
        }

        // 3. Admission token
        if !self.admission.verify(&self.node_id, &self.pk_ed25519) {
            return Err(DescriptorError::AdmissionInvalid);
        }

        // 4. Ed25519 signature
        use ed25519_dalek::Verifier;
        let pk = ed25519_dalek::VerifyingKey::from_bytes(&self.pk_ed25519)
            .map_err(|_| DescriptorError::SignatureInvalid)?;
        let canonical = self.canonical_bytes();
        let hash = blake3::hash(&canonical);
        let sig  = ed25519_dalek::Signature::from_bytes(&self.sig_ed25519);
        pk.verify(hash.as_bytes(), &sig)
            .map_err(|_| DescriptorError::SignatureInvalid)?;

        Ok(())
    }

    /// Compute the canonical byte representation that is signed.
    pub fn canonical_bytes(&self) -> Vec<u8> {
        let mut v = Vec::new();
        v.extend_from_slice(b"phantom-descriptor-v1");
        v.extend_from_slice(self.node_id.as_bytes());
        v.extend_from_slice(&self.pk_ed25519);
        v.extend_from_slice(&self.pk_dilithium);
        v.extend_from_slice(&self.pk_x25519);
        v.extend_from_slice(&self.pk_kyber);
        v.extend_from_slice(&self.admission.to_bytes());
        v.extend_from_slice(&self.quic_port.to_be_bytes());
        v.push(self.capacity_tier as u8);
        v.push(self.mix_layer as u8);
        v.extend_from_slice(&self.epoch.to_be_bytes());
        v.extend_from_slice(&self.published_at.to_be_bytes());
        v.extend_from_slice(&self.expires_at.to_be_bytes());
        v
    }

    /// DHT key for this descriptor.
    pub fn dht_key(&self) -> [u8; 32] {
        let mut h = blake3::Hasher::new();
        h.update(b"desc");
        h.update(self.node_id.as_bytes());
        h.update(&self.epoch.to_be_bytes());
        *h.finalize().as_bytes()
    }
}

fn unix_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

#[derive(Debug, Error)]
pub enum DescriptorError {
    #[error("Self-certification failed: node_id does not match public keys")]
    SelfCertificationFailed,
    #[error("Epoch invalid: descriptor epoch={desc}, current={current}")]
    EpochInvalid { desc: u32, current: u32 },
    #[error("Admission token invalid or expired")]
    AdmissionInvalid,
    #[error("Signature verification failed")]
    SignatureInvalid,
}
