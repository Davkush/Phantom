//! Seed-free network bootstrap (Spec № 3, §11).
//!
//! Three independent layers:
//! 1. mDNS — local network discovery (zero external dependency)
//! 2. DNS TXT records — self-verifying node_ids, no IP trust
//! 3. Genesis CID — IPFS-pinned, content-addressed, hardcoded hash

use thiserror::Error;
use tracing::{info, warn};

use phantom_core::crypto::NodeId;
use crate::descriptor::NodeDescriptor;

/// Hardcoded genesis content hash (BLAKE3 of genesis descriptor set).
/// This is a content hash, not a trusted server. It is immutable and verifiable.
pub const GENESIS_BLAKE3: &str =
    "0000000000000000000000000000000000000000000000000000000000000000"; // placeholder

/// Known bootstrap DNS domains (operated by different independent contributors).
pub const BOOTSTRAP_DOMAINS: &[&str] = &[
    "_phantom-bootstrap.example.net",
    "_phantom-bootstrap.example.org",
    // Production: 20+ independent domains
];

/// Bootstrap result: a list of verified NodeDescriptors to seed the routing table.
pub struct BootstrapResult {
    pub descriptors: Vec<NodeDescriptor>,
    pub sources:     Vec<BootstrapSource>,
}

#[derive(Debug, Clone)]
pub enum BootstrapSource {
    Mdns,
    Dns(String),
    Genesis,
    Manual(std::net::SocketAddr),
}

/// Attempt all three bootstrap layers simultaneously.
/// Returns whatever is found — caller must handle empty result.
pub async fn bootstrap() -> BootstrapResult {
    info!("Starting Phantom bootstrap (mDNS + DNS + genesis)...");

    let mut descriptors = Vec::new();
    let mut sources     = Vec::new();

    // Layer 1: mDNS (local network)
    match mdns_discover().await {
        Ok(mut descs) => {
            info!("mDNS: found {} peers", descs.len());
            sources.extend(descs.iter().map(|_| BootstrapSource::Mdns));
            descriptors.append(&mut descs);
        }
        Err(e) => warn!("mDNS bootstrap failed: {}", e),
    }

    // Layer 2: DNS
    for domain in BOOTSTRAP_DOMAINS {
        match dns_bootstrap(domain).await {
            Ok(mut descs) => {
                info!("DNS({}): found {} peers", domain, descs.len());
                let src = BootstrapSource::Dns(domain.to_string());
                sources.extend(descs.iter().map(|_| src.clone()));
                descriptors.append(&mut descs);
            }
            Err(e) => warn!("DNS bootstrap from {} failed: {}", domain, e),
        }
    }

    // Layer 3: Genesis CID
    match genesis_bootstrap().await {
        Ok(mut descs) => {
            info!("Genesis: found {} peers", descs.len());
            sources.extend(descs.iter().map(|_| BootstrapSource::Genesis));
            descriptors.append(&mut descs);
        }
        Err(e) => warn!("Genesis bootstrap failed: {}", e),
    }

    // Verify all descriptors — discard invalid ones
    let before = descriptors.len();
    descriptors.retain(|d| d.verify().is_ok());
    let after = descriptors.len();
    if before != after {
        warn!("Discarded {} invalid bootstrap descriptors", before - after);
    }

    if descriptors.is_empty() {
        warn!("All bootstrap layers failed. Use --peer <addr> to bootstrap manually.");
    } else {
        info!("Bootstrap complete: {} valid peers found", descriptors.len());
    }

    BootstrapResult { descriptors, sources }
}

async fn mdns_discover() -> Result<Vec<NodeDescriptor>, BootstrapError> {
    // Production: use libp2p mdns::Behaviour to discover _phantom._quic.local
    // Stub: return empty
    Ok(vec![])
}

async fn dns_bootstrap(domain: &str) -> Result<Vec<NodeDescriptor>, BootstrapError> {
    // Production: use hickory-resolver to fetch TXT records
    // Parse: v=phantom1 nid=<hex_node_id> epoch=<epoch>
    // Verify: node_id self-certification (no IP trust needed)
    // Stub: return empty
    Ok(vec![])
}

async fn genesis_bootstrap() -> Result<Vec<NodeDescriptor>, BootstrapError> {
    // Production: fetch from IPFS via iroh, verify BLAKE3(content) == GENESIS_BLAKE3
    // Stub: return empty
    Ok(vec![])
}

#[derive(Debug, Error)]
pub enum BootstrapError {
    #[error("mDNS discovery failed")]
    MdnsFailed,
    #[error("DNS lookup failed for {domain}: {reason}")]
    DnsFailed { domain: String, reason: String },
    #[error("Genesis CID fetch failed")]
    GenesisFailed,
    #[error("Content hash mismatch")]
    ContentHashMismatch,
}
