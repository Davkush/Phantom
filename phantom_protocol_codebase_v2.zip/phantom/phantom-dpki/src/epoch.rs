//! Epoch timing and key rotation management.

use tracing::info;
use phantom_core::crypto::current_epoch;

/// Epoch manager handles timing, key refresh scheduling, and republication.
pub struct EpochManager {
    last_seen_epoch: u32,
    /// Current dynamic puzzle difficulty.
    pub c2_bits: u32,
    /// Observed admissions this epoch (for difficulty adjustment).
    admission_count: u32,
}

impl EpochManager {
    pub fn new() -> Self {
        EpochManager {
            last_seen_epoch: current_epoch(),
            c2_bits:         crate::C2_BITS_DEFAULT,
            admission_count: 0,
        }
    }

    /// Call on every main loop tick. Returns true if epoch boundary was crossed.
    pub fn tick(&mut self) -> bool {
        let cur = current_epoch();
        if cur != self.last_seen_epoch {
            info!("Epoch transition: {} → {}", self.last_seen_epoch, cur);
            // Adjust difficulty
            self.c2_bits = crate::puzzle::PuzzleSolver::adjust_difficulty(
                self.admission_count,
                self.c2_bits,
            );
            self.admission_count = 0;
            self.last_seen_epoch = cur;
            true
        } else {
            false
        }
    }

    /// Record a new node admission (for difficulty adjustment).
    pub fn record_admission(&mut self) {
        self.admission_count += 1;
    }

    /// Returns seconds until the current epoch ends.
    pub fn secs_until_epoch_end() -> u64 {
        use std::time::{SystemTime, UNIX_EPOCH};
        let secs = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let epoch_dur = phantom_core::EPOCH_DURATION_SECS;
        epoch_dur - (secs % epoch_dur)
    }

    /// Returns true if we are within the republication window (last 900s of epoch).
    pub fn should_republish() -> bool {
        Self::secs_until_epoch_end() < 900
    }
}

impl Default for EpochManager {
    fn default() -> Self { Self::new() }
}
