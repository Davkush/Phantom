//! Dual-puzzle Sybil resistance (S/Kademlia scheme).
//!
//! Static puzzle: solved once per identity (H(pk_ed) has C1 leading zeros).
//! Dynamic puzzle: solved every epoch (H(node_id XOR nonce || epoch) has C2 leading zeros).
//! Combined: prevents cheap Sybil identity creation and epoch-activation flooding.

use serde::{Deserialize, Serialize};
use thiserror::Error;

use phantom_core::crypto::{NodeId, HybridKeypair};
use crate::{C1_BITS, C2_BITS_DEFAULT};

/// An admission token proving both static and dynamic PoW puzzles are solved.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AdmissionToken {
    /// Nonce that satisfies the static puzzle (embedded in identity).
    pub static_nonce:  [u8; 8],
    /// Nonce that satisfies the dynamic puzzle for this epoch.
    pub dynamic_nonce: [u8; 8],
    /// Epoch this token is valid for.
    pub epoch: u32,
    /// Difficulty used for dynamic puzzle.
    pub c2_bits: u32,
}

impl AdmissionToken {
    /// Verify both puzzle solutions. Returns true if valid.
    pub fn verify(&self, node_id: &NodeId, pk_ed: &[u8; 32]) -> bool {
        let epoch_ok = self.epoch == phantom_core::crypto::current_epoch();
        let static_ok = Self::check_static(pk_ed, C1_BITS);
        let dynamic_ok = Self::check_dynamic(node_id, &self.dynamic_nonce, self.epoch, self.c2_bits);
        epoch_ok && static_ok && dynamic_ok
    }

    fn check_static(pk_ed: &[u8; 32], c1: u32) -> bool {
        let h = blake3::hash(pk_ed);
        leading_zeros(h.as_bytes()) >= c1
    }

    fn check_dynamic(node_id: &NodeId, nonce: &[u8; 8], epoch: u32, c2: u32) -> bool {
        let mut input = [0u8; 48];
        for i in 0..32 { input[i] = node_id.as_bytes()[i] ^ nonce[i % 8]; }
        input[32..36].copy_from_slice(&epoch.to_be_bytes());
        let h = blake3::hash(&input);
        leading_zeros(h.as_bytes()) >= c2
    }

    /// Serialise to 20 bytes for inclusion in NodeDescriptor canonical form.
    pub fn to_bytes(&self) -> [u8; 20] {
        let mut out = [0u8; 20];
        out[0..8] .copy_from_slice(&self.static_nonce);
        out[8..16].copy_from_slice(&self.dynamic_nonce);
        out[16..20].copy_from_slice(&self.epoch.to_be_bytes());
        out
    }
}

/// Puzzle solver — finds valid nonces via CPU work.
pub struct PuzzleSolver;

impl PuzzleSolver {
    /// Solve the static puzzle: generate Ed25519 keypair with C1 leading zero bits in H(pk_ed).
    /// Expected: ~2^C1 iterations (~50ms at C1=20 on modern hardware).
    pub fn solve_static() -> Result<HybridKeypair, PuzzleError> {
        use rand::RngCore;
        let max_iters = 1u64 << (C1_BITS + 8); // safety limit

        for i in 0..max_iters {
            let kp = HybridKeypair::generate();
            let pk_ed = kp.ed25519_public();
            let h = blake3::hash(pk_ed.as_bytes());
            if leading_zeros(h.as_bytes()) >= C1_BITS {
                tracing::debug!("Static puzzle solved in {} iterations", i + 1);
                return Ok(kp);
            }
        }
        Err(PuzzleError::StaticUnsolvable)
    }

    /// Solve the dynamic puzzle for a given node_id and epoch.
    pub fn solve_dynamic(
        node_id: &NodeId,
        epoch:   u32,
        c2:      u32,
    ) -> Result<AdmissionToken, PuzzleError> {
        let max_iters = 1u64 << (c2 + 8);
        let mut nonce = [0u8; 8];

        for i in 0..max_iters {
            // Increment nonce as little-endian counter
            for b in nonce.iter_mut() {
                *b = b.wrapping_add(1);
                if *b != 0 { break; }
            }

            let mut input = [0u8; 48];
            for j in 0..32 { input[j] = node_id.as_bytes()[j] ^ nonce[j % 8]; }
            input[32..36].copy_from_slice(&epoch.to_be_bytes());
            let h = blake3::hash(&input);

            if leading_zeros(h.as_bytes()) >= c2 {
                tracing::debug!("Dynamic puzzle solved in {} iterations (epoch={})", i + 1, epoch);
                return Ok(AdmissionToken {
                    static_nonce:  nonce,   // reuse slot (static embedded in identity)
                    dynamic_nonce: nonce,
                    epoch,
                    c2_bits: c2,
                });
            }
        }
        Err(PuzzleError::DynamicUnsolvable { epoch })
    }

    /// Adjust difficulty based on observed admission rate.
    pub fn adjust_difficulty(observed: u32, current_c2: u32) -> u32 {
        if observed > crate::MAX_ADMISSIONS_PER_EPOCH {
            (current_c2 + 1).min(28)
        } else if observed < crate::MIN_ADMISSIONS_PER_EPOCH {
            current_c2.saturating_sub(1).max(10)
        } else {
            current_c2
        }
    }
}

fn leading_zeros(bytes: &[u8]) -> u32 {
    let mut count = 0u32;
    for &b in bytes {
        count += b.leading_zeros();
        if b != 0 { break; }
    }
    count
}

#[derive(Debug, Error)]
pub enum PuzzleError {
    #[error("Static puzzle unsolvable within iteration limit")]
    StaticUnsolvable,
    #[error("Dynamic puzzle unsolvable for epoch {epoch}")]
    DynamicUnsolvable { epoch: u32 },
}
