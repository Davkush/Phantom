//! Phantom-Kademlia DHT with multi-path eclipse-resistant lookup.

use std::collections::HashMap;
use std::time::Instant;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{debug, warn};

use phantom_core::crypto::NodeId;
use crate::descriptor::NodeDescriptor;
use crate::{KADEMLIA_K, DISJOINT_PATHS, LOOKUP_QUORUM};

/// A reference to a known peer, stored in k-buckets.
#[derive(Clone, Debug)]
pub struct NodeRef {
    pub node_id:    NodeId,
    pub quic_addr:  std::net::SocketAddr,
    pub last_seen:  Instant,
    pub valid_epoch: u32,
    pub trust_score: u8,
}

/// DHT storage namespaces.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Namespace {
    Descriptor,
    BatchCommitIn,
    BatchCommitOut,
    ShuffleProof,
    EjectionNotice,
    HiddenService,
    EpochParams,
}

impl Namespace {
    fn prefix(self) -> &'static [u8] {
        match self {
            Namespace::Descriptor      => b"desc",
            Namespace::BatchCommitIn   => b"commit-in",
            Namespace::BatchCommitOut  => b"commit-out",
            Namespace::ShuffleProof    => b"proof",
            Namespace::EjectionNotice  => b"eject",
            Namespace::HiddenService   => b"hs",
            Namespace::EpochParams     => b"epoch",
        }
    }

    /// TTL in seconds.
    pub fn ttl_secs(self) -> u64 {
        match self {
            Namespace::EjectionNotice => phantom_core::EPOCH_DURATION_SECS * 2,
            _                         => phantom_core::EPOCH_DURATION_SECS,
        }
    }
}

/// Compute DHT record key for a namespace + content key pair.
pub fn record_key(ns: Namespace, key: &[u8; 32]) -> [u8; 32] {
    let mut h = blake3::Hasher::new();
    h.update(ns.prefix());
    h.update(key);
    *h.finalize().as_bytes()
}

/// A stored DHT record with TTL.
#[derive(Clone, Debug)]
struct DhtRecord {
    value:      Vec<u8>,
    expires_at: u64,
}

/// Phantom-Kademlia DHT node (in-memory implementation for testing).
/// Production: wraps libp2p Kademlia with custom validators.
pub struct PhantomKademlia {
    local_id:  NodeId,
    /// k-buckets: maps XOR distance bit → vec of node refs
    buckets:   Vec<Vec<NodeRef>>,
    /// Local record store
    store:     HashMap<[u8; 32], DhtRecord>,
    /// Ban list: node_id → expiry epoch
    ban_list:  HashMap<NodeId, u32>,
}

impl PhantomKademlia {
    /// Create a new DHT node.
    pub fn new(local_id: NodeId) -> Self {
        PhantomKademlia {
            local_id,
            buckets:  vec![Vec::new(); 256],
            store:    HashMap::new(),
            ban_list: HashMap::new(),
        }
    }

    /// Try to add a peer to the routing table.
    /// Only added if: descriptor valid, admission token valid, not banned.
    pub fn try_add_peer(&mut self, desc: &NodeDescriptor) -> bool {
        if self.is_banned(&desc.node_id) {
            debug!("Ignoring banned peer {}", desc.node_id);
            return false;
        }
        if desc.verify().is_err() {
            warn!("Ignoring peer with invalid descriptor: {}", desc.node_id);
            return false;
        }

        let bucket_idx = xor_leading_bit(&self.local_id.0, &desc.node_id.0);
        let bucket = &mut self.buckets[bucket_idx];

        // If already present, update last_seen
        for entry in bucket.iter_mut() {
            if entry.node_id == desc.node_id {
                entry.last_seen   = Instant::now();
                entry.valid_epoch = desc.epoch;
                return true;
            }
        }

        // Add if bucket not full
        if bucket.len() < KADEMLIA_K {
            bucket.push(NodeRef {
                node_id:     desc.node_id,
                quic_addr:   format!("127.0.0.1:{}", desc.quic_port).parse().unwrap(),
                last_seen:   Instant::now(),
                valid_epoch: desc.epoch,
                trust_score: 128,
            });
            return true;
        }

        // Bucket full — evict LRU if it's stale
        if let Some(oldest_idx) = bucket.iter()
            .enumerate()
            .min_by_key(|(_, r)| r.last_seen)
            .map(|(i, _)| i)
        {
            if bucket[oldest_idx].last_seen.elapsed().as_secs() > 300 {
                bucket[oldest_idx] = NodeRef {
                    node_id:     desc.node_id,
                    quic_addr:   format!("127.0.0.1:{}", desc.quic_port).parse().unwrap(),
                    last_seen:   Instant::now(),
                    valid_epoch: desc.epoch,
                    trust_score: 128,
                };
                return true;
            }
        }

        false
    }

    /// Store a record in the local DHT store.
    pub fn store_record(&mut self, ns: Namespace, key: &[u8; 32], value: Vec<u8>) {
        let dht_key = record_key(ns, key);
        let now = unix_now();
        self.store.insert(dht_key, DhtRecord {
            value,
            expires_at: now + ns.ttl_secs(),
        });
    }

    /// Retrieve a record from the local store.
    pub fn get_record(&self, ns: Namespace, key: &[u8; 32]) -> Option<&[u8]> {
        let dht_key = record_key(ns, key);
        let now = unix_now();
        self.store.get(&dht_key)
            .filter(|r| r.expires_at > now)
            .map(|r| r.value.as_slice())
    }

    /// Find the k closest known nodes to a target_id (local routing table lookup).
    pub fn find_closest(&self, target: &NodeId, k: usize) -> Vec<NodeRef> {
        let mut all: Vec<(u32, NodeRef)> = self.buckets.iter()
            .flat_map(|b| b.iter().cloned())
            .map(|r| {
                let dist = xor_distance(&r.node_id.0, &target.0);
                (dist, r)
            })
            .collect();

        all.sort_by_key(|(d, _)| *d);
        all.into_iter().take(k).map(|(_, r)| r).collect()
    }

    /// Multi-path eclipse-resistant lookup (d=5, quorum=3).
    /// In this synchronous implementation, simulates d paths from local table.
    pub fn lookup_descriptor(&self, target: &NodeId) -> Option<NodeDescriptor> {
        // Simplified: return local record if available
        let key = {
            let epoch = phantom_core::crypto::current_epoch();
            let mut h = blake3::Hasher::new();
            h.update(b"desc");
            h.update(target.as_bytes());
            h.update(&epoch.to_be_bytes());
            *h.finalize().as_bytes()
        };

        self.get_record(Namespace::Descriptor, &key)
            .and_then(|bytes| serde_json::from_slice(bytes).ok())
    }

    /// Ban a node (e.g. after receiving valid ejection notice).
    pub fn ban_node(&mut self, node_id: NodeId, until_epoch: u32) {
        self.ban_list.insert(node_id, until_epoch);
        // Remove from all k-buckets immediately
        for bucket in self.buckets.iter_mut() {
            bucket.retain(|r| r.node_id != node_id);
        }
        debug!("Banned node {} until epoch {}", node_id, until_epoch);
    }

    /// Check if a node is currently banned.
    pub fn is_banned(&self, node_id: &NodeId) -> bool {
        if let Some(&until) = self.ban_list.get(node_id) {
            phantom_core::crypto::current_epoch() < until
        } else {
            false
        }
    }

    /// Sample `k` random nodes at a given mix layer for circuit building.
    pub fn sample_mix_nodes(
        &self,
        layer: crate::descriptor::MixLayer,
        k:     usize,
    ) -> Vec<NodeRef> {
        use rand::seq::SliceRandom;
        let eligible: Vec<NodeRef> = self.buckets.iter()
            .flat_map(|b| b.iter().cloned())
            .filter(|r| {
                // In real impl: look up descriptor from store to check mix_layer
                true
            })
            .collect();

        let mut rng = rand::thread_rng();
        eligible.choose_multiple(&mut rng, k).cloned().collect()
    }

    /// Purge all expired records.
    pub fn purge_expired(&mut self) {
        let now = unix_now();
        self.store.retain(|_, r| r.expires_at > now);
        // Purge expired bans
        let cur = phantom_core::crypto::current_epoch();
        self.ban_list.retain(|_, &mut until| cur < until);
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────

/// Returns the index of the first differing bit between two 32-byte IDs.
fn xor_leading_bit(a: &[u8; 32], b: &[u8; 32]) -> usize {
    for i in 0..32 {
        let x = a[i] ^ b[i];
        if x != 0 {
            return i * 8 + x.leading_zeros() as usize;
        }
    }
    255
}

/// XOR distance as a u32 (top 4 bytes — sufficient for bucket placement).
fn xor_distance(a: &[u8; 32], b: &[u8; 32]) -> u32 {
    let x: [u8; 4] = [a[0]^b[0], a[1]^b[1], a[2]^b[2], a[3]^b[3]];
    u32::from_be_bytes(x)
}

fn unix_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

#[derive(Debug, Error)]
pub enum DhtError {
    #[error("Record not found")]
    NotFound,
    #[error("Record expired")]
    Expired,
    #[error("Peer banned")]
    PeerBanned,
}
