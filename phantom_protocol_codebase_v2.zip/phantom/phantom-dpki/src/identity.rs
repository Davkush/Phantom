//! Self-certifying node identity.
//!
//! A node's identity is derived entirely from its public keys.
//! No external authority is needed for verification.

use blake3::Hasher;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use zeroize::ZeroizeOnDrop;

use phantom_core::crypto::{NodeId, HybridKeypair};
use crate::puzzle::{AdmissionToken, PuzzleSolver};

/// A fully formed node identity: keys + admission token.
#[derive(ZeroizeOnDrop)]
pub struct NodeIdentity {
    /// Underlying hybrid keypair.
    pub keypair: HybridKeypair,
    /// Proof-of-work admission token (current epoch).
    #[zeroize(skip)]
    pub admission: AdmissionToken,
}

impl NodeIdentity {
    /// Generate a new identity. Solves the static puzzle (takes ~50ms on modern hardware).
    /// Dynamic puzzle must be solved separately each epoch via `refresh_admission`.
    pub fn generate() -> Result<Self, IdentityError> {
        // Solve static puzzle: find Ed25519 keypair with H(pk_ed) having C1 leading zero bits
        tracing::info!("Solving static PoW puzzle (C1={} bits)...", crate::C1_BITS);
        let keypair = PuzzleSolver::solve_static()?;
        tracing::info!("Static puzzle solved. node_id={}", keypair.node_id);

        // Solve initial dynamic puzzle
        let admission = PuzzleSolver::solve_dynamic(
            &keypair.node_id,
            phantom_core::crypto::current_epoch(),
            crate::C2_BITS_DEFAULT,
        )?;

        Ok(NodeIdentity { keypair, admission })
    }

    /// Refresh the dynamic admission token for the current epoch.
    /// Must be called before each epoch boundary.
    pub fn refresh_admission(&mut self, c2_bits: u32) -> Result<(), IdentityError> {
        self.admission = PuzzleSolver::solve_dynamic(
            &self.keypair.node_id,
            phantom_core::crypto::current_epoch(),
            c2_bits,
        )?;
        Ok(())
    }

    /// Verify that a claimed node_id matches the provided public keys.
    pub fn verify_self_certification(
        claimed_id:  &NodeId,
        pk_ed:       &[u8; 32],
        pk_dil:      &[u8],
        pk_x25:      &[u8; 32],
        pk_kyber:    &[u8],
    ) -> bool {
        let recomputed = NodeId::derive(pk_ed, pk_dil, pk_x25, pk_kyber);
        recomputed == *claimed_id
    }
}

#[derive(Debug, Error)]
pub enum IdentityError {
    #[error("Static puzzle solving failed")]
    StaticPuzzleFailed,
    #[error("Dynamic puzzle solving failed")]
    DynamicPuzzleFailed,
}
