//! # phantom-dpki
//!
//! Phantom Distributed Public Key Infrastructure (Spec № 3).
//! Replaces directory authorities with a trustless Kademlia DHT.
//!
//! ## Components
//! - [`identity`] — self-certifying node identity
//! - [`puzzle`]   — dual-puzzle Sybil resistance  
//! - [`descriptor`] — NodeDescriptor format and signing
//! - [`dht`]      — Phantom-Kademlia DHT
//! - [`gossip`]   — ejection notice propagation
//! - [`bootstrap`] — seed-free network bootstrap
//! - [`epoch`]    — epoch timing and key rotation

#![forbid(unsafe_code)]
#![warn(missing_docs)]

pub mod identity;
pub mod puzzle;
pub mod descriptor;
pub mod dht;
pub mod gossip;
pub mod bootstrap;
pub mod epoch;

pub use identity::NodeIdentity;
pub use descriptor::{NodeDescriptor, CapacityTier};
pub use gossip::{EjectionNotice, OffenceType};
pub use dht::PhantomKademlia;

/// Static PoW difficulty: leading zero bits required in H(pk_ed).
pub const C1_BITS: u32 = 20;

/// Default dynamic PoW difficulty.
pub const C2_BITS_DEFAULT: u32 = 16;

/// Kademlia replication factor.
pub const KADEMLIA_K: usize = 20;

/// Number of disjoint lookup paths.
pub const DISJOINT_PATHS: usize = 5;

/// Quorum for eclipse-resistant lookup.
pub const LOOKUP_QUORUM: usize = 3;

/// Max admissions per epoch before C2 increments.
pub const MAX_ADMISSIONS_PER_EPOCH: u32 = 10_000;

/// Min admissions per epoch before C2 decrements.
pub const MIN_ADMISSIONS_PER_EPOCH: u32 = 100;
