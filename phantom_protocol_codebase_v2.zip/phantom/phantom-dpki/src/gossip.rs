//! Gossip ejection protocol.
//!
//! Misbehaving nodes are ejected from the network via signed gossip notices.
//! Evidence is self-verifying — any node can independently confirm the offence.

use serde::{Deserialize, Serialize};
use thiserror::Error;

use phantom_core::crypto::NodeId;

/// Categories of ejectable misbehaviour.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum OffenceType {
    /// ZK shuffle proof failed verification.
    InvalidShuffleProof,
    /// Batch window expired without proof being published.
    ProofNotPublished,
    /// Two different C_in published for same batch_id (equivocation).
    Equivocation,
    /// NodeDescriptor signature invalid.
    DescriptorForgery,
    /// Packet alpha_classical seen twice in same epoch (replay).
    ReplayAttack,
    /// Descriptor published for wrong epoch.
    EpochViolation,
    /// DC-Net ciphertext failed ZK proof verification.
    InvalidDcNetCiphertext,
}

/// A signed ejection notice publishable to the gossip network.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EjectionNotice {
    /// Node being ejected.
    pub offender_id:  NodeId,
    /// Epoch of the offence.
    pub epoch:        u32,
    /// Type of offence.
    pub offence:      OffenceType,
    /// Serialised evidence (offence-specific bytes).
    pub evidence:     Vec<u8>,
    /// Node reporting the offence.
    pub reporter_id:  NodeId,
    /// Unix timestamp.
    pub timestamp:    u64,
    /// Reporter's Ed25519 signature.
    pub sig_ed25519:  [u8; 64],
}

impl EjectionNotice {
    /// Create and sign an ejection notice.
    pub fn create(
        offender:    NodeId,
        offence:     OffenceType,
        evidence:    Vec<u8>,
        reporter:    &crate::identity::NodeIdentity,
    ) -> Self {
        let epoch = phantom_core::crypto::current_epoch();
        let now   = unix_now();

        let mut notice = EjectionNotice {
            offender_id: offender,
            epoch,
            offence,
            evidence,
            reporter_id: reporter.keypair.node_id,
            timestamp:   now,
            sig_ed25519: [0u8; 64],
        };

        let canonical = notice.canonical_bytes();
        let hash = blake3::hash(&canonical);
        let sig  = reporter.keypair.sign_ed25519(hash.as_bytes());
        notice.sig_ed25519 = sig.to_bytes();
        notice
    }

    /// Verify the reporter's signature on this notice.
    pub fn verify_signature(&self, reporter_pk: &ed25519_dalek::VerifyingKey) -> bool {
        use ed25519_dalek::Verifier;
        let canonical = self.canonical_bytes();
        let hash = blake3::hash(&canonical);
        let sig  = ed25519_dalek::Signature::from_bytes(&self.sig_ed25519);
        reporter_pk.verify(hash.as_bytes(), &sig).is_ok()
    }

    /// DHT key for storing this notice.
    pub fn dht_key(&self) -> [u8; 32] {
        let mut h = blake3::Hasher::new();
        h.update(b"eject");
        h.update(self.offender_id.as_bytes());
        h.update(&self.epoch.to_be_bytes());
        *h.finalize().as_bytes()
    }

    fn canonical_bytes(&self) -> Vec<u8> {
        let mut v = Vec::new();
        v.extend_from_slice(b"phantom-ejection-v1");
        v.extend_from_slice(self.offender_id.as_bytes());
        v.extend_from_slice(&self.epoch.to_be_bytes());
        v.extend_from_slice(self.reporter_id.as_bytes());
        v.extend_from_slice(&self.timestamp.to_be_bytes());
        v.extend_from_slice(&self.evidence);
        v
    }
}

fn unix_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

#[derive(Debug, Error)]
pub enum GossipError {
    #[error("Ejection notice signature invalid")]
    SignatureInvalid,
    #[error("Evidence verification failed")]
    EvidenceInvalid,
}
