//! Integration tests for phantom-core.

use phantom_core::crypto::{HybridKeypair, NodeId, current_epoch};
use phantom_core::sphinx::{SphinxPacket, PacketFlags, ReplayCache, process_hop, HopResult};
use phantom_core::mix::MixNode;

#[test]
fn test_node_id_derivation_is_deterministic() {
    let kp = HybridKeypair::generate();
    let id1 = kp.node_id;

    // Re-derive from the same keys
    use pqcrypto_traits::{kem::PublicKey as KP, sign::PublicKey as SP};
    let pk_ed  = kp.ed25519_public();
    let pk_dil = pqcrypto_dilithium::dilithium3::keypair().0;
    let pk_x25 = kp.x25519_public();
    let pk_kyb = pqcrypto_kyber::kyber1024::keypair().0;

    let id2 = NodeId::derive(
        pk_ed.as_bytes(),
        pk_dil.as_bytes(),
        pk_x25.as_bytes(),
        pk_kyb.as_bytes(),
    );

    // Different keys → different ID (probabilistically always true)
    assert_ne!(id1, id2, "Two independent keypairs should have different IDs");
}

#[test]
fn test_node_id_is_32_bytes() {
    let kp = HybridKeypair::generate();
    assert_eq!(kp.node_id.as_bytes().len(), 32);
}

#[test]
fn test_shared_secret_key_derivation() {
    let kp = HybridKeypair::generate();
    let dummy_ss = phantom_core::crypto::SharedSecret([42u8; 32]);

    let mac_key     = dummy_ss.mac_key();
    let payload_key = dummy_ss.payload_key();
    let routing_key = dummy_ss.routing_key();
    let blind       = dummy_ss.blind_scalar();

    // All four derived keys must be distinct
    assert_ne!(mac_key, payload_key);
    assert_ne!(mac_key, routing_key);
    assert_ne!(mac_key, blind);
    assert_ne!(payload_key, routing_key);
}

#[test]
fn test_sphinx_packet_serialisation_roundtrip() {
    let mut rng = rand::thread_rng();
    let epoch = current_epoch();
    let pkt = SphinxPacket::new_cover(epoch, &mut rng);

    let bytes = pkt.to_bytes();
    assert_eq!(bytes.len(), phantom_core::PACKET_SIZE);

    let pkt2 = SphinxPacket::from_bytes(&bytes).expect("deserialisation failed");
    assert_eq!(pkt2.version, pkt.version);
    assert_eq!(pkt2.flags.0, pkt.flags.0);
    assert_eq!(pkt2.epoch, pkt.epoch);
    assert_eq!(pkt2.alpha_classical, pkt.alpha_classical);
    assert_eq!(pkt2.gamma_mac, pkt.gamma_mac);
}

#[test]
fn test_packet_size_is_exactly_1452() {
    let mut rng = rand::thread_rng();
    let pkt = SphinxPacket::new_cover(current_epoch(), &mut rng);
    let bytes = pkt.to_bytes();
    assert_eq!(bytes.len(), 1452, "Packet must be exactly 1452 bytes");
}

#[test]
fn test_cover_packet_flag_is_set() {
    let mut rng = rand::thread_rng();
    let pkt = SphinxPacket::new_cover(current_epoch(), &mut rng);
    assert!(pkt.flags.is_cover(), "Cover packet must have COVER flag set");
}

#[test]
fn test_replay_cache_detects_duplicate() {
    let mut cache = ReplayCache::new();
    let alpha = [7u8; 32];

    let first  = cache.check_and_insert(&alpha);
    let second = cache.check_and_insert(&alpha);

    assert!(!first,  "First insertion should not be a replay");
    assert!(second,  "Second insertion should be detected as replay");
}

#[test]
fn test_replay_cache_allows_different_packets() {
    let mut cache = ReplayCache::new();
    let alpha1 = [1u8; 32];
    let alpha2 = [2u8; 32];

    assert!(!cache.check_and_insert(&alpha1));
    assert!(!cache.check_and_insert(&alpha2));
}

#[test]
fn test_mix_node_processes_batch() {
    let kp = HybridKeypair::generate();
    let mut mix = MixNode::new(kp);
    let mut rng = rand::thread_rng();

    // Ingest cover packets to fill minimum batch
    for _ in 0..phantom_core::MIN_BATCH_SIZE {
        let pkt = SphinxPacket::new_cover(current_epoch(), &mut rng);
        mix.ingest(pkt);
    }

    // Force window elapsed (simulated by calling process)
    let result = mix.process_batch();
    assert!(result.is_ok(), "Batch processing should succeed: {:?}", result.err());

    let output = result.unwrap();
    assert!(!output.packets.is_empty() || output.c_in.commitments.len() >= phantom_core::MIN_BATCH_SIZE,
        "Output should have packets or commitments");
}

#[test]
fn test_batch_commitment_hash_is_deterministic() {
    use phantom_core::mix::BatchCommitment;
    let mut rng = rand::thread_rng();
    let epoch = current_epoch();
    let batch_id = [0u8; 32];

    let packets: Vec<SphinxPacket> = (0..4)
        .map(|_| SphinxPacket::new_cover(epoch, &mut rng))
        .collect();

    let blindings: Vec<[u8; 32]> = (0..4).map(|i| [i as u8; 32]).collect();

    let c1 = BatchCommitment::compute(&packets, &blindings, batch_id, epoch);
    let c2 = BatchCommitment::compute(&packets, &blindings, batch_id, epoch);

    assert_eq!(c1.hash, c2.hash, "Commitment hash must be deterministic");
}

#[test]
fn test_ed25519_sign_verify() {
    use ed25519_dalek::Verifier;
    let kp  = HybridKeypair::generate();
    let msg = b"phantom test message";
    let sig = kp.sign_ed25519(msg);
    let pk  = kp.ed25519_public();
    assert!(pk.verify(msg, &sig).is_ok(), "Ed25519 signature must verify");
}
