//! Phase 2 integration tests: transport, circuits, hidden services, reputation.

use phantom_core::crypto::{NodeId, HybridKeypair, current_epoch};
use phantom_core::circuit::{
    CircuitBuilder, CircuitPath, CircuitHop, HopRole, CircuitId, CircuitPool, MAX_CIRCUIT_AGE_SECS
};
use phantom_core::hidden_service::{
    PhantomAddress, HiddenServiceManager, RendezvousCookie,
    RendezvousRequest, IntroductionPoint,
};
use phantom_core::reputation::{ReputationStore, NodeReputation, GUARD_UPTIME_THRESHOLD};
use phantom_core::transport::{PacketDispatcher, TrafficObfuscator};
use phantom_core::sphinx::SphinxPacket;
use std::sync::Arc;

// ── Transport tests ───────────────────────────────────────────────────────

#[test]
fn test_packet_dispatcher_counts_connections() {
    use tokio::sync::mpsc;
    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        let (dead_tx, _) = mpsc::channel(8);
        let dispatcher = PacketDispatcher::new(dead_tx);
        assert_eq!(dispatcher.connection_count().await, 0);
    });
}

#[test]
fn test_traffic_obfuscator_pads_to_mtu() {
    let obf = TrafficObfuscator::new(100_000);
    let short_data = vec![1u8, 2u8, 3u8];
    let padded = obf.pad(&short_data);
    assert_eq!(padded.len(), phantom_core::PACKET_SIZE);
    assert_eq!(&padded[..3], &[1u8, 2u8, 3u8]);
    assert_eq!(&padded[3..], &vec![0u8; phantom_core::PACKET_SIZE - 3][..]);
}

#[test]
fn test_traffic_obfuscator_handles_exact_mtu() {
    let obf   = TrafficObfuscator::new(100_000);
    let exact = vec![0xFFu8; phantom_core::PACKET_SIZE];
    let padded = obf.pad(&exact);
    assert_eq!(padded.len(), phantom_core::PACKET_SIZE);
    assert_eq!(padded, exact.as_slice());
}

// ── Circuit tests ─────────────────────────────────────────────────────────

fn make_circuit_hop(role: HopRole) -> CircuitHop {
    let kp = HybridKeypair::generate();
    CircuitHop {
        node_id:   kp.node_id,
        pk_x25519: kp.x25519_public().to_bytes(),
        pk_kyber:  {
            use pqcrypto_traits::kem::PublicKey;
            pqcrypto_kyber::kyber1024::keypair().0.as_bytes().to_vec()
        },
        role,
    }
}

fn make_circuit_path() -> CircuitPath {
    CircuitPath {
        hops: [
            make_circuit_hop(HopRole::Guard),
            make_circuit_hop(HopRole::Middle),
            make_circuit_hop(HopRole::Exit),
        ],
        circuit_id: CircuitId::random(),
    }
}

#[test]
fn test_circuit_id_is_unique() {
    let id1 = CircuitId::random();
    let id2 = CircuitId::random();
    assert_ne!(id1, id2, "Circuit IDs must be unique");
}

#[test]
fn test_circuit_builder_constructs_circuit() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(kp);
    let path    = make_circuit_path();
    let circuit = builder.build(path);
    assert!(circuit.is_ok(), "Circuit construction must succeed: {:?}", circuit.err());
}

#[test]
fn test_circuit_hop_secrets_are_distinct() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(kp);
    let path    = make_circuit_path();
    let circuit = builder.build(path).unwrap();
    // Each hop gets a different shared secret (verified by different entry nodes)
    let guard_id  = circuit.path.hops[0].node_id;
    let middle_id = circuit.path.hops[1].node_id;
    let exit_id   = circuit.path.hops[2].node_id;
    assert_ne!(guard_id, middle_id);
    assert_ne!(guard_id, exit_id);
    assert_ne!(middle_id, exit_id);
}

#[test]
fn test_circuit_wraps_payload() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(kp);
    let path    = make_circuit_path();
    let mut circuit = builder.build(path).unwrap();

    let payload = b"Hello, Phantom!";
    let dest    = [0u8; 32];
    let pkt     = circuit.wrap(payload, dest);
    assert!(pkt.is_ok(), "Circuit wrapping must succeed: {:?}", pkt.err());

    let pkt = pkt.unwrap();
    assert_eq!(pkt.version, phantom_core::PROTOCOL_VERSION);
    assert_eq!(pkt.to_bytes().len(), phantom_core::PACKET_SIZE);
}

#[test]
fn test_circuit_increments_packet_count() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(kp);
    let path    = make_circuit_path();
    let mut circuit = builder.build(path).unwrap();

    assert_eq!(circuit.packet_count(), 0);
    for _ in 0..5 {
        let _ = circuit.wrap(b"test", [0u8; 32]);
    }
    assert_eq!(circuit.packet_count(), 5);
}

#[test]
fn test_circuit_pool_add_and_retrieve() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(Arc::clone(&kp));
    let mut pool = CircuitPool::new(Arc::clone(&kp));

    let path    = make_circuit_path();
    let id      = path.circuit_id;
    let circuit = builder.build(path).unwrap();
    pool.add(circuit);

    assert_eq!(pool.circuit_count(), 1);
    assert!(pool.get_or_rotate(id).is_some());
}

#[test]
fn test_circuit_rejects_oversized_payload() {
    let kp      = Arc::new(HybridKeypair::generate());
    let builder = CircuitBuilder::new(kp);
    let path    = make_circuit_path();
    let mut circuit = builder.build(path).unwrap();

    let huge_payload = vec![0u8; phantom_core::PAYLOAD_SIZE + 1];
    let result = circuit.wrap(&huge_payload, [0u8; 32]);
    assert!(result.is_err(), "Oversized payload must be rejected");
}

// ── Hidden service tests ──────────────────────────────────────────────────

#[test]
fn test_phantom_address_derivation_is_deterministic() {
    let kp       = HybridKeypair::generate();
    let pk_ed    = kp.ed25519_public();
    use pqcrypto_traits::kem::PublicKey;
    let pk_kyber = pqcrypto_kyber::kyber1024::keypair().0;

    let addr1 = PhantomAddress::derive(pk_ed.as_bytes(), pk_kyber.as_bytes());
    let addr2 = PhantomAddress::derive(pk_ed.as_bytes(), pk_kyber.as_bytes());
    assert_eq!(addr1, addr2, "Address derivation must be deterministic");
}

#[test]
fn test_phantom_address_is_unique_per_keypair() {
    use pqcrypto_traits::kem::PublicKey;
    let kp1 = HybridKeypair::generate();
    let kp2 = HybridKeypair::generate();
    let pk_kyber = pqcrypto_kyber::kyber1024::keypair().0;

    let addr1 = PhantomAddress::derive(kp1.ed25519_public().as_bytes(), pk_kyber.as_bytes());
    let addr2 = PhantomAddress::derive(kp2.ed25519_public().as_bytes(), pk_kyber.as_bytes());
    assert_ne!(addr1, addr2, "Different keypairs must produce different addresses");
}

#[test]
fn test_phantom_address_to_base32_contains_phantom_tld() {
    let kp = HybridKeypair::generate();
    use pqcrypto_traits::kem::PublicKey;
    let pk_kyber = pqcrypto_kyber::kyber1024::keypair().0;
    let addr = PhantomAddress::derive(kp.ed25519_public().as_bytes(), pk_kyber.as_bytes());
    assert!(addr.to_base32().ends_with(".phantom"),
        "Address must end with .phantom TLD");
}

#[test]
fn test_phantom_address_dht_keys_differ_by_epoch() {
    let addr  = PhantomAddress([5u8; 32]);
    let key1  = addr.dht_key(1);
    let key2  = addr.dht_key(2);
    assert_ne!(key1, key2, "DHT keys must differ across epochs");
}

#[test]
fn test_hidden_service_manager_creates_address() {
    let kp  = Arc::new(HybridKeypair::generate());
    let mgr = HiddenServiceManager::new(Arc::clone(&kp));
    // Address is 32 bytes
    assert_eq!(mgr.address.0.len(), 32);
}

#[test]
fn test_hidden_service_rendezvous_request() {
    let kp   = Arc::new(HybridKeypair::generate());
    let mut mgr = HiddenServiceManager::new(Arc::clone(&kp));

    let cookie    = RendezvousCookie::random();
    let eph_sk    = x25519_dalek::StaticSecret::random_from_rng(rand::thread_rng());
    let eph_pk    = x25519_dalek::PublicKey::from(&eph_sk);

    let req = RendezvousRequest {
        rendezvous_node: NodeId([9u8; 32]),
        cookie,
        client_pk_eph:   *eph_pk.as_bytes(),
        client_ct_pq:    vec![],
    };

    let session = mgr.handle_rendezvous_request(req);
    assert!(session.is_ok(), "Rendezvous must succeed: {:?}", session.err());

    let session = session.unwrap();
    assert_eq!(session.cookie, cookie);
    assert_eq!(session.session_key.len(), 32);
}

#[test]
fn test_hidden_service_two_rendezvous_different_session_keys() {
    let kp   = Arc::new(HybridKeypair::generate());
    let mut mgr = HiddenServiceManager::new(Arc::clone(&kp));

    let make_req = || {
        let eph_sk = x25519_dalek::StaticSecret::random_from_rng(rand::thread_rng());
        let eph_pk = x25519_dalek::PublicKey::from(&eph_sk);
        RendezvousRequest {
            rendezvous_node: NodeId([1u8; 32]),
            cookie:          RendezvousCookie::random(),
            client_pk_eph:   *eph_pk.as_bytes(),
            client_ct_pq:    vec![],
        }
    };

    let s1 = mgr.handle_rendezvous_request(make_req()).unwrap();
    let s2 = mgr.handle_rendezvous_request(make_req()).unwrap();

    assert_ne!(s1.session_key, s2.session_key,
        "Each rendezvous must produce a distinct session key");
}

// ── Reputation tests ──────────────────────────────────────────────────────

#[test]
fn test_reputation_starts_neutral() {
    let id  = NodeId([0u8; 32]);
    let rep = NodeReputation::new(id);
    assert!(!rep.is_banned(), "New node must not be banned");
    assert!(rep.weight() > 0.0, "New node must have positive weight");
}

#[test]
fn test_reputation_valid_proofs_increase_weight() {
    let id  = NodeId([1u8; 32]);
    let mut rep = NodeReputation::new(id);
    let initial_weight = rep.weight();

    for _ in 0..20 { rep.record_proof(true); }
    assert!(rep.weight() > initial_weight, "Valid proofs must increase weight");
}

#[test]
fn test_reputation_invalid_proofs_decrease_weight() {
    let id  = NodeId([2u8; 32]);
    let mut rep = NodeReputation::new(id);
    for _ in 0..5 { rep.record_proof(true); } // establish good standing
    let good_weight = rep.weight();

    for _ in 0..30 { rep.record_proof(false); } // lots of failures
    assert!(rep.weight() < good_weight, "Invalid proofs must decrease weight");
}

#[test]
fn test_reputation_ejection_reduces_weight() {
    let id  = NodeId([3u8; 32]);
    let mut rep = NodeReputation::new(id);
    let initial_weight = rep.weight();
    rep.record_ejection();
    assert!(rep.weight() < initial_weight, "Ejection must reduce weight");
}

#[test]
fn test_reputation_three_ejections_bans_node() {
    let id  = NodeId([4u8; 32]);
    let mut rep = NodeReputation::new(id);
    for _ in 0..3 { rep.record_ejection(); }
    assert!(rep.is_banned(), "3 ejections must ban a node");
    assert_eq!(rep.weight(), 0.0, "Banned node must have zero weight");
}

#[test]
fn test_reputation_store_select_guards() {
    let mut store = ReputationStore::new();

    // Add 5 high-reputation nodes
    for i in 0..5u8 {
        let id = NodeId([i; 32]);
        let rep = store.get_or_create(id);
        rep.uptime_score = 240; // above GUARD_UPTIME_THRESHOLD
        for _ in 0..10 { rep.record_proof(true); }
    }

    // Add 3 low-reputation nodes
    for i in 10..13u8 {
        let id = NodeId([i; 32]);
        let rep = store.get_or_create(id);
        rep.uptime_score = 100;
    }

    let guards = store.select_guards(3);
    assert!(guards.len() <= 3);
    assert_eq!(store.eligible_guards(), 5);
}

#[test]
fn test_reputation_store_select_relays_excludes_banned() {
    let mut store = ReputationStore::new();
    let good   = NodeId([1u8; 32]);
    let banned = NodeId([2u8; 32]);

    let rep_good = store.get_or_create(good);
    for _ in 0..5 { rep_good.record_proof(true); }

    let rep_bad = store.get_or_create(banned);
    for _ in 0..3 { rep_bad.record_ejection(); }

    let relays = store.select_relays(5, &[]);
    assert!(!relays.contains(&banned), "Banned nodes must not be selected as relays");
}
