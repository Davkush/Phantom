//! Circuit builder: constructs multi-hop Sphinx⁺ paths.
//!
//! A circuit is a sequence of relay nodes through which traffic is routed.
//! Standard 3-hop topology: Guard → Middle → Exit.
//!
//! ## Circuit construction (telescoping key exchange)
//! 1. Select Guard, Middle, Exit nodes from DPKI
//! 2. Perform hybrid key exchange with each hop in order
//! 3. Onion-encrypt the path information
//! 4. Produce a `Circuit` that wraps payloads in Sphinx⁺ packets
//!
//! ## Circuit lifecycle
//! - Circuits pre-built at startup (1 per destination class)
//! - Replaced after MAX_CIRCUIT_AGE_SECS or on proof of compromise
//! - Each packet uses a fresh ephemeral key (forward secrecy)

use std::collections::HashMap;
use std::time::{Duration, Instant};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{debug, info, warn};

use crate::crypto::{NodeId, HybridKeypair, SharedSecret, current_epoch};
use crate::sphinx::{SphinxPacket, PacketFlags};
use crate::PAYLOAD_SIZE;

/// Number of hops in a standard circuit.
pub const CIRCUIT_HOPS: usize = 3;

/// Maximum circuit age before replacement.
pub const MAX_CIRCUIT_AGE_SECS: u64 = 600; // 10 minutes

/// Maximum number of packets per circuit before rotation.
pub const MAX_PACKETS_PER_CIRCUIT: u64 = 10_000;

// ── Circuit path ──────────────────────────────────────────────────────────

/// A single hop in a circuit path.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CircuitHop {
    /// Node ID of this relay.
    pub node_id:     NodeId,
    /// X25519 public key of this relay (for key exchange).
    pub pk_x25519:   [u8; 32],
    /// Kyber-1024 public key (for post-quantum KEM).
    pub pk_kyber:    Vec<u8>,
    /// Role of this hop.
    pub role:        HopRole,
}

/// The role of a hop in the circuit.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum HopRole {
    Guard,
    Middle,
    Exit,
}

/// A complete 3-hop circuit path specification.
#[derive(Clone, Debug)]
pub struct CircuitPath {
    pub hops:    [CircuitHop; CIRCUIT_HOPS],
    pub circuit_id: CircuitId,
}

/// Unique circuit identifier.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CircuitId(pub [u8; 16]);

impl CircuitId {
    pub fn random() -> Self {
        use rand::RngCore;
        let mut id = [0u8; 16];
        rand::thread_rng().fill_bytes(&mut id);
        CircuitId(id)
    }
}

// ── Live circuit ──────────────────────────────────────────────────────────

/// A live circuit ready to wrap payloads in Sphinx⁺ packets.
pub struct Circuit {
    pub id:        CircuitId,
    pub path:      CircuitPath,
    /// Session shared secrets for each hop (derived during construction).
    hop_secrets:   [SharedSecret; CIRCUIT_HOPS],
    /// When this circuit was built.
    built_at:      Instant,
    /// How many packets have been sent on this circuit.
    packet_count:  u64,
}

impl Circuit {
    /// Wrap a payload in a 3-layer Sphinx⁺ onion for this circuit.
    pub fn wrap(&mut self, payload: &[u8], dest: [u8; 32]) -> Result<SphinxPacket, CircuitError> {
        if payload.len() > PAYLOAD_SIZE {
            return Err(CircuitError::PayloadTooLarge(payload.len()));
        }

        let epoch = current_epoch();
        let mut rng = rand::thread_rng();

        // Pad payload to fixed size
        let mut padded_payload = [0u8; PAYLOAD_SIZE];
        padded_payload[..payload.len()].copy_from_slice(payload);

        // Build routing blocks for each hop (innermost first)
        // Exit hop: deliver to dest
        let exit_routing = build_routing_block(
            &self.path.hops[2].node_id,
            RoutingCommand::Exit { dest },
        );
        // Middle hop: forward to exit
        let middle_routing = build_routing_block(
            &self.path.hops[2].node_id,
            RoutingCommand::Relay { next_hop: self.path.hops[2].node_id },
        );
        // Guard hop: forward to middle
        let guard_routing = build_routing_block(
            &self.path.hops[1].node_id,
            RoutingCommand::Relay { next_hop: self.path.hops[1].node_id },
        );

        // Encrypt payload layers (exit → middle → guard, innermost first)
        let mut enc_payload = padded_payload;
        for i in (0..CIRCUIT_HOPS).rev() {
            enc_payload = encrypt_payload_layer(&enc_payload, &self.hop_secrets[i]);
        }

        // Build the outermost packet (addressed to guard node)
        let mut alpha_cl = [0u8; 32];
        let mut alpha_pq = [0u8; 96];
        rng.fill_bytes(&mut alpha_cl);
        rng.fill_bytes(&mut alpha_pq);

        let mac_key = self.hop_secrets[0].mac_key();

        let mut pkt = SphinxPacket {
            version:         crate::PROTOCOL_VERSION,
            flags:           PacketFlags::FORWARD,
            epoch,
            alpha_classical: alpha_cl,
            alpha_pq,
            beta_routing:    guard_routing,
            gamma_mac:       [0u8; 32],
            c_batch:         [0u8; 8],
            pi_ref:          0,
            payload:         {
                let mut p = Box::new([0u8; PAYLOAD_SIZE]);
                p.copy_from_slice(&enc_payload);
                p
            },
        };
        pkt.gamma_mac = pkt.compute_mac(&mac_key);

        self.packet_count += 1;
        debug!("Circuit {}: wrapped packet #{}", hex::encode(&self.id.0[..4]), self.packet_count);

        Ok(pkt)
    }

    /// Check if this circuit should be rotated.
    pub fn should_rotate(&self) -> bool {
        self.built_at.elapsed() > Duration::from_secs(MAX_CIRCUIT_AGE_SECS)
            || self.packet_count >= MAX_PACKETS_PER_CIRCUIT
    }

    /// Return the entry node (Guard) for dispatching.
    pub fn entry_node(&self) -> NodeId {
        self.path.hops[0].node_id
    }

    pub fn id(&self) -> CircuitId { self.id }
    pub fn packet_count(&self) -> u64 { self.packet_count }
    pub fn age_secs(&self) -> u64 { self.built_at.elapsed().as_secs() }
}

// ── Circuit builder ───────────────────────────────────────────────────────

/// Builds circuits by performing key exchanges with each hop.
pub struct CircuitBuilder {
    local_keypair: Arc<HybridKeypair>,
}

use std::sync::Arc;

impl CircuitBuilder {
    pub fn new(keypair: Arc<HybridKeypair>) -> Self {
        CircuitBuilder { local_keypair: keypair }
    }

    /// Build a circuit from a pre-selected path.
    /// In production: each key exchange is sent via Sphinx⁺ EXTEND cells
    /// through the already-established partial circuit (telescoping).
    /// Here: performs the key derivation locally (simulated for testing).
    pub fn build(&self, path: CircuitPath) -> Result<Circuit, CircuitError> {
        // Simulate telescoping key exchange:
        // Guard: direct X25519+Kyber with guard's keys
        // Middle: X25519+Kyber through guard (guard relays CREATE_MIDDLE cell)
        // Exit:   X25519+Kyber through guard+middle (both relay CREATE_EXIT cell)
        let epoch = current_epoch();

        let mut hop_secrets: Vec<SharedSecret> = Vec::with_capacity(CIRCUIT_HOPS);

        for (i, hop) in path.hops.iter().enumerate() {
            // Simulate: derive shared secret using BLAKE3 of hop keys + circuit_id
            // Real impl: X25519+Kyber DH with each hop's actual keys
            let mut h = blake3::Hasher::new();
            h.update(b"phantom-circuit-hop-v1");
            h.update(&path.circuit_id.0);
            h.update(hop.node_id.as_bytes());
            h.update(self.local_keypair.node_id.as_bytes());
            h.update(&epoch.to_be_bytes());
            h.update(&[i as u8]);
            let secret = SharedSecret(*h.finalize().as_bytes());
            hop_secrets.push(secret);
        }

        info!(
            "Circuit {} built: {} → {} → {}",
            hex::encode(&path.circuit_id.0[..4]),
            path.hops[0].node_id,
            path.hops[1].node_id,
            path.hops[2].node_id,
        );

        Ok(Circuit {
            id:           path.circuit_id,
            path,
            hop_secrets:  hop_secrets.try_into()
                .map_err(|_| CircuitError::InsufficientHops)?,
            built_at:     Instant::now(),
            packet_count: 0,
        })
    }
}

// ── Circuit pool ──────────────────────────────────────────────────────────

/// Manages a pool of pre-built circuits, one per destination class.
pub struct CircuitPool {
    circuits:  HashMap<CircuitId, Circuit>,
    builder:   CircuitBuilder,
}

impl CircuitPool {
    pub fn new(keypair: Arc<HybridKeypair>) -> Self {
        CircuitPool {
            circuits: HashMap::new(),
            builder:  CircuitBuilder::new(keypair),
        }
    }

    /// Add a pre-built circuit to the pool.
    pub fn add(&mut self, circuit: Circuit) {
        let id = circuit.id;
        self.circuits.insert(id, circuit);
    }

    /// Get a circuit, rotating if needed.
    /// Returns None if no circuit is available (caller should build one).
    pub fn get_or_rotate(&mut self, id: CircuitId) -> Option<&mut Circuit> {
        if let Some(c) = self.circuits.get(&id) {
            if c.should_rotate() {
                self.circuits.remove(&id);
                return None;
            }
        }
        self.circuits.get_mut(&id)
    }

    /// Return any available circuit that doesn't need rotation.
    pub fn any_available(&mut self) -> Option<&mut Circuit> {
        let to_remove: Vec<CircuitId> = self.circuits.values()
            .filter(|c| c.should_rotate())
            .map(|c| c.id)
            .collect();
        for id in to_remove { self.circuits.remove(&id); }
        self.circuits.values_mut().next()
    }

    pub fn circuit_count(&self) -> usize { self.circuits.len() }
}

// ── Helpers ───────────────────────────────────────────────────────────────

#[derive(Clone, Debug)]
enum RoutingCommand {
    Relay  { next_hop: NodeId },
    Exit   { dest: [u8; 32] },
}

fn build_routing_block(node_id: &NodeId, cmd: RoutingCommand) -> [u8; 128] {
    let mut block = [0u8; 128];
    block[..32].copy_from_slice(node_id.as_bytes());
    match cmd {
        RoutingCommand::Relay { .. } => block[32] = 0x01,
        RoutingCommand::Exit  { dest } => {
            block[32] = 0x02;
            block[33..65].copy_from_slice(&dest);
        }
    }
    block
}

fn encrypt_payload_layer(payload: &[u8; PAYLOAD_SIZE], secret: &SharedSecret) -> [u8; PAYLOAD_SIZE] {
    use chacha20poly1305::cipher::{KeyIvInit, StreamCipher};
    type ChaCha20 = chacha20poly1305::ChaCha20;
    let key = secret.payload_key();
    let nonce = chacha20poly1305::cipher::generic_array::GenericArray::from_slice(&[0u8; 12]);
    let key_arr = chacha20poly1305::cipher::generic_array::GenericArray::from_slice(&key);
    let mut cipher = ChaCha20::new(key_arr, nonce);
    let mut out = *payload;
    cipher.apply_keystream(&mut out);
    out
}

/// Circuit construction errors.
#[derive(Debug, Error)]
pub enum CircuitError {
    #[error("Payload too large: {0} bytes (max {})", PAYLOAD_SIZE)]
    PayloadTooLarge(usize),
    #[error("Insufficient hops for circuit construction")]
    InsufficientHops,
    #[error("Key exchange failed for hop {0}")]
    KeyExchangeFailed(usize),
    #[error("No circuit available")]
    NoCircuitAvailable,
    #[error("Circuit expired")]
    CircuitExpired,
}
