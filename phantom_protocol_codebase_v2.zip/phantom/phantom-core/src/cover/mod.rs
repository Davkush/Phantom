//! Mandatory cover traffic engine.
//!
//! Every node sends exactly one packet per COVER_INTERVAL_MS regardless
//! of real traffic. Cover packets are structurally identical to real packets.
//! Three cover types: Loop, Drop, Decoy.

use std::time::Duration;
use tokio::time::{self, MissedTickBehavior};
use tokio::sync::mpsc;
use tracing::debug;

use crate::crypto::{current_epoch, NodeId};
use crate::sphinx::SphinxPacket;

/// Cover traffic interval in milliseconds. Every node sends one packet per interval.
pub const COVER_INTERVAL_MS: u64 = 100;

/// Type of cover packet generated.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CoverType {
    /// Routes through network and returns to origin — verifies circuit health.
    Loop,
    /// Routes to random exit node and is discarded — indistinguishable from real.
    Drop,
    /// Addressed to real node with dummy payload.
    Decoy,
}

/// Cover traffic engine. Runs as a background Tokio task.
pub struct CoverEngine {
    node_id:  NodeId,
    tx:       mpsc::Sender<SphinxPacket>,
    interval: Duration,
}

impl CoverEngine {
    /// Create a new cover engine.
    /// `tx` receives the generated cover packets for injection into the outbound queue.
    pub fn new(node_id: NodeId, tx: mpsc::Sender<SphinxPacket>) -> Self {
        CoverEngine {
            node_id,
            tx,
            interval: Duration::from_millis(COVER_INTERVAL_MS),
        }
    }

    /// Spawn the cover traffic task. Runs until the sender is dropped.
    pub fn spawn(self) -> tokio::task::JoinHandle<()> {
        tokio::spawn(async move {
            let mut ticker = time::interval(self.interval);
            ticker.set_missed_tick_behavior(MissedTickBehavior::Delay);

            loop {
                ticker.tick().await;

                let cover_type = self.choose_cover_type();
                let pkt = self.generate_cover(cover_type);

                if self.tx.send(pkt).await.is_err() {
                    debug!("Cover engine: outbound channel closed, stopping");
                    break;
                }
            }
        })
    }

    fn choose_cover_type(&self) -> CoverType {
        // Weighted selection: 50% Drop, 30% Loop, 20% Decoy
        use rand::Rng;
        let r: u8 = rand::thread_rng().gen_range(0..100);
        match r {
            0..=49  => CoverType::Drop,
            50..=79 => CoverType::Loop,
            _       => CoverType::Decoy,
        }
    }

    fn generate_cover(&self, cover_type: CoverType) -> SphinxPacket {
        let mut rng = rand::thread_rng();
        let epoch = current_epoch();
        let mut pkt = SphinxPacket::new_cover(epoch, &mut rng);

        // All cover types look identical from outside.
        // The cover_type distinction is only meaningful for the generating node.
        debug!("Cover packet generated: {:?}", cover_type);
        pkt
    }
}
