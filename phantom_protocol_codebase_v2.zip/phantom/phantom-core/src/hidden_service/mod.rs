//! Hidden service protocol (Phantom Protocol Spec № 1, §8).
//!
//! A hidden service has a .phantom address derived from its public keys.
//! The server's IP is never exposed to clients, relays, or observers.
//!
//! ## Protocol overview
//!
//! ### Service side (server)
//! 1. Derive .phantom address from long-term signing keys
//! 2. Select N introduction nodes from DPKI
//! 3. Register with each introduction node via Sphinx⁺ circuit
//! 4. Publish introduction point list to DHT
//!
//! ### Client side
//! 1. Resolve .phantom address → introduction points (from DHT)
//! 2. Select a rendezvous node
//! 3. Send rendezvous request to service via an introduction point
//! 4. Service builds circuit to rendezvous node
//! 5. Both parties derive session key; all traffic flows through rendezvous
//!
//! ## Address format
//! `<52-char base32>.phantom`
//! Derived as: BLAKE3(pk_ed25519 || pk_kyber1024)[:32], base32-encoded

use std::collections::HashMap;
use std::net::SocketAddr;
use std::time::Instant;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{info, debug, warn};

use crate::crypto::{NodeId, HybridKeypair, current_epoch};
use crate::circuit::{Circuit, CircuitId, CircuitPath, CircuitHop, HopRole, CircuitBuilder};

// ── Address ───────────────────────────────────────────────────────────────

/// A .phantom hidden service address (32 bytes = 256 bits).
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PhantomAddress(pub [u8; 32]);

impl PhantomAddress {
    /// Derive a .phantom address from the service's public keys.
    /// Address = BLAKE3("phantom-hs-v1" || pk_ed || pk_kyber)[:32]
    pub fn derive(pk_ed: &[u8; 32], pk_kyber: &[u8]) -> Self {
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-hs-v1");
        h.update(pk_ed);
        h.update(pk_kyber);
        PhantomAddress(*h.finalize().as_bytes())
    }

    /// Encode as base32 string (suitable for display as `<addr>.phantom`).
    pub fn to_base32(&self) -> String {
        // Simple hex encoding for stub; production uses base32
        format!("{}.phantom", hex::encode(&self.0[..16]))
    }

    /// DHT key for looking up this service's introduction points.
    pub fn dht_key(&self, epoch: u32) -> [u8; 32] {
        let mut h = blake3::Hasher::new();
        h.update(b"hs");
        h.update(&self.0);
        h.update(&epoch.to_be_bytes());
        *h.finalize().as_bytes()
    }
}

impl std::fmt::Display for PhantomAddress {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.to_base32())
    }
}
impl std::fmt::Debug for PhantomAddress {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "PhantomAddress({})", hex::encode(&self.0[..8]))
    }
}

// ── Introduction points ───────────────────────────────────────────────────

/// An introduction point: a relay node that can forward connection requests
/// to the hidden service.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IntroductionPoint {
    /// The relay node acting as introduction point.
    pub node_id:      NodeId,
    /// Ephemeral public key for this introduction point session.
    pub pk_intro:     [u8; 32],
    /// Encrypted service descriptor (how to reach the service through this IP).
    pub enc_descriptor: Vec<u8>,
    /// Epoch this introduction point is valid for.
    pub epoch:        u32,
}

/// The published set of introduction points for a hidden service.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IntroductionPointSet {
    /// Service address.
    pub service_addr: PhantomAddress,
    /// Introduction points (typically 3-5).
    pub points:       Vec<IntroductionPoint>,
    /// Epoch.
    pub epoch:        u32,
    /// Ed25519 signature by the service's long-term key.
    pub sig:          [u8; 64],
}

impl IntroductionPointSet {
    /// Verify the signature on this introduction point set.
    pub fn verify(&self, pk_ed: &ed25519_dalek::VerifyingKey) -> bool {
        use ed25519_dalek::Verifier;
        let canonical = self.canonical_bytes();
        let sig = ed25519_dalek::Signature::from_bytes(&self.sig);
        pk_ed.verify(&canonical, &sig).is_ok()
    }

    fn canonical_bytes(&self) -> Vec<u8> {
        let mut v = Vec::new();
        v.extend_from_slice(b"phantom-hs-intro-v1");
        v.extend_from_slice(&self.service_addr.0);
        v.extend_from_slice(&self.epoch.to_be_bytes());
        for ip in &self.points {
            v.extend_from_slice(ip.node_id.as_bytes());
            v.extend_from_slice(&ip.pk_intro);
        }
        v
    }
}

// ── Rendezvous ────────────────────────────────────────────────────────────

/// A rendezvous cookie: a random value shared between client and service,
/// used to identify the rendezvous connection at the rendezvous node.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct RendezvousCookie(pub [u8; 20]);

impl RendezvousCookie {
    pub fn random() -> Self {
        use rand::RngCore;
        let mut c = [0u8; 20];
        rand::thread_rng().fill_bytes(&mut c);
        RendezvousCookie(c)
    }
}

/// A rendezvous request sent from client to service via an introduction point.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RendezvousRequest {
    /// Rendezvous node the client has selected.
    pub rendezvous_node: NodeId,
    /// Random cookie identifying this rendezvous at the rendezvous node.
    pub cookie:          RendezvousCookie,
    /// Client's ephemeral public key for session key agreement.
    pub client_pk_eph:   [u8; 32],
    /// Kyber-1024 ciphertext for PQ session key.
    pub client_ct_pq:    Vec<u8>,
}

/// Session key derived at rendezvous.
#[derive(Clone)]
pub struct RendezvousSession {
    pub cookie:         RendezvousCookie,
    pub session_key:    [u8; 32],
    pub service_addr:   PhantomAddress,
    pub established_at: Instant,
}

impl RendezvousSession {
    /// Derive a session key from the client and service ephemeral key material.
    pub fn derive(
        client_pk_eph:  &[u8; 32],
        service_sk_eph: &x25519_dalek::StaticSecret,
        cookie:         &RendezvousCookie,
        service_addr:   PhantomAddress,
    ) -> Self {
        let client_pk = x25519_dalek::PublicKey::from(*client_pk_eph);
        let dh = service_sk_eph.diffie_hellman(&client_pk);
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-rendezvous-session-v1");
        h.update(dh.as_bytes());
        h.update(&cookie.0);
        h.update(&service_addr.0);
        RendezvousSession {
            cookie:         *cookie,
            session_key:    *h.finalize().as_bytes(),
            service_addr,
            established_at: Instant::now(),
        }
    }
}

// ── Service descriptor ────────────────────────────────────────────────────

/// A hidden service descriptor (published to DHT, encrypted for the service's keys).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ServiceDescriptor {
    pub address:       PhantomAddress,
    pub pk_ed25519:    [u8; 32],
    pub intro_points:  IntroductionPointSet,
    pub epoch:         u32,
    /// Whether this service accepts only Extreme Mode connections.
    pub extreme_only:  bool,
}

// ── Hidden service manager ────────────────────────────────────────────────

/// Manages a running hidden service.
pub struct HiddenServiceManager {
    pub address:     PhantomAddress,
    keypair:         Arc<HybridKeypair>,
    intro_points:    Vec<IntroductionPoint>,
    /// Active rendezvous sessions keyed by cookie.
    sessions:        HashMap<RendezvousCookie, RendezvousSession>,
    /// Ephemeral key for rendezvous (refreshed per request).
    eph_key:         x25519_dalek::StaticSecret,
}

use std::sync::Arc;

impl HiddenServiceManager {
    /// Create a new hidden service.
    pub fn new(keypair: Arc<HybridKeypair>) -> Self {
        use pqcrypto_traits::kem::PublicKey as KP;
        let pk_ed    = keypair.ed25519_public();
        let pk_kyber = pqcrypto_kyber::kyber1024::keypair().0;
        let address  = PhantomAddress::derive(pk_ed.as_bytes(), pk_kyber.as_bytes());

        info!("Hidden service address: {}", address);

        HiddenServiceManager {
            address,
            keypair,
            intro_points: Vec::new(),
            sessions:     HashMap::new(),
            eph_key:      x25519_dalek::StaticSecret::random_from_rng(rand::thread_rng()),
        }
    }

    /// Register introduction points. In production: sends ESTABLISH_INTRO
    /// cells to each candidate relay via Sphinx⁺ circuits.
    pub fn set_intro_points(&mut self, points: Vec<IntroductionPoint>) {
        info!("Hidden service: registered {} introduction points", points.len());
        self.intro_points = points;
    }

    /// Build the signed introduction point set for DHT publication.
    pub fn build_intro_set(&self) -> IntroductionPointSet {
        let epoch = current_epoch();
        let mut set = IntroductionPointSet {
            service_addr: self.address,
            points:       self.intro_points.clone(),
            epoch,
            sig:          [0u8; 64],
        };
        let canonical = set.canonical_bytes();
        let sig = self.keypair.sign_ed25519(&canonical);
        set.sig = sig.to_bytes();
        set
    }

    /// Handle an incoming rendezvous request from a client.
    pub fn handle_rendezvous_request(
        &mut self,
        req: RendezvousRequest,
    ) -> Result<RendezvousSession, HiddenServiceError> {
        // Derive ephemeral key for this session
        let session = RendezvousSession::derive(
            req.client_pk_eph.as_ref().try_into()
                .map_err(|_| HiddenServiceError::InvalidKeyMaterial)?,
            &self.eph_key,
            &req.cookie,
            self.address,
        );

        // Rotate ephemeral key (forward secrecy per session)
        self.eph_key = x25519_dalek::StaticSecret::random_from_rng(rand::thread_rng());

        self.sessions.insert(req.cookie, session.clone());
        info!("Hidden service: rendezvous established (cookie={:?})", req.cookie);

        Ok(session)
    }

    /// Look up an existing session by cookie.
    pub fn get_session(&self, cookie: &RendezvousCookie) -> Option<&RendezvousSession> {
        self.sessions.get(cookie)
    }

    /// Purge expired sessions (older than 1 hour).
    pub fn purge_expired_sessions(&mut self) {
        self.sessions.retain(|_, s| {
            s.established_at.elapsed().as_secs() < 3600
        });
    }

    pub fn intro_point_count(&self) -> usize { self.intro_points.len() }
    pub fn session_count(&self) -> usize { self.sessions.len() }
}

#[derive(Debug, Error)]
pub enum HiddenServiceError {
    #[error("No introduction points registered")]
    NoIntroPoints,
    #[error("Rendezvous node unreachable: {0}")]
    RendezvousUnreachable(NodeId),
    #[error("Session not found for cookie")]
    SessionNotFound,
    #[error("Invalid key material")]
    InvalidKeyMaterial,
    #[error("Address resolution failed for {0}")]
    ResolutionFailed(PhantomAddress),
}
