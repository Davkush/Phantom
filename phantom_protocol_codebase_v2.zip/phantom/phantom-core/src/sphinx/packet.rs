//! Sphinx⁺ packet format definition.
//!
//! ```text
//! Sphinx⁺ Packet (1452 bytes total):
//! ┌─────────────────────────────────────────────────────┐
//! │  HEADER (304 bytes)                                 │
//! │  ├─ version        1 byte                           │
//! │  ├─ flags          1 byte                           │
//! │  ├─ epoch          4 bytes  (big-endian u32)        │
//! │  ├─ alpha_cl      32 bytes  (X25519 group element)  │
//! │  ├─ alpha_pq      96 bytes  (Kyber-1024 fragment)   │
//! │  ├─ beta_routing 128 bytes  (onion routing block)   │
//! │  ├─ gamma_mac     32 bytes  (BLAKE3 MAC)            │
//! │  ├─ c_batch        8 bytes  (batch commitment ref)  │
//! │  └─ pi_ref         2 bytes  (packet index in batch) │
//! ├─────────────────────────────────────────────────────┤
//! │  BODY (1148 bytes)                                  │
//! │  └─ payload      1148 bytes (ChaCha20-Poly1305)     │
//! └─────────────────────────────────────────────────────┘
//! ```

use bitflags::bitflags;
use serde::{Deserialize, Serialize};
use zeroize::ZeroizeOnDrop;

/// Total packet size in bytes. Fixed for all packets — real and cover.
pub const PACKET_SIZE: usize = 1452;
/// Header size in bytes.
pub const HEADER_SIZE: usize = 304;
/// Body (payload) size in bytes.
pub const BODY_SIZE: usize = 1148;

// Byte offsets within the header
const OFF_VERSION:      usize = 0;
const OFF_FLAGS:        usize = 1;
const OFF_EPOCH:        usize = 2;
const OFF_ALPHA_CL:     usize = 6;
const OFF_ALPHA_PQ:     usize = 38;
const OFF_BETA_ROUTING: usize = 134;
const OFF_GAMMA_MAC:    usize = 262;
const OFF_C_BATCH:      usize = 294;
const OFF_PI_REF:       usize = 302;
// Body starts at HEADER_SIZE = 304

/// Current protocol version byte.
pub const VERSION: u8 = 0x01;

bitflags! {
    /// Flags byte in the Sphinx⁺ header.
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
    pub struct PacketFlags: u8 {
        /// Packet is cover traffic — discard at exit node.
        const COVER   = 0b1000_0000;
        /// Single-Use Reply Block (SURB) packet.
        const REPLY   = 0b0100_0000;
        /// Standard forward packet.
        const FORWARD = 0b0010_0000;
        /// DC-Net mode cell (processed differently).
        const DC_CELL = 0b0001_0000;
    }
}

/// A Sphinx⁺ packet: a fixed-size byte array with typed accessor methods.
///
/// The inner bytes are the canonical serialised form — no additional
/// serialisation step is needed for transmission.
#[derive(Clone, ZeroizeOnDrop)]
pub struct SphinxPacket {
    pub(crate) bytes: [u8; PACKET_SIZE],
}

impl std::fmt::Debug for SphinxPacket {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SphinxPacket")
            .field("version", &self.version())
            .field("flags", &self.flags())
            .field("epoch", &self.epoch())
            .field("pi_ref", &self.pi_ref())
            .finish_non_exhaustive()
    }
}

impl SphinxPacket {
    /// Construct from raw bytes. Does NOT validate the packet.
    pub fn from_bytes(bytes: [u8; PACKET_SIZE]) -> Self {
        Self { bytes }
    }

    /// Access the raw bytes for transmission.
    pub fn as_bytes(&self) -> &[u8; PACKET_SIZE] {
        &self.bytes
    }

    // ── Header field accessors ────────────────────────────────────────────

    pub fn version(&self) -> u8 {
        self.bytes[OFF_VERSION]
    }

    pub fn flags(&self) -> PacketFlags {
        PacketFlags::from_bits_truncate(self.bytes[OFF_FLAGS])
    }

    pub fn epoch(&self) -> u32 {
        u32::from_be_bytes(self.bytes[OFF_EPOCH..OFF_EPOCH+4].try_into().unwrap())
    }

    pub fn alpha_classical(&self) -> &[u8; 32] {
        self.bytes[OFF_ALPHA_CL..OFF_ALPHA_CL+32].try_into().unwrap()
    }

    pub fn alpha_pq(&self) -> &[u8; 96] {
        self.bytes[OFF_ALPHA_PQ..OFF_ALPHA_PQ+96].try_into().unwrap()
    }

    pub fn beta_routing(&self) -> &[u8; 128] {
        self.bytes[OFF_BETA_ROUTING..OFF_BETA_ROUTING+128].try_into().unwrap()
    }

    pub fn gamma_mac(&self) -> &[u8; 32] {
        self.bytes[OFF_GAMMA_MAC..OFF_GAMMA_MAC+32].try_into().unwrap()
    }

    pub fn c_batch(&self) -> &[u8; 8] {
        self.bytes[OFF_C_BATCH..OFF_C_BATCH+8].try_into().unwrap()
    }

    pub fn pi_ref(&self) -> u16 {
        u16::from_be_bytes(self.bytes[OFF_PI_REF..OFF_PI_REF+2].try_into().unwrap())
    }

    pub fn payload(&self) -> &[u8; BODY_SIZE] {
        self.bytes[HEADER_SIZE..].try_into().unwrap()
    }

    // ── Mutable header writers ────────────────────────────────────────────

    pub fn set_version(&mut self, v: u8) { self.bytes[OFF_VERSION] = v; }
    pub fn set_flags(&mut self, f: PacketFlags) { self.bytes[OFF_FLAGS] = f.bits(); }
    pub fn set_epoch(&mut self, e: u32) { self.bytes[OFF_EPOCH..OFF_EPOCH+4].copy_from_slice(&e.to_be_bytes()); }
    pub fn set_alpha_classical(&mut self, a: &[u8; 32]) { self.bytes[OFF_ALPHA_CL..OFF_ALPHA_CL+32].copy_from_slice(a); }
    pub fn set_alpha_pq(&mut self, a: &[u8; 96]) { self.bytes[OFF_ALPHA_PQ..OFF_ALPHA_PQ+96].copy_from_slice(a); }
    pub fn set_beta_routing(&mut self, b: &[u8; 128]) { self.bytes[OFF_BETA_ROUTING..OFF_BETA_ROUTING+128].copy_from_slice(b); }
    pub fn set_gamma_mac(&mut self, m: &[u8; 32]) { self.bytes[OFF_GAMMA_MAC..OFF_GAMMA_MAC+32].copy_from_slice(m); }
    pub fn set_c_batch(&mut self, c: &[u8; 8]) { self.bytes[OFF_C_BATCH..OFF_C_BATCH+8].copy_from_slice(c); }
    pub fn set_pi_ref(&mut self, p: u16) { self.bytes[OFF_PI_REF..OFF_PI_REF+2].copy_from_slice(&p.to_be_bytes()); }
    pub fn set_payload(&mut self, p: &[u8; BODY_SIZE]) { self.bytes[HEADER_SIZE..].copy_from_slice(p); }

    /// Header bytes excluding the MAC field (used for MAC computation).
    pub fn header_without_mac(&self) -> Vec<u8> {
        let mut h = Vec::with_capacity(HEADER_SIZE - 32);
        h.extend_from_slice(&self.bytes[..OFF_GAMMA_MAC]);
        h.extend_from_slice(&self.bytes[OFF_GAMMA_MAC+32..HEADER_SIZE]);
        h
    }

    /// Is this a cover traffic packet?
    pub fn is_cover(&self) -> bool {
        self.flags().contains(PacketFlags::COVER)
    }

    /// Compute the expected MAC for this packet given a mac_key.
    pub fn compute_mac(&self, mac_key: &[u8; 32]) -> [u8; 32] {
        let payload_to_mac = self.header_without_mac();
        let mut h = blake3::Hasher::new_keyed(mac_key);
        h.update(&payload_to_mac);
        *h.finalize().as_bytes()
    }
}

/// Size assertions — verified at compile time.
const _: () = {
    assert!(OFF_VERSION == 0);
    assert!(OFF_FLAGS == 1);
    assert!(OFF_EPOCH == 2);
    assert!(OFF_ALPHA_CL == 6);
    assert!(OFF_ALPHA_PQ == 38);      // 6 + 32
    assert!(OFF_BETA_ROUTING == 134); // 38 + 96
    assert!(OFF_GAMMA_MAC == 262);    // 134 + 128
    assert!(OFF_C_BATCH == 294);      // 262 + 32
    assert!(OFF_PI_REF == 302);       // 294 + 8
    assert!(HEADER_SIZE == 304);      // 302 + 2
    assert!(PACKET_SIZE == 1452);     // 304 + 1148
};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_packet_size() {
        let pkt = SphinxPacket { bytes: [0u8; PACKET_SIZE] };
        assert_eq!(pkt.as_bytes().len(), PACKET_SIZE);
    }

    #[test]
    fn test_field_round_trip() {
        let mut pkt = SphinxPacket { bytes: [0u8; PACKET_SIZE] };
        pkt.set_version(VERSION);
        pkt.set_flags(PacketFlags::FORWARD);
        pkt.set_epoch(42);
        pkt.set_pi_ref(7);

        assert_eq!(pkt.version(), VERSION);
        assert_eq!(pkt.flags(), PacketFlags::FORWARD);
        assert_eq!(pkt.epoch(), 42);
        assert_eq!(pkt.pi_ref(), 7);
    }
}
