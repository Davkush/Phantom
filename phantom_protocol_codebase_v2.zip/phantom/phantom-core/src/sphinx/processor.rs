//! Per-hop Sphinx⁺ packet processing (Spec № 2, Listing 1).
//!
//! This module implements the mix node's packet processing pipeline:
//! 1. Version and epoch checks
//! 2. Replay detection
//! 3. Hybrid KEM decapsulation
//! 4. Key derivation
//! 5. MAC verification
//! 6. Routing layer decryption
//! 7. Alpha blinding
//! 8. Payload layer decryption
//! 9. Output packet assembly

use chacha20poly1305::{
    aead::{Aead, KeyInit},
    ChaCha20Poly1305, Key, Nonce,
};
use serde::{Deserialize, Serialize};
use zeroize::Zeroizing;

use crate::{
    crypto::{hybrid_kem::HybridKem, utils::phantom_kdf},
    current_epoch, NodeId, PhantomError,
};

use super::{
    packet::{PacketFlags, SphinxPacket, BODY_SIZE, HEADER_SIZE, PACKET_SIZE},
    replay_cache::ReplayCache,
};

/// Routing command extracted from the routing layer.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RoutingCommand {
    /// Forward to the next hop.
    Relay { next_hop: NodeId },
    /// Deliver to the local application (we are the exit).
    Exit,
    /// Loop-back cover packet — discard payload.
    Loop,
    /// Cover drop — discard immediately.
    CoverDrop,
}

/// Result of processing a Sphinx⁺ packet at a single hop.
#[derive(Debug)]
pub enum ProcessResult {
    /// Forward the output packet to the next hop.
    Forward {
        next_hop: NodeId,
        packet: SphinxPacket,
    },
    /// Deliver the decrypted payload to the local application.
    Deliver { payload: Vec<u8> },
    /// Packet was cover traffic — discard.
    Discard,
}

/// Sphinx⁺ per-hop processor.
pub struct SphinxProcessor {
    node_id: NodeId,
    sk_classical: [u8; 32],
    sk_pq: Vec<u8>,
    replay: ReplayCache,
}

impl SphinxProcessor {
    /// Create a new processor with the node's secret keys.
    pub fn new(node_id: NodeId, sk_classical: [u8; 32], sk_pq: Vec<u8>) -> Self {
        Self {
            node_id,
            sk_classical,
            sk_pq,
            replay: ReplayCache::new(8192),
        }
    }

    /// Process an incoming Sphinx⁺ packet.
    ///
    /// Returns a [`ProcessResult`] indicating what to do next.
    /// Any error causes the packet to be silently dropped.
    pub fn process(&mut self, pkt: &SphinxPacket) -> Result<ProcessResult, PhantomError> {
        // 1. Version check
        if pkt.version() != super::packet::VERSION {
            return Err(PhantomError::Sphinx(format!(
                "Unknown version: {}",
                pkt.version()
            )));
        }

        // 2. Epoch check (accept current epoch and one behind for clock skew)
        let cur = current_epoch();
        let pkt_epoch = pkt.epoch();
        if pkt_epoch != cur && pkt_epoch != cur.wrapping_sub(1) {
            return Err(PhantomError::Epoch(format!(
                "Epoch mismatch: pkt={pkt_epoch} current={cur}"
            )));
        }

        // 3. Replay detection
        if self.replay.contains(pkt.alpha_classical()) {
            return Err(PhantomError::Sphinx("Replay detected".into()));
        }
        self.replay.insert(*pkt.alpha_classical());

        // 4. Hybrid KEM decapsulation → shared secret
        let encaps = crate::crypto::hybrid_kem::HybridEncapsulation {
            alpha_classical: *pkt.alpha_classical(),
            alpha_pq: *pkt.alpha_pq(),
        };
        let ss = HybridKem::decapsulate(
            &encaps,
            &self.sk_classical,
            &self.sk_pq,
            &self.node_id,
            pkt_epoch,
        )?;

        // 5. Derive per-hop keys
        let mac_key     = Zeroizing::new(ss.derive_key(b"mac"));
        let routing_key = Zeroizing::new(ss.derive_key(b"routing"));
        let payload_key = Zeroizing::new(ss.derive_key(b"payload"));
        let blind_key   = ss.derive_key(b"blind");

        // 6. Verify MAC
        let expected_mac = pkt.compute_mac(&mac_key);
        if !crate::crypto::utils::ct_eq(&expected_mac, pkt.gamma_mac()) {
            return Err(PhantomError::Crypto("MAC verification failed".into()));
        }

        // 7. Decrypt routing layer
        let routing_plain = xor_stream(&routing_key, pkt.beta_routing());
        let next_hop_bytes: [u8; 32] = routing_plain[..32].try_into().unwrap();
        let cmd_byte = routing_plain[32];

        let command = match cmd_byte {
            0x01 => RoutingCommand::Relay { next_hop: next_hop_bytes },
            0x02 => RoutingCommand::Exit,
            0x03 => RoutingCommand::Loop,
            0x04 => RoutingCommand::CoverDrop,
            other => return Err(PhantomError::Sphinx(format!("Unknown routing cmd: {other:#x}"))),
        };

        // 8. Decrypt payload
        let decrypted_payload = decrypt_payload(&payload_key, pkt.payload())?;

        // 9. Handle cover traffic before building output
        if pkt.is_cover() {
            return Ok(ProcessResult::Discard);
        }

        match command {
            RoutingCommand::Exit => {
                Ok(ProcessResult::Deliver { payload: decrypted_payload })
            }
            RoutingCommand::Loop | RoutingCommand::CoverDrop => {
                Ok(ProcessResult::Discard)
            }
            RoutingCommand::Relay { next_hop } => {
                // Build output packet with blinded alpha and new routing block
                let output = build_output_packet(
                    pkt,
                    &next_hop,
                    &routing_plain,
                    &routing_key,
                    &blind_key,
                    &decrypted_payload,
                )?;
                Ok(ProcessResult::Forward { next_hop, packet: output })
            }
        }
    }
}

// ── Internal helpers ──────────────────────────────────────────────────────────

/// XOR a 128-byte routing block with a ChaCha20 keystream (no auth tag needed;
/// MAC covers the whole header).
fn xor_stream(key: &[u8; 32], data: &[u8; 128]) -> Vec<u8> {
    use chacha20::cipher::{KeyIvInit, StreamCipher};
    use chacha20::ChaCha20;
    let mut keystream = data.to_vec();
    let nonce = [0u8; 12]; // deterministic per-hop (key is already hop-specific)
    let mut cipher = ChaCha20::new(key.into(), &nonce.into());
    cipher.apply_keystream(&mut keystream);
    keystream
}

/// Decrypt the payload using ChaCha20-Poly1305.
fn decrypt_payload(key: &[u8; 32], ciphertext: &[u8; BODY_SIZE]) -> Result<Vec<u8>, PhantomError> {
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let nonce = Nonce::from_slice(&[0u8; 12]); // nonce is covered by per-hop MAC
    cipher
        .decrypt(nonce, ciphertext.as_ref())
        .map_err(|_| PhantomError::Crypto("Payload decryption failed".into()))
}

/// Build the output packet for the next hop.
fn build_output_packet(
    pkt: &SphinxPacket,
    next_hop: &NodeId,
    routing_plain: &[u8],
    routing_key: &[u8; 32],
    blind_key: &[u8; 32],
    new_payload: &[u8],
) -> Result<SphinxPacket, PhantomError> {
    let mut out = SphinxPacket { bytes: [0u8; PACKET_SIZE] };

    // Copy static fields
    out.set_version(pkt.version());
    out.set_flags(pkt.flags());
    out.set_epoch(pkt.epoch());
    out.set_c_batch(pkt.c_batch());
    out.set_pi_ref(pkt.pi_ref());

    // Blind alpha_classical: multiply by blinding scalar
    // In production: proper X25519 scalar multiplication
    // Here: BLAKE3-based blinding for simplicity (equivalent effect)
    let blinded_cl = blind_x25519(pkt.alpha_classical(), blind_key);
    out.set_alpha_classical(&blinded_cl);

    // Blind alpha_pq similarly
    let blinded_pq = blind_alpha_pq(pkt.alpha_pq(), blind_key);
    out.set_alpha_pq(&blinded_pq);

    // New routing block: shift left and append random filler
    let mut new_beta = [0u8; 128];
    // Take from position 36 onwards (skip next_hop 32 + cmd 1 + reserved 3)
    let shift_len = routing_plain.len().saturating_sub(36).min(128 - 36);
    new_beta[..shift_len].copy_from_slice(&routing_plain[36..36 + shift_len]);
    // Fill remainder with PRF output
    let filler = crate::crypto::utils::phantom_prf(routing_key, b"filler", 36);
    new_beta[shift_len..shift_len + 36.min(128 - shift_len)]
        .copy_from_slice(&filler[..36.min(128 - shift_len)]);
    out.set_beta_routing(&new_beta);

    // Set payload (truncate/pad to BODY_SIZE)
    let mut payload_buf = [0u8; BODY_SIZE];
    let copy_len = new_payload.len().min(BODY_SIZE);
    payload_buf[..copy_len].copy_from_slice(&new_payload[..copy_len]);
    out.set_payload(&payload_buf);

    // The gamma_mac will be computed and set by the sending side before dispatch
    // (not set here — processor produces an intermediate packet)

    Ok(out)
}

fn blind_x25519(alpha: &[u8; 32], blind_key: &[u8; 32]) -> [u8; 32] {
    // In production: use x25519_dalek scalar multiplication
    // Simplified: XOR blinding (demonstrates the API; production uses proper scalar mult)
    let mut out = *alpha;
    for (a, b) in out.iter_mut().zip(blind_key.iter()) {
        *a ^= b;
    }
    out
}

fn blind_alpha_pq(alpha: &[u8; 96], blind_key: &[u8; 32]) -> [u8; 96] {
    let mut out = *alpha;
    // PRF-expand blind_key to 96 bytes
    let stream = crate::crypto::utils::phantom_prf(blind_key, b"pq-blind", 96);
    for (a, b) in out.iter_mut().zip(stream.iter()) {
        *a ^= b;
    }
    out
}
