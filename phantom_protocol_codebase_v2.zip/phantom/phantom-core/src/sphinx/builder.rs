// phantom-core/src/sphinx/builder.rs
//! Sphinx⁺ packet construction (sender-side).

use chacha20poly1305::{
    aead::{Aead, KeyInit},
    ChaCha20Poly1305, Key, Nonce,
};
use rand::RngCore;

use crate::{
    crypto::{hybrid_kem::HybridKem, utils::phantom_prf},
    current_epoch, NodeId, PhantomError,
};

use super::packet::{PacketFlags, SphinxPacket, BODY_SIZE, PACKET_SIZE, VERSION};

/// A hop in a Sphinx⁺ circuit.
#[derive(Debug, Clone)]
pub struct HopSpec {
    pub node_id: NodeId,
    pub pk_classical: [u8; 32],
    pub pk_pq: Vec<u8>,
}

/// Builds Sphinx⁺ packets for a given circuit.
pub struct SphinxBuilder;

impl SphinxBuilder {
    /// Construct a Sphinx⁺ packet for a path through `hops`.
    ///
    /// `hops` must contain 1–5 hops. The last hop is the exit.
    /// `payload` is the plaintext to deliver (max [`BODY_SIZE`] bytes).
    pub fn build(
        hops: &[HopSpec],
        payload: &[u8],
        flags: PacketFlags,
        c_batch: [u8; 8],
        pi_ref: u16,
    ) -> Result<SphinxPacket, PhantomError> {
        if hops.is_empty() || hops.len() > 5 {
            return Err(PhantomError::Sphinx("Path must have 1–5 hops".into()));
        }
        if payload.len() > BODY_SIZE {
            return Err(PhantomError::Sphinx(format!(
                "Payload too large: {} > {}",
                payload.len(),
                BODY_SIZE
            )));
        }

        let epoch = current_epoch();

        // Encapsulate keys for each hop (innermost = last hop, outermost = first hop)
        let mut encaps_list = Vec::with_capacity(hops.len());
        let mut ss_list = Vec::with_capacity(hops.len());
        for hop in hops.iter() {
            let (ss, enc) = HybridKem::encapsulate(
                &hop.pk_classical,
                &hop.pk_pq,
                &hop.node_id,
                epoch,
            )?;
            encaps_list.push(enc);
            ss_list.push(ss);
        }

        // Encrypt payload in layers (innermost first)
        let mut encrypted_payload = [0u8; BODY_SIZE];
        encrypted_payload[..payload.len()].copy_from_slice(payload);

        for ss in ss_list.iter().rev() {
            let key = ss.derive_key(b"payload");
            let cipher = ChaCha20Poly1305::new(Key::from_slice(&key));
            let nonce = Nonce::from_slice(&[0u8; 12]);
            let ct = cipher
                .encrypt(nonce, &encrypted_payload[..])
                .map_err(|_| PhantomError::Crypto("Payload encryption failed".into()))?;
            let copy_len = ct.len().min(BODY_SIZE);
            encrypted_payload[..copy_len].copy_from_slice(&ct[..copy_len]);
        }

        // Build routing block for outermost hop
        let mut routing = [0u8; 128];
        routing[..32].copy_from_slice(&hops[1.min(hops.len()-1)].node_id);
        routing[32] = if hops.len() > 1 { 0x01 } else { 0x02 }; // Relay or Exit

        // XOR routing block with keystream
        let routing_key = ss_list[0].derive_key(b"routing");
        let routing_enc = xor_routing(&routing_key, &routing);

        // Assemble packet
        let mut pkt = SphinxPacket { bytes: [0u8; PACKET_SIZE] };
        pkt.set_version(VERSION);
        pkt.set_flags(flags);
        pkt.set_epoch(epoch);
        pkt.set_alpha_classical(&encaps_list[0].alpha_classical);
        pkt.set_alpha_pq(&encaps_list[0].alpha_pq);
        pkt.set_beta_routing(&routing_enc);
        pkt.set_c_batch(&c_batch);
        pkt.set_pi_ref(pi_ref);
        pkt.set_payload(&encrypted_payload);

        // Compute and set MAC
        let mac_key = ss_list[0].derive_key(b"mac");
        let mac = pkt.compute_mac(&mac_key);
        pkt.set_gamma_mac(&mac);

        Ok(pkt)
    }

    /// Build a cover traffic packet (structurally identical to a real packet).
    pub fn build_cover(
        hops: &[HopSpec],
        c_batch: [u8; 8],
        pi_ref: u16,
    ) -> Result<SphinxPacket, PhantomError> {
        let mut dummy_payload = [0u8; BODY_SIZE];
        rand::thread_rng().fill_bytes(&mut dummy_payload);
        Self::build(hops, &dummy_payload, PacketFlags::COVER | PacketFlags::FORWARD, c_batch, pi_ref)
    }
}

fn xor_routing(key: &[u8; 32], data: &[u8; 128]) -> [u8; 128] {
    use chacha20::cipher::{KeyIvInit, StreamCipher};
    use chacha20::ChaCha20;
    let mut out = *data;
    let nonce = [0u8; 12];
    let mut cipher = ChaCha20::new(key.into(), &nonce.into());
    cipher.apply_keystream(&mut out);
    out
}
