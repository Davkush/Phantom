//! Sphinx⁺ extended packet format (Phantom Protocol Spec № 2).
//!
//! Fixed 1452-byte packets. All packets are bitwise indistinguishable
//! from random bytes to any node not holding the appropriate key.

use blake3::Hasher;
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce, aead::{Aead, NewAead}};
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use thiserror::Error;
use zeroize::Zeroize;

use crate::crypto::{SharedSecret, HybridKeypair, NodeId, current_epoch};
use crate::{PACKET_SIZE, HEADER_SIZE, PAYLOAD_SIZE};

// ── Packet flags ──────────────────────────────────────────────────────────

/// Bit flags in the Sphinx⁺ header flags byte.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PacketFlags(pub u8);

impl PacketFlags {
    /// Cover traffic — discard at exit node.
    pub const COVER:   PacketFlags = PacketFlags(0b1000_0000);
    /// Single-Use Reply Block.
    pub const REPLY:   PacketFlags = PacketFlags(0b0100_0000);
    /// Standard forward packet.
    pub const FORWARD: PacketFlags = PacketFlags(0b0010_0000);
    /// DC-Net mode cell.
    pub const DC_CELL: PacketFlags = PacketFlags(0b0001_0000);

    pub fn is_cover(self)   -> bool { self.0 & 0b1000_0000 != 0 }
    pub fn is_forward(self) -> bool { self.0 & 0b0010_0000 != 0 }
    pub fn is_dc_cell(self) -> bool { self.0 & 0b0001_0000 != 0 }
}

// ── Routing commands ──────────────────────────────────────────────────────

/// Per-hop routing command decoded from the β_routing field.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RoutingCommand {
    /// Forward to next relay node.
    Relay { next_hop: NodeId },
    /// Deliver payload at exit node.
    Exit  { dest: [u8; 32] },
    /// Loop cover — return to origin.
    Loop,
    /// Discard (drop cover).
    Drop,
}

// ── Sphinx⁺ packet ────────────────────────────────────────────────────────

/// A fixed-size (1452-byte) Sphinx⁺ packet.
/// All fields are fixed-width; the struct serialises to exactly PACKET_SIZE bytes.
#[derive(Clone, Serialize, Deserialize)]
pub struct SphinxPacket {
    // ── Header (304 bytes) ────────────────────────────────────────────────
    /// Protocol version (0x01).
    pub version: u8,
    /// Packet flags (COVER | FORWARD | REPLY | DC_CELL).
    pub flags: PacketFlags,
    /// Network epoch (big-endian u32).
    pub epoch: u32,
    /// X25519 ephemeral group element (32 bytes).
    pub alpha_classical: [u8; 32],
    /// Kyber-1024 KEM fragment (96 bytes — first 96 of 1568-byte ciphertext).
    pub alpha_pq: [u8; 96],
    /// Onion-encrypted routing block (128 bytes).
    pub beta_routing: [u8; 128],
    /// BLAKE3 MAC over entire header (32 bytes).
    pub gamma_mac: [u8; 32],
    /// Batch commitment reference — first 8 bytes of the batch's Pedersen commitment hash.
    pub c_batch: [u8; 8],
    /// Packet index within its batch (big-endian u16).
    pub pi_ref: u16,

    // ── Body (1148 bytes) ─────────────────────────────────────────────────
    /// ChaCha20-Poly1305 encrypted payload (1148 bytes).
    pub payload: Box<[u8; PAYLOAD_SIZE]>,
}

impl SphinxPacket {
    /// Create a cover traffic packet (bitwise indistinguishable from a real packet).
    pub fn new_cover(epoch: u32, rng: &mut impl rand::RngCore) -> Self {
        let mut pkt = Self::random(rng);
        pkt.version = crate::PROTOCOL_VERSION;
        pkt.flags   = PacketFlags::COVER;
        pkt.epoch   = epoch;
        // Recompute MAC over the random fields
        pkt.gamma_mac = pkt.compute_mac(&[0u8; 32]); // cover uses zero mac key
        pkt
    }

    /// Generate a fully random packet (for testing / cover).
    pub fn random(rng: &mut impl rand::RngCore) -> Self {
        let mut alpha_cl = [0u8; 32];
        let mut alpha_pq = [0u8; 96];
        let mut beta     = [0u8; 128];
        let mut gamma    = [0u8; 32];
        let mut c_batch  = [0u8; 8];
        let mut payload  = Box::new([0u8; PAYLOAD_SIZE]);

        rng.fill_bytes(&mut alpha_cl);
        rng.fill_bytes(&mut alpha_pq);
        rng.fill_bytes(&mut beta);
        rng.fill_bytes(&mut gamma);
        rng.fill_bytes(&mut c_batch);
        rng.fill_bytes(payload.as_mut());

        SphinxPacket {
            version:         crate::PROTOCOL_VERSION,
            flags:           PacketFlags::FORWARD,
            epoch:           current_epoch(),
            alpha_classical: alpha_cl,
            alpha_pq:        alpha_pq,
            beta_routing:    beta,
            gamma_mac:       gamma,
            c_batch,
            pi_ref:          0,
            payload,
        }
    }

    /// Compute the BLAKE3 MAC over this packet header (excluding gamma_mac itself).
    pub fn compute_mac(&self, mac_key: &[u8; 32]) -> [u8; 32] {
        let mut h = blake3::Hasher::new_keyed(mac_key);
        h.update(&[self.version]);
        h.update(&[self.flags.0]);
        h.update(&self.epoch.to_be_bytes());
        h.update(&self.alpha_classical);
        h.update(&self.alpha_pq);
        h.update(&self.beta_routing);
        h.update(&self.c_batch);
        h.update(&self.pi_ref.to_be_bytes());
        *h.finalize().as_bytes()
    }

    /// Verify the MAC. Returns Err if invalid.
    pub fn verify_mac(&self, mac_key: &[u8; 32]) -> Result<(), SphinxError> {
        let expected = self.compute_mac(mac_key);
        if !constant_time_eq(&self.gamma_mac, &expected) {
            return Err(SphinxError::MacVerificationFailed);
        }
        Ok(())
    }

    /// Serialise to exactly PACKET_SIZE bytes.
    pub fn to_bytes(&self) -> [u8; PACKET_SIZE] {
        let mut buf = [0u8; PACKET_SIZE];
        buf[0]       = self.version;
        buf[1]       = self.flags.0;
        buf[2..6]    .copy_from_slice(&self.epoch.to_be_bytes());
        buf[6..38]   .copy_from_slice(&self.alpha_classical);
        buf[38..134] .copy_from_slice(&self.alpha_pq);
        buf[134..262].copy_from_slice(&self.beta_routing);
        buf[262..294].copy_from_slice(&self.gamma_mac);
        buf[294..302].copy_from_slice(&self.c_batch);
        buf[302..304].copy_from_slice(&self.pi_ref.to_be_bytes());
        buf[304..]   .copy_from_slice(self.payload.as_ref());
        buf
    }

    /// Deserialise from bytes.
    pub fn from_bytes(b: &[u8; PACKET_SIZE]) -> Result<Self, SphinxError> {
        if b[0] != crate::PROTOCOL_VERSION {
            return Err(SphinxError::UnknownVersion(b[0]));
        }
        let epoch = u32::from_be_bytes(b[2..6].try_into().unwrap());
        let pi_ref = u16::from_be_bytes(b[302..304].try_into().unwrap());

        Ok(SphinxPacket {
            version:         b[0],
            flags:           PacketFlags(b[1]),
            epoch,
            alpha_classical: b[6..38].try_into().unwrap(),
            alpha_pq:        b[38..134].try_into().unwrap(),
            beta_routing:    b[134..262].try_into().unwrap(),
            gamma_mac:       b[262..294].try_into().unwrap(),
            c_batch:         b[294..302].try_into().unwrap(),
            pi_ref,
            payload:         Box::new(b[304..].try_into().unwrap()),
        })
    }
}

// ── Per-hop processing ────────────────────────────────────────────────────

/// Result of processing one hop of a Sphinx⁺ packet.
pub enum HopResult {
    /// Forward the new packet to the next relay.
    Forward {
        next_hop: NodeId,
        packet:   SphinxPacket,
    },
    /// Deliver payload at exit.
    Exit {
        dest:    [u8; 32],
        payload: Vec<u8>,
    },
    /// Loop cover — re-inject into the network.
    Loop(SphinxPacket),
    /// Drop cover — discard silently.
    Drop,
}

/// Per-node replay cache: tracks alpha_classical values seen this epoch.
pub struct ReplayCache {
    seen: HashSet<[u8; 32]>,
    epoch: u32,
}

impl ReplayCache {
    pub fn new() -> Self {
        ReplayCache { seen: HashSet::new(), epoch: current_epoch() }
    }

    /// Returns true if this alpha has been seen before (replay detected).
    pub fn check_and_insert(&mut self, alpha: &[u8; 32]) -> bool {
        let cur = current_epoch();
        if cur != self.epoch {
            // New epoch — flush cache
            self.seen.clear();
            self.epoch = cur;
        }
        !self.seen.insert(*alpha)
    }
}

impl Default for ReplayCache {
    fn default() -> Self { Self::new() }
}

/// Process a single Sphinx⁺ hop.
///
/// # Errors
/// Returns `SphinxError` if:
/// - Version is unknown
/// - Epoch is out of range
/// - Replay detected  
/// - MAC verification fails
pub fn process_hop(
    pkt:     SphinxPacket,
    sk:      &HybridKeypair,
    replay:  &mut ReplayCache,
) -> Result<HopResult, SphinxError> {
    // 1. Version check
    if pkt.version != crate::PROTOCOL_VERSION {
        return Err(SphinxError::UnknownVersion(pkt.version));
    }

    // 2. Epoch check (allow current ± 1)
    let cur_epoch = current_epoch();
    if pkt.epoch.abs_diff(cur_epoch) > 1 {
        return Err(SphinxError::EpochOutOfRange { pkt: pkt.epoch, cur: cur_epoch });
    }

    // 3. Replay check
    if replay.check_and_insert(&pkt.alpha_classical) {
        return Err(SphinxError::ReplayDetected);
    }

    // 4. Derive shared secret (hybrid)
    let ct = crate::crypto::HybridCiphertext {
        eph_pk_x25519: pkt.alpha_classical,
        ct_kyber: {
            let mut full = Box::new([0u8; 1568]);
            full[..96].copy_from_slice(&pkt.alpha_pq);
            // Remaining bytes zero-padded — KEM fragment scheme
            full
        },
    };
    let shared = crate::crypto::hybrid_kem_decap(&ct, sk, pkt.epoch)
        .map_err(|_| SphinxError::KeyDecapFailed)?;

    // 5. Derive keys
    let mac_key     = shared.mac_key();
    let routing_key = shared.routing_key();
    let payload_key = shared.payload_key();
    let blind       = shared.blind_scalar();

    // 6. Verify MAC
    pkt.verify_mac(&mac_key)?;

    // 7. Decrypt routing layer
    let routing_plain = xor_keystream(&pkt.beta_routing, &routing_key);
    let command = decode_routing_command(&routing_plain)?;

    // Build next routing block (shift left, append PRNG filler)
    let mut new_beta = [0u8; 128];
    let shift = 36usize.min(routing_plain.len());
    if routing_plain.len() > shift {
        let remaining = routing_plain.len() - shift;
        new_beta[..remaining].copy_from_slice(&routing_plain[shift..]);
    }
    // Fill remainder with deterministic PRNG output keyed by routing_key
    let filler_start = routing_plain.len().saturating_sub(shift);
    let filler_bytes = prng_fill(&routing_key, filler_start, 128 - filler_start);
    new_beta[filler_start..].copy_from_slice(&filler_bytes);

    // 8. Blind alpha for next hop (unlinkability)
    let new_alpha_cl = blind_x25519(&pkt.alpha_classical, &blind);

    // 9. Decrypt payload layer
    let new_payload = chacha20_decrypt(&payload_key, pkt.payload.as_ref())?;

    // 10. Build output packet
    let mut out = SphinxPacket {
        version:         crate::PROTOCOL_VERSION,
        flags:           pkt.flags,
        epoch:           pkt.epoch,
        alpha_classical: new_alpha_cl,
        alpha_pq:        pkt.alpha_pq, // updated by sender in full impl
        beta_routing:    new_beta,
        gamma_mac:       [0u8; 32],    // recomputed below
        c_batch:         pkt.c_batch,
        pi_ref:          pkt.pi_ref,
        payload:         {
            let mut p = Box::new([0u8; PAYLOAD_SIZE]);
            let copy_len = new_payload.len().min(PAYLOAD_SIZE);
            p[..copy_len].copy_from_slice(&new_payload[..copy_len]);
            p
        },
    };

    // Compute new MAC with next-hop's key (placeholder — real impl derives next-hop key)
    out.gamma_mac = out.compute_mac(&mac_key);

    match command {
        RoutingCommand::Relay { next_hop } => Ok(HopResult::Forward { next_hop, packet: out }),
        RoutingCommand::Exit  { dest }     => Ok(HopResult::Exit { dest, payload: new_payload }),
        RoutingCommand::Loop               => Ok(HopResult::Loop(out)),
        RoutingCommand::Drop               => Ok(HopResult::Drop),
    }
}

// ── Internal helpers ──────────────────────────────────────────────────────

fn decode_routing_command(data: &[u8]) -> Result<RoutingCommand, SphinxError> {
    if data.len() < 36 {
        return Err(SphinxError::RoutingDecodeError);
    }
    let cmd_byte = data[32];
    match cmd_byte {
        0x01 => {
            let mut hop = [0u8; 32];
            hop.copy_from_slice(&data[..32]);
            Ok(RoutingCommand::Relay { next_hop: NodeId(hop) })
        }
        0x02 => {
            let mut dest = [0u8; 32];
            dest.copy_from_slice(&data[..32]);
            Ok(RoutingCommand::Exit { dest })
        }
        0x03 => Ok(RoutingCommand::Loop),
        0x04 => Ok(RoutingCommand::Drop),
        _    => Err(SphinxError::RoutingDecodeError),
    }
}

fn xor_keystream(data: &[u8], key: &[u8; 32]) -> Vec<u8> {
    // Simple ChaCha20 keystream XOR (no AEAD — routing uses stream cipher)
    use chacha20poly1305::cipher::{KeyIvInit, StreamCipher};
    type ChaCha20 = chacha20poly1305::ChaCha20;
    let nonce_bytes = [0u8; 12];
    let mut cipher = ChaCha20::new(Key::from_slice(key), Nonce::from_slice(&nonce_bytes));
    let mut out = data.to_vec();
    cipher.apply_keystream(&mut out);
    out
}

fn chacha20_decrypt(key: &[u8; 32], data: &[u8]) -> Result<Vec<u8>, SphinxError> {
    use chacha20poly1305::aead::Aead;
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let nonce   = Nonce::from_slice(&[0u8; 12]);
    cipher.decrypt(nonce, data).map_err(|_| SphinxError::PayloadDecryptFailed)
}

fn prng_fill(key: &[u8; 32], offset: usize, len: usize) -> Vec<u8> {
    let mut h = blake3::Hasher::new_keyed(key);
    h.update(b"phantom-filler");
    h.update(&(offset as u64).to_be_bytes());
    let mut out = vec![0u8; len];
    h.finalize_xof().fill(&mut out);
    out
}

fn blind_x25519(pk_bytes: &[u8; 32], blind: &[u8; 32]) -> [u8; 32] {
    // Scalar multiplication: pk * blind (mod group order)
    // Simplified — real impl uses curve25519-dalek point ops
    let mut result = [0u8; 32];
    for i in 0..32 {
        result[i] = pk_bytes[i] ^ blind[i]; // placeholder — use proper scalar mult
    }
    result
}

fn constant_time_eq(a: &[u8; 32], b: &[u8; 32]) -> bool {
    use std::hint::black_box;
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    black_box(diff) == 0
}

/// Sphinx⁺ processing errors.
#[derive(Debug, Error)]
pub enum SphinxError {
    #[error("Unknown protocol version: {0:#04x}")]
    UnknownVersion(u8),
    #[error("Epoch out of range: packet={pkt}, current={cur}")]
    EpochOutOfRange { pkt: u32, cur: u32 },
    #[error("Replay attack detected")]
    ReplayDetected,
    #[error("Key decapsulation failed")]
    KeyDecapFailed,
    #[error("MAC verification failed")]
    MacVerificationFailed,
    #[error("Payload decryption failed")]
    PayloadDecryptFailed,
    #[error("Routing block decode error")]
    RoutingDecodeError,
    #[error("Serialisation error")]
    SerialiseError,
}
