//! Replay attack prevention cache.
//!
//! Stores seen packet identifiers (alpha_classical values) per epoch.
//! Old epoch entries are automatically evicted.

use lru::LruCache;
use std::num::NonZeroUsize;

use crate::current_epoch;

/// LRU-based replay detection cache.
pub struct ReplayCache {
    /// Current epoch entries: alpha_classical → epoch
    cache: LruCache<[u8; 32], u32>,
}

impl ReplayCache {
    /// Create a new cache with `capacity` entries.
    pub fn new(capacity: usize) -> Self {
        Self {
            cache: LruCache::new(NonZeroUsize::new(capacity).unwrap()),
        }
    }

    /// Check if this alpha has been seen before.
    pub fn contains(&self, alpha: &[u8; 32]) -> bool {
        self.cache.contains(alpha)
    }

    /// Mark this alpha as seen for the current epoch.
    pub fn insert(&mut self, alpha: [u8; 32]) {
        self.cache.put(alpha, current_epoch());
    }

    /// Evict entries from expired epochs. Call once per epoch transition.
    pub fn evict_expired(&mut self) {
        let cur = current_epoch();
        // LruCache doesn't support direct eviction by value, so we rebuild
        // Only necessary in very long-running nodes; LRU handles pressure otherwise.
        let to_remove: Vec<[u8; 32]> = self
            .cache
            .iter()
            .filter(|(_, &epoch)| epoch < cur.saturating_sub(1))
            .map(|(k, _)| *k)
            .collect();
        for k in to_remove {
            self.cache.pop(&k);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_replay_detection() {
        let mut cache = ReplayCache::new(100);
        let alpha = [0x42u8; 32];

        assert!(!cache.contains(&alpha));
        cache.insert(alpha);
        assert!(cache.contains(&alpha));
    }

    #[test]
    fn test_different_alphas() {
        let mut cache = ReplayCache::new(100);
        let a1 = [0x01u8; 32];
        let a2 = [0x02u8; 32];

        cache.insert(a1);
        assert!(cache.contains(&a1));
        assert!(!cache.contains(&a2));
    }
}
