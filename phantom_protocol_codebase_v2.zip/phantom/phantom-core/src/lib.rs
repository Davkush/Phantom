//! # phantom-core
//!
//! Core cryptographic primitives, packet format, and routing for Phantom Protocol.
//!
//! ## Modules
//! - [`crypto`]         — hybrid post-quantum key exchange, hashing, node identity
//! - [`sphinx`]         — Sphinx⁺ extended packet format (fixed 1452-byte packets)
//! - [`mix`]            — mix node batch processor with ZK-verifiable shuffle
//! - [`cover`]          — mandatory constant-rate cover traffic engine
//! - [`transport`]      — QUIC-based packet transport with traffic obfuscation
//! - [`circuit`]        — multi-hop circuit construction (telescoping key exchange)
//! - [`hidden_service`] — .phantom hidden service address derivation and rendezvous
//! - [`reputation`]     — node reputation tracking and weighted circuit path selection

#![forbid(unsafe_code)]
#![warn(missing_docs)]

pub mod crypto;
pub mod sphinx;
pub mod mix;
pub mod cover;
pub mod transport;
pub mod circuit;
pub mod hidden_service;
pub mod reputation;

/// Current Sphinx⁺ protocol version byte.
pub const PROTOCOL_VERSION: u8 = 0x01;

/// Fixed Sphinx⁺ packet size in bytes (1 Ethernet MTU minus IP/UDP/QUIC overhead).
pub const PACKET_SIZE: usize = 1452;

/// Sphinx⁺ header size in bytes.
pub const HEADER_SIZE: usize = 304;

/// Sphinx⁺ payload size in bytes.
pub const PAYLOAD_SIZE: usize = PACKET_SIZE - HEADER_SIZE;

/// Network epoch duration in seconds (1 hour).
pub const EPOCH_DURATION_SECS: u64 = 3600;

/// Minimum mix batch size (padded with loop cover if not reached).
pub const MIN_BATCH_SIZE: usize = 32;

/// Maximum mix batch size.
pub const MAX_BATCH_SIZE: usize = 512;

/// Mix batch collection window in milliseconds.
pub const BATCH_WINDOW_MS: u64 = 200;

/// Re-exports.
pub use crypto::{HybridKeypair, NodeId, SharedSecret};
pub use sphinx::{SphinxPacket, PacketFlags, HopResult};
pub use circuit::{Circuit, CircuitPath, CircuitBuilder, CircuitPool, CircuitId};
pub use hidden_service::{PhantomAddress, HiddenServiceManager, RendezvousCookie};
pub use reputation::ReputationStore;
