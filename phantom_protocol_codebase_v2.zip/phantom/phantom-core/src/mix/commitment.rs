//! Pedersen commitments over BLS12-381 G1 for Sphinx⁺ batch verification.
//!
//! Each packet in a batch is committed to before processing (C_in) and after
//! processing (C_out). The ZK shuffle proof proves C_out is a correct
//! permutation of C_in without revealing the permutation.

use ark_bls12_381::{Fr, G1Affine, G1Projective};
use ark_ec::Group;
use ark_ff::{Field, PrimeField, UniformRand};
use ark_serialize::{CanonicalDeserialize, CanonicalSerialize};
use rand::thread_rng;
use serde::{Deserialize, Serialize};

use crate::{sphinx::packet::SphinxPacket, PhantomError};

/// A Pedersen commitment to a single packet's content.
///
/// `com(p; r) = r*G + H(header)*H1 + H(payload)*H2`
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PacketCommitment {
    /// The G1 commitment point (compressed, 48 bytes).
    pub point: Vec<u8>,
    /// The blinding factor (kept secret by the committer).
    #[serde(skip)]
    pub blinding: Option<Vec<u8>>,
}

impl PacketCommitment {
    /// Commit to a packet using a random blinding factor.
    pub fn commit(packet: &SphinxPacket, crs: &CommitmentCRS) -> (Self, Fr) {
        let mut rng = thread_rng();
        let r = Fr::rand(&mut rng);
        let point = crs.commit_packet(packet, &r);

        let mut point_bytes = Vec::new();
        point.serialize_compressed(&mut point_bytes).unwrap();

        let mut r_bytes = Vec::new();
        r.serialize_compressed(&mut r_bytes).unwrap();

        (
            Self {
                point: point_bytes,
                blinding: Some(r_bytes),
            },
            r,
        )
    }

    /// Deserialise the commitment point.
    pub fn as_g1(&self) -> Result<G1Affine, PhantomError> {
        G1Affine::deserialize_compressed(&self.point[..])
            .map_err(|e| PhantomError::Crypto(format!("G1 deserialise: {e}")))
    }
}

/// A vector of commitments covering an entire batch.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchCommitment {
    /// Commitment to each packet in the batch.
    pub commitments: Vec<PacketCommitment>,
    /// BLAKE3 hash of all commitment points (for DHT keying).
    pub batch_hash: [u8; 32],
    /// Epoch this batch belongs to.
    pub epoch: u32,
    /// Node that created this commitment.
    pub node_id: [u8; 32],
}

impl BatchCommitment {
    /// Create a batch commitment from a slice of packets.
    pub fn from_packets(
        packets: &[SphinxPacket],
        crs: &CommitmentCRS,
        epoch: u32,
        node_id: [u8; 32],
    ) -> (Self, Vec<Fr>) {
        let mut commitments = Vec::with_capacity(packets.len());
        let mut blindings = Vec::with_capacity(packets.len());

        for pkt in packets {
            let (com, r) = PacketCommitment::commit(pkt, crs);
            commitments.push(com);
            blindings.push(r);
        }

        // Hash all commitment points for DHT key
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-batch-v1");
        for com in &commitments {
            h.update(&com.point);
        }
        let batch_hash = *h.finalize().as_bytes();

        (
            Self { commitments, batch_hash, epoch, node_id },
            blindings,
        )
    }
}

/// Common Reference String for Pedersen commitments.
/// Contains BLS12-381 G1 generators.
#[derive(Debug, Clone)]
pub struct CommitmentCRS {
    pub g:  G1Affine,  // main generator
    pub h1: G1Affine,  // header hash component
    pub h2: G1Affine,  // payload hash component
    pub h3: G1Affine,  // batch_id component
    pub h4: G1Affine,  // index component
}

impl CommitmentCRS {
    /// Derive the CRS deterministically from the network genesis hash.
    /// In production this would be from a trusted setup ceremony (or STARK).
    pub fn from_genesis(genesis_hash: &[u8; 32]) -> Self {
        // Derive generators via hash-to-curve (simplified: scalar mult of base)
        let base = G1Projective::generator();
        let scalar_from = |label: &[u8]| -> Fr {
            let mut h = blake3::Hasher::new_keyed(genesis_hash);
            h.update(label);
            let bytes = h.finalize();
            Fr::from_le_bytes_mod_order(bytes.as_bytes())
        };

        Self {
            g:  (base * scalar_from(b"g")).into(),
            h1: (base * scalar_from(b"h1")).into(),
            h2: (base * scalar_from(b"h2")).into(),
            h3: (base * scalar_from(b"h3")).into(),
            h4: (base * scalar_from(b"h4")).into(),
        }
    }

    /// Commit to a packet's content.
    pub fn commit_packet(&self, packet: &SphinxPacket, r: &Fr) -> G1Affine {
        let g  = G1Projective::from(self.g);
        let h1 = G1Projective::from(self.h1);
        let h2 = G1Projective::from(self.h2);

        // Hash header and payload to field elements
        let header_scalar = Fr::from_le_bytes_mod_order(
            blake3::hash(&packet.as_bytes()[..crate::sphinx::packet::HEADER_SIZE]).as_bytes()
        );
        let payload_scalar = Fr::from_le_bytes_mod_order(
            blake3::hash(packet.payload()).as_bytes()
        );

        let point = g * r + h1 * header_scalar + h2 * payload_scalar;
        point.into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sphinx::packet::{PacketFlags, SphinxPacket, PACKET_SIZE};

    fn make_test_packet() -> SphinxPacket {
        let mut pkt = SphinxPacket { bytes: [0u8; PACKET_SIZE] };
        pkt.set_flags(PacketFlags::FORWARD);
        pkt.set_epoch(1);
        pkt
    }

    #[test]
    fn test_commitment_deterministic_given_same_r() {
        let crs = CommitmentCRS::from_genesis(&[0u8; 32]);
        let pkt = make_test_packet();
        let r = Fr::from(42u64);

        let p1 = crs.commit_packet(&pkt, &r);
        let p2 = crs.commit_packet(&pkt, &r);
        assert_eq!(p1, p2);
    }

    #[test]
    fn test_different_packets_different_commitments() {
        let crs = CommitmentCRS::from_genesis(&[0u8; 32]);
        let r = Fr::from(1u64);

        let mut pkt1 = make_test_packet();
        let mut pkt2 = make_test_packet();
        pkt2.set_epoch(99); // different packet

        let p1 = crs.commit_packet(&pkt1, &r);
        let p2 = crs.commit_packet(&pkt2, &r);
        assert_ne!(p1, p2);
    }
}
