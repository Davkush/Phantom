//! Mix node batch processor with ZK-verifiable shuffle (Phantom Protocol Spec № 2).
//!
//! Implements the full batch lifecycle:
//! 1. Collect packets during BATCH_WINDOW_MS
//! 2. Compute and publish C_in (Pedersen commitment over input batch)
//! 3. Process each packet (Sphinx⁺ per-hop decryption)
//! 4. Shuffle output
//! 5. Compute and publish C_out
//! 6. Generate ZK shuffle proof (BayerGroth argument)
//! 7. Publish proof; dispatch output packets

use std::collections::HashMap;
use std::time::{Duration, Instant};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{info, warn, debug};

use crate::crypto::{HybridKeypair, NodeId, current_epoch};
use crate::sphinx::{SphinxPacket, HopResult, ReplayCache, process_hop};
use crate::{MIN_BATCH_SIZE, MAX_BATCH_SIZE, BATCH_WINDOW_MS};

// ── Pedersen commitment (simplified over BLS12-381 G1) ────────────────────

/// A Pedersen commitment to a single packet.
/// In the full impl this is a BLS12-381 G1Affine point.
/// Here represented as 48 bytes (compressed G1 point size).
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Commitment(pub [u8; 48]);

impl Commitment {
    /// Commit to a packet using BLAKE3 (placeholder for full Pedersen commitment).
    /// Real implementation: com(p; r) = r*G + H(p.header)*H1 + H(p.payload)*H2
    pub fn commit(pkt: &SphinxPacket, blinding: &[u8; 32]) -> Self {
        let mut h = blake3::Hasher::new_keyed(blinding);
        h.update(&pkt.to_bytes());
        let digest = h.finalize();
        let mut out = [0u8; 48];
        out[..32].copy_from_slice(digest.as_bytes());
        Commitment(out)
    }
}

// ── ZK shuffle proof ──────────────────────────────────────────────────────

/// A Bayer-Groth verifiable shuffle proof.
/// Proves that output batch is a correct permutation+decryption of input batch.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ShuffleProof {
    /// Node that generated this proof.
    pub node_id:    NodeId,
    /// Epoch.
    pub epoch:      u32,
    /// Batch size.
    pub batch_size: u32,
    /// BLAKE3(C_in).
    pub c_in_hash:  [u8; 32],
    /// BLAKE3(C_out).
    pub c_out_hash: [u8; 32],
    /// Fiat-Shamir challenge scalar (32 bytes).
    pub challenge:  [u8; 32],
    /// Response vector — polynomial evaluation (simplified: Vec<[u8;32]>).
    pub response_b: Vec<[u8; 32]>,
    /// Blinding differences.
    pub response_t: Vec<[u8; 32]>,
    /// Unix timestamp of proof generation.
    pub timestamp:  u64,
    /// Ed25519 signature over canonical bytes.
    pub sig_ed25519: [u8; 64],
}

impl ShuffleProof {
    /// Verify the proof. Returns Ok(()) if valid.
    /// Full implementation uses Bayer-Groth multi-exponentiation argument.
    /// This stub verifies the Fiat-Shamir challenge and signature.
    pub fn verify(
        &self,
        c_in:   &[Commitment],
        c_out:  &[Commitment],
        pk_ed:  &ed25519_dalek::VerifyingKey,
    ) -> Result<(), MixError> {
        // 1. Verify batch size
        if self.batch_size as usize != c_in.len() || c_in.len() != c_out.len() {
            return Err(MixError::ProofBatchSizeMismatch);
        }

        // 2. Recompute Fiat-Shamir challenge
        let expected_challenge = compute_fs_challenge(
            self.epoch,
            &self.node_id,
            c_in,
            c_out,
        );
        if !constant_time_eq_32(&self.challenge, &expected_challenge) {
            return Err(MixError::ProofChallengeMismatch);
        }

        // 3. Verify Ed25519 signature
        use ed25519_dalek::Verifier;
        let canonical = self.canonical_bytes();
        let sig = ed25519_dalek::Signature::from_bytes(&self.sig_ed25519);
        pk_ed.verify(&canonical, &sig)
            .map_err(|_| MixError::ProofSignatureInvalid)?;

        // 4. Full Bayer-Groth verification would happen here.
        // Placeholder: accept if challenge and signature are valid.
        Ok(())
    }

    fn canonical_bytes(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(256);
        v.extend_from_slice(b"phantom-shuffle-proof-v1");
        v.extend_from_slice(self.node_id.as_bytes());
        v.extend_from_slice(&self.epoch.to_be_bytes());
        v.extend_from_slice(&self.batch_size.to_be_bytes());
        v.extend_from_slice(&self.c_in_hash);
        v.extend_from_slice(&self.c_out_hash);
        v.extend_from_slice(&self.challenge);
        v.extend_from_slice(&self.timestamp.to_be_bytes());
        v
    }
}

// ── Batch commitment ──────────────────────────────────────────────────────

/// A committed input or output batch.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BatchCommitment {
    /// BLAKE3 of all commitments concatenated.
    pub hash:        [u8; 32],
    /// Individual per-packet commitments.
    pub commitments: Vec<Commitment>,
    /// Epoch.
    pub epoch:       u32,
    /// Batch ID.
    pub batch_id:    [u8; 32],
    /// Unix timestamp.
    pub timestamp:   u64,
}

impl BatchCommitment {
    pub fn compute(packets: &[SphinxPacket], blindings: &[[u8; 32]], batch_id: [u8; 32], epoch: u32) -> Self {
        let commitments: Vec<Commitment> = packets.iter()
            .zip(blindings.iter())
            .map(|(pkt, blind)| Commitment::commit(pkt, blind))
            .collect();

        let mut h = blake3::Hasher::new();
        for c in &commitments {
            h.update(&c.0);
        }
        let hash = *h.finalize().as_bytes();

        BatchCommitment {
            hash,
            commitments,
            epoch,
            batch_id,
            timestamp: unix_now(),
        }
    }
}

// ── Mix node ──────────────────────────────────────────────────────────────

/// A stateful mix node that processes batches of Sphinx⁺ packets.
pub struct MixNode {
    /// Node keypair.
    pub keypair:      HybridKeypair,
    /// Replay cache for this epoch.
    pub replay_cache: ReplayCache,
    /// Batch counter (monotonically increasing).
    batch_counter:    u64,
    /// Pending packets waiting for batch close.
    pending:          Vec<SphinxPacket>,
    /// Batch collection start time.
    batch_start:      Instant,
}

impl MixNode {
    /// Create a new mix node.
    pub fn new(keypair: HybridKeypair) -> Self {
        MixNode {
            keypair,
            replay_cache: ReplayCache::new(),
            batch_counter: 0,
            pending: Vec::with_capacity(MAX_BATCH_SIZE),
            batch_start: Instant::now(),
        }
    }

    /// Ingest a packet into the pending batch.
    /// Returns true if the batch should be closed (max size reached).
    pub fn ingest(&mut self, pkt: SphinxPacket) -> bool {
        if self.pending.len() < MAX_BATCH_SIZE {
            self.pending.push(pkt);
        }
        self.pending.len() >= MAX_BATCH_SIZE
    }

    /// Returns true if the batch collection window has elapsed.
    pub fn window_elapsed(&self) -> bool {
        self.batch_start.elapsed() > Duration::from_millis(BATCH_WINDOW_MS)
    }

    /// Process the current batch. Returns the output packets and shuffle proof.
    pub fn process_batch(&mut self) -> Result<BatchOutput, MixError> {
        let epoch = current_epoch();
        let batch_id = self.compute_batch_id(epoch);

        // Pad to MIN_BATCH_SIZE with loop cover
        let mut rng = rand::thread_rng();
        while self.pending.len() < MIN_BATCH_SIZE {
            self.pending.push(SphinxPacket::new_cover(epoch, &mut rng));
        }

        let input_packets = std::mem::take(&mut self.pending);
        let n = input_packets.len();

        // Generate blinding factors for C_in
        let blindings_in: Vec<[u8; 32]> = (0..n).map(|_| {
            let mut b = [0u8; 32];
            rng.fill_bytes(&mut b);
            b
        }).collect();

        // Compute C_in (MUST happen before processing)
        let c_in = BatchCommitment::compute(&input_packets, &blindings_in, batch_id, epoch);
        info!("Batch {} C_in computed, {} packets", self.batch_counter, n);

        // Process each packet
        let mut output_packets = Vec::with_capacity(n);
        let mut permutation: Vec<usize> = (0..n).collect();

        // Track which processed successfully
        let mut processed_indices = Vec::new();
        for (i, pkt) in input_packets.into_iter().enumerate() {
            match process_hop(pkt, &self.keypair, &mut self.replay_cache) {
                Ok(HopResult::Forward { next_hop: _, packet }) => {
                    output_packets.push(packet);
                    processed_indices.push(i);
                }
                Ok(HopResult::Loop(pkt)) => {
                    output_packets.push(pkt);
                    processed_indices.push(i);
                }
                Ok(HopResult::Drop) => {
                    // Cover packet — don't include in output
                    debug!("Dropped cover packet at index {}", i);
                }
                Ok(HopResult::Exit { .. }) => {
                    // Exit packets handled by upper layer
                    debug!("Exit packet at index {}", i);
                }
                Err(e) => {
                    warn!("Packet processing error at index {}: {}", i, e);
                }
            }
        }

        // Shuffle output (Fisher-Yates)
        use rand::seq::SliceRandom;
        output_packets.shuffle(&mut rng);

        // Generate blinding factors for C_out
        let blindings_out: Vec<[u8; 32]> = (0..output_packets.len()).map(|_| {
            let mut b = [0u8; 32];
            rng.fill_bytes(&mut b);
            b
        }).collect();

        // Compute C_out
        let c_out = BatchCommitment::compute(&output_packets, &blindings_out, batch_id, epoch);

        // Generate shuffle proof
        let proof = self.generate_proof(&c_in, &c_out, epoch, batch_id)?;

        self.batch_counter += 1;
        self.batch_start = Instant::now();

        info!(
            "Batch {} complete: {} in → {} out, proof generated",
            self.batch_counter - 1,
            n,
            output_packets.len()
        );

        Ok(BatchOutput {
            batch_id,
            c_in,
            c_out,
            packets: output_packets,
            proof,
            epoch,
        })
    }

    fn compute_batch_id(&self, epoch: u32) -> [u8; 32] {
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-batch-id-v1");
        h.update(self.keypair.node_id.as_bytes());
        h.update(&epoch.to_be_bytes());
        h.update(&self.batch_counter.to_be_bytes());
        *h.finalize().as_bytes()
    }

    fn generate_proof(
        &self,
        c_in:     &BatchCommitment,
        c_out:    &BatchCommitment,
        epoch:    u32,
        batch_id: [u8; 32],
    ) -> Result<ShuffleProof, MixError> {
        // Compute Fiat-Shamir challenge
        let challenge = compute_fs_challenge(
            epoch,
            &self.keypair.node_id,
            &c_in.commitments,
            &c_out.commitments,
        );

        // Response vectors (simplified — real impl uses Bayer-Groth multiexp argument)
        let n = c_in.commitments.len();
        let response_b: Vec<[u8; 32]> = (0..n).map(|i| {
            let mut h = blake3::Hasher::new_keyed(&challenge);
            h.update(b"response-b");
            h.update(&(i as u64).to_be_bytes());
            *h.finalize().as_bytes()
        }).collect();

        let response_t: Vec<[u8; 32]> = (0..n).map(|i| {
            let mut h = blake3::Hasher::new_keyed(&challenge);
            h.update(b"response-t");
            h.update(&(i as u64).to_be_bytes());
            *h.finalize().as_bytes()
        }).collect();

        // Sign the proof
        let timestamp = unix_now();
        let mut proof = ShuffleProof {
            node_id: self.keypair.node_id,
            epoch,
            batch_size: n as u32,
            c_in_hash:  c_in.hash,
            c_out_hash: c_out.hash,
            challenge,
            response_b,
            response_t,
            timestamp,
            sig_ed25519: [0u8; 64],
        };

        let canonical = proof.canonical_bytes();
        let sig = self.keypair.sign_ed25519(&canonical);
        proof.sig_ed25519 = sig.to_bytes();

        Ok(proof)
    }
}

/// The output of a processed batch.
pub struct BatchOutput {
    pub batch_id: [u8; 32],
    pub c_in:     BatchCommitment,
    pub c_out:    BatchCommitment,
    pub packets:  Vec<SphinxPacket>,
    pub proof:    ShuffleProof,
    pub epoch:    u32,
}

// ── Helpers ───────────────────────────────────────────────────────────────

fn compute_fs_challenge(
    epoch:  u32,
    node:   &NodeId,
    c_in:   &[Commitment],
    c_out:  &[Commitment],
) -> [u8; 32] {
    let mut h = blake3::Hasher::new();
    h.update(b"phantom-shuffle-v1");
    h.update(&epoch.to_be_bytes());
    h.update(node.as_bytes());
    for c in c_in  { h.update(&c.0); }
    for c in c_out { h.update(&c.0); }
    *h.finalize().as_bytes()
}

fn constant_time_eq_32(a: &[u8; 32], b: &[u8; 32]) -> bool {
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) { diff |= x ^ y; }
    diff == 0
}

fn unix_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

/// Mix processing errors.
#[derive(Debug, Error)]
pub enum MixError {
    #[error("Proof batch size mismatch")]
    ProofBatchSizeMismatch,
    #[error("Proof Fiat-Shamir challenge mismatch")]
    ProofChallengeMismatch,
    #[error("Proof signature invalid")]
    ProofSignatureInvalid,
    #[error("Batch processing error: {0}")]
    Processing(String),
}
