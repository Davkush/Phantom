//! BLAKE3-based hash, KDF, and PRF utilities used throughout Phantom Protocol.

use blake3::{Hasher, OutputReader};

/// Domain-separated BLAKE3 hash.
///
/// `phantom_hash(domain, inputs...) = BLAKE3(domain || input_0 || input_1 || ...)`
pub fn phantom_hash(domain: &[u8], inputs: &[&[u8]]) -> [u8; 32] {
    let mut h = Hasher::new();
    h.update(domain);
    for input in inputs {
        h.update(input);
    }
    *h.finalize().as_bytes()
}

/// Key derivation function: derive a 32-byte sub-key from a master key and purpose.
///
/// `phantom_kdf(master, purpose) = BLAKE3_keyed(master, purpose)`
pub fn phantom_kdf(master: &[u8; 32], purpose: &[u8]) -> [u8; 32] {
    let mut h = Hasher::new_keyed(master);
    h.update(purpose);
    *h.finalize().as_bytes()
}

/// Pseudorandom function (PRF): generate `len` pseudorandom bytes from a key and data.
///
/// Uses BLAKE3's XOF (extendable output function) mode.
pub fn phantom_prf(key: &[u8; 32], data: &[u8], len: usize) -> Vec<u8> {
    let mut h = Hasher::new_keyed(key);
    h.update(data);
    let mut reader: OutputReader = h.finalize_xof();
    let mut out = vec![0u8; len];
    reader.fill(&mut out);
    out
}

/// Constant-time byte slice equality.
pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

/// Batch commitment key for DHT publication.
pub fn batch_commit_key(node_id: &[u8; 32], batch_id: u64, epoch: u32) -> [u8; 32] {
    phantom_hash(
        b"phantom-batch-commit-v1",
        &[node_id, &batch_id.to_be_bytes(), &epoch.to_be_bytes()],
    )
}

/// ZK proof key for DHT publication.
pub fn proof_key(c_in_hash: &[u8; 32], epoch: u32, node_id: &[u8; 32]) -> [u8; 32] {
    phantom_hash(
        b"phantom-proof-v1",
        &[c_in_hash, &epoch.to_be_bytes(), node_id],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_phantom_hash_domain_separation() {
        let a = phantom_hash(b"domain-a", &[b"data"]);
        let b = phantom_hash(b"domain-b", &[b"data"]);
        assert_ne!(a, b, "Different domains must produce different hashes");
    }

    #[test]
    fn test_phantom_kdf_purpose_separation() {
        let master = [0x42u8; 32];
        let k1 = phantom_kdf(&master, b"mac");
        let k2 = phantom_kdf(&master, b"payload");
        assert_ne!(k1, k2);
    }

    #[test]
    fn test_ct_eq() {
        assert!(ct_eq(b"hello", b"hello"));
        assert!(!ct_eq(b"hello", b"world"));
        assert!(!ct_eq(b"hi", b"hello"));
    }

    #[test]
    fn test_phantom_prf_length() {
        let key = [0u8; 32];
        let out = phantom_prf(&key, b"test", 1024);
        assert_eq!(out.len(), 1024);
    }
}
