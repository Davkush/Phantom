//! Node key material: identity keys (permanent) and session keys (per-epoch).

use blake3::Hasher;
use ed25519_dalek::{SigningKey as Ed25519SigningKey, VerifyingKey as Ed25519VerifyingKey};
use pqcrypto_dilithium::dilithium3::{self, PublicKey as DilPublicKey, SecretKey as DilSecretKey};
use pqcrypto_kyber::kyber1024::{self, PublicKey as KyberPublicKey, SecretKey as KyberSecretKey};
use pqcrypto_traits::sign::PublicKey as _;
use pqcrypto_traits::kem::PublicKey as KemPubTrait;
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use x25519_dalek::{PublicKey as X25519PublicKey, StaticSecret as X25519SecretKey};
use zeroize::{Zeroize, ZeroizeOnDrop};

use crate::{NodeId, PhantomError};

/// All public keys for a Phantom node.
/// These are sent in every [`NodeDescriptor`] and are used for identity
/// verification and key exchange.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodePublicKeys {
    /// Ed25519 signing key — permanent, defines node identity.
    pub ed25519: [u8; 32],
    /// Dilithium-3 signing key — permanent, post-quantum signing.
    pub dilithium: Vec<u8>, // 1952 bytes
    /// X25519 KEM key — rotates every epoch.
    pub x25519: [u8; 32],
    /// Kyber-1024 KEM key — rotates every epoch.
    pub kyber: Vec<u8>, // 1568 bytes
}

impl NodePublicKeys {
    /// Derive the [`NodeId`] from these public keys.
    ///
    /// `node_id = BLAKE3("phantom-node-v1" || pk_ed || pk_dil || pk_x25 || pk_kyber)`
    pub fn node_id(&self) -> NodeId {
        let mut h = Hasher::new();
        h.update(b"phantom-node-v1");
        h.update(&self.ed25519);
        h.update(&self.dilithium);
        h.update(&self.x25519);
        h.update(&self.kyber);
        *h.finalize().as_bytes()
    }

    /// Serialise to canonical bytes for signing.
    pub fn canonical_bytes(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(32 + 1952 + 32 + 1568);
        out.extend_from_slice(&self.ed25519);
        out.extend_from_slice(&self.dilithium);
        out.extend_from_slice(&self.x25519);
        out.extend_from_slice(&self.kyber);
        out
    }
}

/// Complete key material for a Phantom node, including all secret keys.
///
/// Secret key fields are zeroed on drop via [`ZeroizeOnDrop`].
#[derive(ZeroizeOnDrop)]
pub struct NodeKeypair {
    // ── Identity keys (permanent) ─────────────────────────────────────────
    /// Ed25519 signing secret key.
    #[zeroize(skip)] // ed25519_dalek handles its own zeroize
    pub sk_ed25519: Ed25519SigningKey,
    /// Dilithium-3 signing secret key.
    pub sk_dilithium_bytes: Vec<u8>,
    // ── Session keys (rotate per epoch) ───────────────────────────────────
    /// X25519 KEM secret key.
    pub sk_x25519: [u8; 32],
    /// Kyber-1024 KEM secret key.
    pub sk_kyber_bytes: Vec<u8>,
}

impl NodeKeypair {
    /// Generate a new node keypair.
    ///
    /// This performs the **static PoW puzzle** to ensure the Ed25519 public key
    /// has `C1_BITS` leading zero bits in its BLAKE3 hash — an admission
    /// requirement for Phantom-DPKI (Spec № 3 §4.1).
    pub fn generate(c1_bits: u32) -> Result<(Self, NodePublicKeys), PhantomError> {
        tracing::info!("Generating node keypair (static puzzle C1={c1_bits} bits)…");

        // ── Static puzzle: find Ed25519 keypair with C1 leading zero bits ──
        let (sk_ed, pk_ed_bytes) = loop {
            let sk = Ed25519SigningKey::generate(&mut OsRng);
            let pk_bytes = sk.verifying_key().to_bytes();
            let hash = blake3::hash(&pk_bytes);
            if leading_zero_bits(hash.as_bytes()) >= c1_bits {
                tracing::debug!("Static puzzle solved after iteration");
                break (sk, pk_bytes);
            }
        };

        // ── Dilithium-3 keypair ────────────────────────────────────────────
        let (pk_dil, sk_dil) = dilithium3::keypair();
        let pk_dil_bytes = pk_dil.as_bytes().to_vec();
        let sk_dil_bytes = sk_dil.as_bytes().to_vec();

        // ── X25519 session keypair ─────────────────────────────────────────
        let sk_x25 = X25519SecretKey::random_from_rng(OsRng);
        let pk_x25 = X25519PublicKey::from(&sk_x25);
        let sk_x25_bytes: [u8; 32] = sk_x25.to_bytes();
        let pk_x25_bytes = pk_x25.to_bytes();

        // ── Kyber-1024 session keypair ────────────────────────────────────
        let (pk_kyber, sk_kyber) = kyber1024::keypair();
        let pk_kyber_bytes = pk_kyber.as_bytes().to_vec();
        let sk_kyber_bytes = sk_kyber.as_bytes().to_vec();

        let public_keys = NodePublicKeys {
            ed25519:  pk_ed_bytes,
            dilithium: pk_dil_bytes,
            x25519:   pk_x25_bytes,
            kyber:    pk_kyber_bytes,
        };

        let keypair = NodeKeypair {
            sk_ed25519: sk_ed,
            sk_dilithium_bytes: sk_dil_bytes,
            sk_x25519: sk_x25_bytes,
            sk_kyber_bytes,
        };

        tracing::info!("Node keypair generated. node_id={}", hex::encode(public_keys.node_id()));
        Ok((keypair, public_keys))
    }

    /// Rotate session keys (X25519 + Kyber-1024) for a new epoch.
    /// Identity keys (Ed25519 + Dilithium-3) are unchanged.
    pub fn rotate_session_keys(&mut self, public_keys: &mut NodePublicKeys) {
        // New X25519
        let sk_x25 = X25519SecretKey::random_from_rng(OsRng);
        let pk_x25 = X25519PublicKey::from(&sk_x25);
        self.sk_x25519 = sk_x25.to_bytes();
        public_keys.x25519 = pk_x25.to_bytes();

        // New Kyber-1024
        let (pk_kyber, sk_kyber) = kyber1024::keypair();
        self.sk_kyber_bytes.zeroize();
        self.sk_kyber_bytes = sk_kyber.as_bytes().to_vec();
        public_keys.kyber = pk_kyber.as_bytes().to_vec();

        tracing::debug!("Session keys rotated for new epoch");
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

/// Count leading zero bits in a byte slice.
fn leading_zero_bits(bytes: &[u8]) -> u32 {
    let mut count = 0u32;
    for &b in bytes {
        if b == 0 {
            count += 8;
        } else {
            count += b.leading_zeros();
            break;
        }
    }
    count
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_node_id_deterministic() {
        let (_, pk) = NodeKeypair::generate(0).unwrap(); // c1=0: no puzzle for tests
        let id1 = pk.node_id();
        let id2 = pk.node_id();
        assert_eq!(id1, id2, "node_id must be deterministic");
    }

    #[test]
    fn test_session_key_rotation_preserves_identity() {
        let (mut kp, mut pk) = NodeKeypair::generate(0).unwrap();
        let id_before = pk.node_id();
        let x25_before = pk.x25519;

        kp.rotate_session_keys(&mut pk);

        // node_id changes because it includes x25519/kyber
        // but Ed25519 key is unchanged
        assert_eq!(pk.ed25519, kp.sk_ed25519.verifying_key().to_bytes());
        assert_ne!(pk.x25519, x25_before, "X25519 key should have rotated");
        let _ = id_before; // identity changes by design on rotation
    }

    #[test]
    fn test_leading_zero_bits() {
        assert_eq!(leading_zero_bits(&[0x00, 0x00, 0x80]), 9);
        assert_eq!(leading_zero_bits(&[0xFF]), 0);
        assert_eq!(leading_zero_bits(&[0x00]), 8);
    }
}
