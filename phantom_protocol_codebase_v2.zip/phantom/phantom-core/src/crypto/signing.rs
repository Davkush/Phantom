//! Hybrid signing: Ed25519 (classical) + Dilithium-3 (post-quantum).
//!
//! Both signatures are always required. A message is considered valid only if
//! both signatures verify. This provides security if either scheme is broken.

use blake3::Hasher;
use ed25519_dalek::{Signature as Ed25519Sig, Signer, SigningKey, Verifier, VerifyingKey};
use pqcrypto_dilithium::dilithium3::{
    self, PublicKey as DilPublicKey, SecretKey as DilSecretKey,
    SignedMessage,
};
use pqcrypto_traits::sign::{PublicKey as _, SignedMessage as _};
use serde::{Deserialize, Serialize};
use zeroize::ZeroizeOnDrop;

use crate::PhantomError;

/// Ed25519 signature (64 bytes).
pub type Ed25519Signature = [u8; 64];
/// Dilithium-3 signature (3293 bytes).
pub type DilithiumSignature = Vec<u8>;

/// A hybrid (Ed25519 + Dilithium-3) signature pair.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HybridSignature {
    pub ed25519: Ed25519Signature,
    pub dilithium: DilithiumSignature,
}

/// Signs messages with Ed25519 + Dilithium-3.
pub struct HybridSigner {
    sk_ed: SigningKey,
    sk_dil_bytes: Vec<u8>,
}

impl HybridSigner {
    /// Construct from raw secret key bytes.
    pub fn from_bytes(
        sk_ed_bytes: &[u8; 32],
        sk_dil_bytes: &[u8],
    ) -> Result<Self, PhantomError> {
        let sk_ed = SigningKey::from_bytes(sk_ed_bytes);
        Ok(Self {
            sk_ed,
            sk_dil_bytes: sk_dil_bytes.to_vec(),
        })
    }

    /// Sign `message` (BLAKE3 hash is taken internally).
    /// Returns both signatures.
    pub fn sign(&self, message: &[u8]) -> Result<HybridSignature, PhantomError> {
        // Hash message first so signatures are over fixed-size input
        let digest = blake3::hash(message);
        let digest_bytes = digest.as_bytes();

        // Ed25519 signature
        let ed_sig = self.sk_ed.sign(digest_bytes);
        let ed_bytes: [u8; 64] = ed_sig.to_bytes();

        // Dilithium-3 signature
        let sk_dil = DilSecretKey::from_bytes(&self.sk_dil_bytes)
            .map_err(|e| PhantomError::Crypto(format!("Dilithium seckey: {e:?}")))?;
        let signed = dilithium3::sign(digest_bytes, &sk_dil);
        // Extract just the signature bytes (signed message = sig || message)
        let sig_len = signed.as_bytes().len() - digest_bytes.len();
        let dil_sig = signed.as_bytes()[..sig_len].to_vec();

        Ok(HybridSignature {
            ed25519: ed_bytes,
            dilithium: dil_sig,
        })
    }
}

/// Verifies hybrid (Ed25519 + Dilithium-3) signatures.
pub struct HybridVerifier {
    pk_ed: VerifyingKey,
    pk_dil_bytes: Vec<u8>,
}

impl HybridVerifier {
    /// Construct from raw public key bytes.
    pub fn from_bytes(
        pk_ed_bytes: &[u8; 32],
        pk_dil_bytes: &[u8],
    ) -> Result<Self, PhantomError> {
        let pk_ed = VerifyingKey::from_bytes(pk_ed_bytes)
            .map_err(|e| PhantomError::Crypto(format!("Ed25519 pubkey: {e}")))?;
        Ok(Self {
            pk_ed,
            pk_dil_bytes: pk_dil_bytes.to_vec(),
        })
    }

    /// Verify `sig` over `message`. Returns `Ok(())` only if BOTH signatures are valid.
    pub fn verify(&self, message: &[u8], sig: &HybridSignature) -> Result<(), PhantomError> {
        let digest = blake3::hash(message);
        let digest_bytes = digest.as_bytes();

        // Verify Ed25519
        let ed_sig = Ed25519Sig::from_bytes(&sig.ed25519);
        self.pk_ed
            .verify(digest_bytes, &ed_sig)
            .map_err(|e| PhantomError::Crypto(format!("Ed25519 verify: {e}")))?;

        // Verify Dilithium-3
        let pk_dil = DilPublicKey::from_bytes(&self.pk_dil_bytes)
            .map_err(|e| PhantomError::Crypto(format!("Dilithium pubkey: {e:?}")))?;
        // Reconstruct signed message = sig || digest
        let mut signed_msg = sig.dilithium.clone();
        signed_msg.extend_from_slice(digest_bytes);
        let sm = SignedMessage::from_bytes(&signed_msg)
            .map_err(|e| PhantomError::Crypto(format!("Dilithium signed msg: {e:?}")))?;
        dilithium3::open(&sm, &pk_dil)
            .map_err(|e| PhantomError::Crypto(format!("Dilithium verify: {e:?}")))?;

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::crypto::keys::NodeKeypair;

    #[test]
    fn test_sign_and_verify() {
        let (kp, pk) = NodeKeypair::generate(0).unwrap();

        let signer = HybridSigner::from_bytes(
            &kp.sk_ed25519.to_bytes(),
            &kp.sk_dilithium_bytes,
        ).unwrap();

        let verifier = HybridVerifier::from_bytes(
            &pk.ed25519,
            &pk.dilithium,
        ).unwrap();

        let message = b"phantom protocol test message";
        let sig = signer.sign(message).unwrap();

        assert!(verifier.verify(message, &sig).is_ok(), "Valid signature should verify");
    }

    #[test]
    fn test_tampered_message_fails() {
        let (kp, pk) = NodeKeypair::generate(0).unwrap();

        let signer = HybridSigner::from_bytes(
            &kp.sk_ed25519.to_bytes(),
            &kp.sk_dilithium_bytes,
        ).unwrap();

        let verifier = HybridVerifier::from_bytes(
            &pk.ed25519,
            &pk.dilithium,
        ).unwrap();

        let sig = signer.sign(b"original message").unwrap();
        assert!(
            verifier.verify(b"tampered message", &sig).is_err(),
            "Tampered message should not verify"
        );
    }
}
