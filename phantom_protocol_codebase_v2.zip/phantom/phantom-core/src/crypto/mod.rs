//! Hybrid post-quantum cryptographic primitives.
//!
//! Combines X25519 (classical) with Kyber-1024 (post-quantum) for key
//! encapsulation, and Ed25519 + Dilithium-3 for signatures.
//! Security holds if either classical OR post-quantum primitive is secure.

use blake3::Hasher;
use rand::{RngCore, SeedableRng};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use zeroize::{Zeroize, ZeroizeOnDrop};

pub use x25519_dalek::{PublicKey as X25519PublicKey, StaticSecret as X25519SecretKey};
pub use ed25519_dalek::{SigningKey, VerifyingKey, Signature};

/// A 32-byte node identifier: BLAKE3(pk_ed || pk_dil || pk_x25 || pk_kyber).
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct NodeId(pub [u8; 32]);

impl NodeId {
    /// Derive node_id from public key material.
    pub fn derive(
        pk_ed:    &[u8; 32],
        pk_dil:   &[u8],
        pk_x25:   &[u8; 32],
        pk_kyber: &[u8],
    ) -> Self {
        let mut h = Hasher::new();
        h.update(b"phantom-node-v1");
        h.update(pk_ed);
        h.update(pk_dil);
        h.update(pk_x25);
        h.update(pk_kyber);
        let digest = h.finalize();
        NodeId(*digest.as_bytes())
    }

    /// Return bytes.
    pub fn as_bytes(&self) -> &[u8; 32] { &self.0 }
}

impl std::fmt::Display for NodeId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", hex::encode(self.0))
    }
}
impl std::fmt::Debug for NodeId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "NodeId({})", hex::encode(&self.0[..8]))
    }
}

/// A 32-byte shared secret derived from hybrid key exchange.
#[derive(Clone, Zeroize, ZeroizeOnDrop)]
pub struct SharedSecret(pub [u8; 32]);

impl SharedSecret {
    /// Derive MAC key.
    pub fn mac_key(&self) -> [u8; 32] {
        *blake3::derive_key("phantom-mac-v1", &self.0)
    }
    /// Derive payload encryption key.
    pub fn payload_key(&self) -> [u8; 32] {
        *blake3::derive_key("phantom-payload-v1", &self.0)
    }
    /// Derive routing decryption key.
    pub fn routing_key(&self) -> [u8; 32] {
        *blake3::derive_key("phantom-routing-v1", &self.0)
    }
    /// Derive hop blinding scalar.
    pub fn blind_scalar(&self) -> [u8; 32] {
        *blake3::derive_key("phantom-blind-v1", &self.0)
    }
}

/// Complete hybrid keypair: classical (X25519 + Ed25519) + PQ (Kyber-1024 + Dilithium-3).
#[derive(ZeroizeOnDrop)]
pub struct HybridKeypair {
    /// X25519 static secret for KEM.
    pub sk_x25519:    X25519SecretKey,
    /// Ed25519 signing key (permanent identity).
    pub sk_ed25519:   SigningKey,
    /// Kyber-1024 secret key bytes.
    #[zeroize(skip)]   // handled by pqcrypto
    pub sk_kyber:     pqcrypto_kyber::kyber1024::SecretKey,
    /// Dilithium-3 secret key bytes.
    #[zeroize(skip)]
    pub sk_dilithium: pqcrypto_dilithium::dilithium3::SecretKey,
    /// Derived node identity.
    pub node_id:      NodeId,
}

impl HybridKeypair {
    /// Generate a fresh keypair with random keys.
    /// NOTE: does NOT solve the static PoW puzzle — use `phantom-dpki` for full admission.
    pub fn generate() -> Self {
        use pqcrypto_traits::kem::PublicKey as KemPK;
        use pqcrypto_traits::sign::PublicKey as SigPK;

        let mut rng = OsRng;

        let sk_x25519  = X25519SecretKey::random_from_rng(&mut rng);
        let sk_ed25519 = SigningKey::generate(&mut rng);
        let (pk_kyber, sk_kyber) = pqcrypto_kyber::kyber1024::keypair();
        let (pk_dil,   sk_dil)   = pqcrypto_dilithium::dilithium3::keypair();

        let pk_x25 = X25519PublicKey::from(&sk_x25519);
        let pk_ed  = sk_ed25519.verifying_key();

        let node_id = NodeId::derive(
            pk_ed.as_bytes(),
            pk_dil.as_bytes(),
            pk_x25.as_bytes(),
            pk_kyber.as_bytes(),
        );

        HybridKeypair {
            sk_x25519:    sk_x25519,
            sk_ed25519:   sk_ed25519,
            sk_kyber:     sk_kyber,
            sk_dilithium: sk_dil,
            node_id,
        }
    }

    /// Return the X25519 public key.
    pub fn x25519_public(&self) -> X25519PublicKey {
        X25519PublicKey::from(&self.sk_x25519)
    }

    /// Return the Ed25519 verifying key.
    pub fn ed25519_public(&self) -> VerifyingKey {
        self.sk_ed25519.verifying_key()
    }

    /// Sign a message with Ed25519.
    pub fn sign_ed25519(&self, msg: &[u8]) -> Signature {
        use ed25519_dalek::Signer;
        self.sk_ed25519.sign(msg)
    }
}

/// Perform hybrid X25519 + Kyber-1024 key agreement.
/// Returns a 32-byte shared secret that is secure if EITHER primitive is unbroken.
pub fn hybrid_kem_encap(
    peer_x25519: &X25519PublicKey,
    peer_kyber:  &pqcrypto_kyber::kyber1024::PublicKey,
    epoch:       u32,
    node_id:     &NodeId,
) -> (SharedSecret, HybridCiphertext) {
    use pqcrypto_traits::kem::{Ciphertext, SharedSecret as KemSS};

    let mut rng = OsRng;

    // Classical: X25519 ephemeral DH
    let eph_sk = X25519SecretKey::random_from_rng(&mut rng);
    let eph_pk = X25519PublicKey::from(&eph_sk);
    let s_cl   = eph_sk.diffie_hellman(peer_x25519);

    // Post-quantum: Kyber-1024 encapsulation
    let (s_pq_bytes, ct_pq) = pqcrypto_kyber::kyber1024::encapsulate(peer_kyber);

    // Hybrid: combine both secrets via BLAKE3
    let mut h = Hasher::new();
    h.update(b"phantom-hop-v1");
    h.update(s_cl.as_bytes());
    h.update(s_pq_bytes.as_bytes());
    h.update(node_id.as_bytes());
    h.update(&epoch.to_be_bytes());
    let combined = h.finalize();

    let shared = SharedSecret(*combined.as_bytes());
    let ct = HybridCiphertext {
        eph_pk_x25519: *eph_pk.as_bytes(),
        ct_kyber:      ct_pq.as_bytes().try_into()
            .expect("Kyber-1024 ciphertext is 1568 bytes"),
    };

    (shared, ct)
}

/// Hybrid ciphertext: X25519 ephemeral public key + Kyber-1024 ciphertext.
#[derive(Clone, Serialize, Deserialize)]
pub struct HybridCiphertext {
    /// X25519 ephemeral public key (32 bytes).
    pub eph_pk_x25519: [u8; 32],
    /// Kyber-1024 ciphertext (1568 bytes).
    pub ct_kyber: Box<[u8; 1568]>,
}

/// Decapsulate a hybrid ciphertext to recover the shared secret.
pub fn hybrid_kem_decap(
    ct:      &HybridCiphertext,
    sk:      &HybridKeypair,
    epoch:   u32,
) -> Result<SharedSecret, CryptoError> {
    use pqcrypto_traits::kem::{Ciphertext as KemCT, SharedSecret as KemSS};

    // Classical: X25519
    let eph_pk = X25519PublicKey::from(ct.eph_pk_x25519);
    let s_cl   = sk.sk_x25519.diffie_hellman(&eph_pk);

    // Post-quantum: Kyber-1024 decapsulation
    let kyber_ct = pqcrypto_kyber::kyber1024::Ciphertext::from_bytes(ct.ct_kyber.as_ref())
        .map_err(|_| CryptoError::KyberDecapFailed)?;
    let s_pq = pqcrypto_kyber::kyber1024::decapsulate(&kyber_ct, &sk.sk_kyber);

    // Hybrid combination
    let mut h = Hasher::new();
    h.update(b"phantom-hop-v1");
    h.update(s_cl.as_bytes());
    h.update(s_pq.as_bytes());
    h.update(sk.node_id.as_bytes());
    h.update(&epoch.to_be_bytes());
    let combined = h.finalize();

    Ok(SharedSecret(*combined.as_bytes()))
}

/// Returns current network epoch: Unix time / EPOCH_DURATION_SECS.
pub fn current_epoch() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    (secs / crate::EPOCH_DURATION_SECS) as u32
}

/// Cryptographic errors.
#[derive(Debug, Error)]
pub enum CryptoError {
    /// Kyber decapsulation failed (wrong key or corrupted ciphertext).
    #[error("Kyber-1024 decapsulation failed")]
    KyberDecapFailed,
    /// MAC verification failed.
    #[error("MAC verification failed")]
    MacVerificationFailed,
    /// Signature verification failed.
    #[error("Signature verification failed")]
    SignatureVerificationFailed,
}
