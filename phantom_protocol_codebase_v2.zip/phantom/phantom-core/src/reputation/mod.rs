//! Node reputation and selection system.
//!
//! Tracks per-node reliability metrics and uses them for circuit path selection.
//! Reputation is local (each node maintains its own view) — no global authority.
//!
//! ## Metrics tracked
//! - `proof_success_rate`: fraction of batches with valid ZK shuffle proofs
//! - `uptime_score`:       exponentially weighted moving average of availability
//! - `latency_p50`:        median round-trip latency to this node
//! - `ejection_count`:     times this node has been ejected (lifetime)
//!
//! ## Selection algorithm
//! Weighted random selection (WRS) over eligible nodes.
//! Weight = proof_success_rate × uptime_score / (1 + ejection_count)
//! Guards additionally require: uptime_score > GUARD_UPTIME_THRESHOLD

use std::collections::HashMap;
use std::time::{Duration, Instant};
use serde::{Deserialize, Serialize};
use tracing::debug;

use crate::crypto::NodeId;

/// Minimum uptime score to be eligible as a Guard node (0-255).
pub const GUARD_UPTIME_THRESHOLD: u8 = 200;

/// Minimum proof success rate to be eligible as any relay (0.0-1.0).
pub const MIN_PROOF_SUCCESS_RATE: f32 = 0.90;

/// Exponential moving average alpha for uptime score updates.
pub const UPTIME_EMA_ALPHA: f32 = 0.1;

/// A node's reputation record.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NodeReputation {
    /// Node being tracked.
    pub node_id:            NodeId,
    /// Fraction of batches with valid proofs observed (0.0–1.0).
    pub proof_success_rate: f32,
    /// EWMA uptime score (0–255).
    pub uptime_score:       u8,
    /// Median round-trip latency in milliseconds.
    pub latency_p50_ms:     u32,
    /// Number of ejections observed for this node.
    pub ejection_count:     u32,
    /// When this record was last updated.
    #[serde(skip)]
    pub last_updated:       Option<Instant>,
    /// Number of proof observations.
    pub proof_observations: u32,
    /// Number of uptime pings.
    pub uptime_pings:       u32,
}

impl NodeReputation {
    /// Create a new reputation record for an unknown node (neutral defaults).
    pub fn new(node_id: NodeId) -> Self {
        NodeReputation {
            node_id,
            proof_success_rate: 0.5,   // neutral starting point
            uptime_score:       128,   // neutral
            latency_p50_ms:     500,   // assume 500ms until measured
            ejection_count:     0,
            last_updated:       Some(Instant::now()),
            proof_observations: 0,
            uptime_pings:       0,
        }
    }

    /// Record a proof observation (valid or invalid).
    pub fn record_proof(&mut self, valid: bool) {
        let alpha = 0.05f32; // slow adaptation for proofs
        let sample = if valid { 1.0f32 } else { 0.0f32 };
        self.proof_success_rate = (1.0 - alpha) * self.proof_success_rate + alpha * sample;
        self.proof_observations += 1;
        self.last_updated = Some(Instant::now());
    }

    /// Record an uptime ping result.
    pub fn record_uptime_ping(&mut self, reachable: bool) {
        let sample = if reachable { 255u8 } else { 0u8 };
        let alpha = UPTIME_EMA_ALPHA;
        let new_score = (1.0 - alpha) * self.uptime_score as f32 + alpha * sample as f32;
        self.uptime_score = new_score.round() as u8;
        self.uptime_pings += 1;
        self.last_updated = Some(Instant::now());
    }

    /// Record a latency measurement.
    pub fn record_latency(&mut self, latency_ms: u32) {
        // Running median approximation via EWMA
        let alpha = 0.2f32;
        self.latency_p50_ms = ((1.0 - alpha) * self.latency_p50_ms as f32
            + alpha * latency_ms as f32).round() as u32;
    }

    /// Record that this node was ejected.
    pub fn record_ejection(&mut self) {
        self.ejection_count += 1;
        self.proof_success_rate *= 0.5; // punish proof rate
        self.uptime_score = self.uptime_score.saturating_sub(50);
    }

    /// Compute the selection weight for this node.
    /// Higher weight = more likely to be selected for circuits.
    pub fn weight(&self) -> f32 {
        if self.is_banned() { return 0.0; }
        self.proof_success_rate
            * (self.uptime_score as f32 / 255.0)
            / (1.0 + self.ejection_count as f32)
    }

    /// Returns true if this node is effectively banned (too many ejections).
    pub fn is_banned(&self) -> bool {
        self.ejection_count >= 3 || self.proof_success_rate < MIN_PROOF_SUCCESS_RATE
    }

    /// Returns true if this node is eligible to be a Guard.
    pub fn is_guard_eligible(&self) -> bool {
        !self.is_banned() && self.uptime_score >= GUARD_UPTIME_THRESHOLD
    }
}

/// The reputation store: maintains records for all known nodes.
pub struct ReputationStore {
    records: HashMap<NodeId, NodeReputation>,
}

impl ReputationStore {
    pub fn new() -> Self {
        ReputationStore { records: HashMap::new() }
    }

    /// Get or create a reputation record.
    pub fn get_or_create(&mut self, node_id: NodeId) -> &mut NodeReputation {
        self.records.entry(node_id).or_insert_with(|| NodeReputation::new(node_id))
    }

    /// Record a proof observation for a node.
    pub fn record_proof(&mut self, node_id: NodeId, valid: bool) {
        self.get_or_create(node_id).record_proof(valid);
        debug!("Reputation: proof {} for {}", if valid { "valid" } else { "INVALID" }, node_id);
    }

    /// Record an ejection event.
    pub fn record_ejection(&mut self, node_id: NodeId) {
        self.get_or_create(node_id).record_ejection();
    }

    /// Select `n` guard-eligible nodes using weighted random selection.
    pub fn select_guards(&self, n: usize) -> Vec<NodeId> {
        self.select_weighted(n, |r| r.is_guard_eligible())
    }

    /// Select `n` relay-eligible nodes (middle/exit).
    pub fn select_relays(&self, n: usize, exclude: &[NodeId]) -> Vec<NodeId> {
        self.select_weighted(n, |r| !r.is_banned() && !exclude.contains(&r.node_id))
    }

    fn select_weighted<F: Fn(&NodeReputation) -> bool>(
        &self, n: usize, filter: F,
    ) -> Vec<NodeId> {
        use rand::distributions::WeightedIndex;
        use rand::prelude::*;

        let eligible: Vec<(&NodeId, f32)> = self.records.iter()
            .filter(|(_, r)| filter(r))
            .map(|(id, r)| (id, r.weight()))
            .filter(|(_, w)| *w > 0.0)
            .collect();

        if eligible.is_empty() { return vec![]; }

        let weights: Vec<f32> = eligible.iter().map(|(_, w)| *w).collect();
        let dist = match WeightedIndex::new(&weights) {
            Ok(d) => d,
            Err(_) => return eligible.iter().take(n).map(|(id, _)| **id).collect(),
        };

        let mut rng = thread_rng();
        let mut selected = Vec::with_capacity(n);
        let mut used = std::collections::HashSet::new();
        let mut attempts = 0;

        while selected.len() < n && attempts < eligible.len() * 3 {
            let idx = dist.sample(&mut rng);
            let id  = *eligible[idx].0;
            if used.insert(id) {
                selected.push(id);
            }
            attempts += 1;
        }
        selected
    }

    /// Get a node's current weight (for diagnostics).
    pub fn weight_of(&self, node_id: &NodeId) -> f32 {
        self.records.get(node_id).map(|r| r.weight()).unwrap_or(0.5)
    }

    pub fn total_nodes(&self) -> usize { self.records.len() }

    pub fn eligible_guards(&self) -> usize {
        self.records.values().filter(|r| r.is_guard_eligible()).count()
    }
}

impl Default for ReputationStore {
    fn default() -> Self { Self::new() }
}
