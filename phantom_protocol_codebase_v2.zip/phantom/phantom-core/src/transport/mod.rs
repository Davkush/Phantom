//! QUIC-based transport layer for Phantom Protocol.
//!
//! All inter-node communication uses QUIC over UDP port 443.
//! Traffic is obfuscated to resemble standard HTTPS/QUIC:
//! - Fixed packet sizes (padded to MTU)
//! - Constant inter-packet timing
//! - TLS 1.3 certificate that looks like a real web server cert
//!
//! ## Connection model
//! Each pair of nodes maintains a single persistent QUIC connection.
//! Sphinx⁺ packets are sent as individual QUIC datagrams (not streams),
//! preserving the fixed-size property even at the transport layer.

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio::sync::RwLock;
use thiserror::Error;
use tracing::{debug, info, warn};

use crate::sphinx::SphinxPacket;
use crate::crypto::NodeId;
use crate::PACKET_SIZE;

/// A handle to a live QUIC connection with a peer.
#[derive(Clone, Debug)]
pub struct PeerConnection {
    pub peer_id:   NodeId,
    pub peer_addr: SocketAddr,
    /// Channel to send outbound packets to this peer.
    pub tx:        mpsc::Sender<SphinxPacket>,
}

impl PeerConnection {
    /// Send a Sphinx⁺ packet to this peer.
    pub async fn send(&self, pkt: SphinxPacket) -> Result<(), TransportError> {
        self.tx.send(pkt).await
            .map_err(|_| TransportError::ConnectionClosed(self.peer_id))
    }
}

/// Outbound packet dispatcher: routes packets to the correct peer connection.
pub struct PacketDispatcher {
    connections: Arc<RwLock<HashMap<NodeId, PeerConnection>>>,
    /// Packets that couldn't be dispatched (peer not connected).
    dead_letter: mpsc::Sender<(NodeId, SphinxPacket)>,
}

impl PacketDispatcher {
    pub fn new(dead_letter: mpsc::Sender<(NodeId, SphinxPacket)>) -> Self {
        PacketDispatcher {
            connections: Arc::new(RwLock::new(HashMap::new())),
            dead_letter,
        }
    }

    /// Register a new peer connection.
    pub async fn add_connection(&self, conn: PeerConnection) {
        let mut conns = self.connections.write().await;
        info!("Transport: connected to peer {}", conn.peer_id);
        conns.insert(conn.peer_id, conn);
    }

    /// Remove a peer connection (called on disconnect).
    pub async fn remove_connection(&self, peer_id: &NodeId) {
        let mut conns = self.connections.write().await;
        if conns.remove(peer_id).is_some() {
            debug!("Transport: disconnected from peer {}", peer_id);
        }
    }

    /// Send a packet to a specific next-hop node.
    pub async fn dispatch(&self, next_hop: NodeId, pkt: SphinxPacket) -> Result<(), TransportError> {
        let conns = self.connections.read().await;
        if let Some(conn) = conns.get(&next_hop) {
            conn.send(pkt).await
        } else {
            drop(conns);
            warn!("No connection to next-hop {}, queuing for dead letter", next_hop);
            self.dead_letter.send((next_hop, pkt)).await
                .map_err(|_| TransportError::DispatchFailed(next_hop))
        }
    }

    /// Return the number of active connections.
    pub async fn connection_count(&self) -> usize {
        self.connections.read().await.len()
    }

    /// Return all currently connected peer IDs.
    pub async fn connected_peers(&self) -> Vec<NodeId> {
        self.connections.read().await.keys().cloned().collect()
    }
}

/// Inbound packet receiver: demultiplexes packets arriving on QUIC connections.
pub struct PacketReceiver {
    /// Inbound packet channel (populated by QUIC receive tasks).
    pub rx: mpsc::Receiver<(NodeId, SphinxPacket)>,
}

impl PacketReceiver {
    /// Receive the next inbound packet. Returns (source_peer_id, packet).
    pub async fn recv(&mut self) -> Option<(NodeId, SphinxPacket)> {
        self.rx.recv().await
    }
}

/// Simulated QUIC transport (used in tests and when quinn is unavailable).
/// Production: replace with quinn-based implementation.
pub struct SimulatedTransport {
    local_id:   NodeId,
    local_addr: SocketAddr,
    dispatcher: PacketDispatcher,
    inbound_tx: mpsc::Sender<(NodeId, SphinxPacket)>,
}

impl SimulatedTransport {
    /// Create a simulated transport pair for testing.
    /// Returns (transport_a, receiver_a, transport_b, receiver_b).
    pub fn create_pair(
        id_a: NodeId, addr_a: SocketAddr,
        id_b: NodeId, addr_b: SocketAddr,
    ) -> (Self, PacketReceiver, Self, PacketReceiver) {
        let (dead_a, _) = mpsc::channel(64);
        let (dead_b, _) = mpsc::channel(64);
        let (in_tx_a, in_rx_a) = mpsc::channel(256);
        let (in_tx_b, in_rx_b) = mpsc::channel(256);
        let (out_tx_a, _out_rx_a) = mpsc::channel(256);
        let (out_tx_b, _out_rx_b) = mpsc::channel(256);

        let conn_a_to_b = PeerConnection { peer_id: id_b, peer_addr: addr_b, tx: out_tx_a };
        let conn_b_to_a = PeerConnection { peer_id: id_a, peer_addr: addr_a, tx: out_tx_b };

        let disp_a = PacketDispatcher::new(dead_a);
        let disp_b = PacketDispatcher::new(dead_b);

        let transport_a = SimulatedTransport {
            local_id: id_a, local_addr: addr_a,
            dispatcher: disp_a, inbound_tx: in_tx_a,
        };
        let transport_b = SimulatedTransport {
            local_id: id_b, local_addr: addr_b,
            dispatcher: disp_b, inbound_tx: in_tx_b,
        };

        (transport_a, PacketReceiver { rx: in_rx_a },
         transport_b, PacketReceiver { rx: in_rx_b })
    }

    pub fn dispatcher(&self) -> &PacketDispatcher {
        &self.dispatcher
    }

    /// Inject a packet as if it arrived from a peer (for testing).
    pub async fn inject_inbound(&self, from: NodeId, pkt: SphinxPacket) {
        let _ = self.inbound_tx.send((from, pkt)).await;
    }

    pub fn local_id(&self) -> NodeId { self.local_id }
    pub fn local_addr(&self) -> SocketAddr { self.local_addr }
}

/// Obfuscation layer: pads packets to fixed MTU, shapes inter-packet timing.
pub struct TrafficObfuscator {
    /// Target inter-packet interval in microseconds.
    interval_us: u64,
}

impl TrafficObfuscator {
    pub fn new(interval_us: u64) -> Self {
        TrafficObfuscator { interval_us }
    }

    /// Pad a packet to exactly PACKET_SIZE bytes.
    /// (Sphinx⁺ packets are already fixed-size — this is a no-op in the
    /// normal case, provided as a safeguard.)
    pub fn pad(&self, data: &[u8]) -> [u8; PACKET_SIZE] {
        let mut out = [0u8; PACKET_SIZE];
        let n = data.len().min(PACKET_SIZE);
        out[..n].copy_from_slice(&data[..n]);
        out
    }

    /// Rate limit: sleep until next send slot.
    pub async fn rate_limit(&self) {
        tokio::time::sleep(
            std::time::Duration::from_micros(self.interval_us)
        ).await;
    }
}

/// Transport layer errors.
#[derive(Debug, Error)]
pub enum TransportError {
    #[error("Connection closed to peer {0}")]
    ConnectionClosed(NodeId),
    #[error("Dispatch failed: no route to {0}")]
    DispatchFailed(NodeId),
    #[error("QUIC error: {0}")]
    Quic(String),
    #[error("TLS error: {0}")]
    Tls(String),
    #[error("Packet too large: {0} bytes (max {})", PACKET_SIZE)]
    PacketTooLarge(usize),
}
