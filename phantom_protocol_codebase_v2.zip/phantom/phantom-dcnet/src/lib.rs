//! # phantom-dcnet
//!
//! DC-Net Extreme Mode for Phantom Protocol (Spec № 4).
//! Provides information-theoretic sender anonymity against a GPA.
//!
//! ## Components
//! - [`group`]       — group formation, lifecycle, coordinator rotation
//! - [`pad`]         — pairwise pad establishment and derivation  
//! - [`reservation`] — anonymous slot reservation protocol
//! - [`round`]       — data round execution and verifiable ciphertexts
//! - [`disruption`]  — disruption detection and ejection

#![forbid(unsafe_code)]
#![warn(missing_docs)]

pub mod group;
pub mod pad;
pub mod reservation;
pub mod round;
pub mod disruption;

pub use group::{DcNetGroup, GroupId, GroupSize};
pub use round::{DcNetCiphertext, RoundOutput};

/// Minimum group size for DC-Net operation (anonymity set floor).
pub const MIN_GROUP_SIZE: usize = 8;
/// Maximum group size (O(N²) pad complexity ceiling).
pub const MAX_GROUP_SIZE: usize = 128;
/// Target group size (best latency/anonymity balance).
pub const TARGET_GROUP_SIZE: usize = 32;
/// Group epoch duration in seconds.
pub const GROUP_EPOCH_SECS: u64 = 600; // 10 minutes
/// Pre-computed rounds per group epoch.
pub const PRECOMPUTED_ROUNDS: u32 = 100;
/// DC-Net message size in bytes.
pub const MESSAGE_SIZE: usize = 1024;
/// Round deadline in milliseconds.
pub const ROUND_DEADLINE_MS: u64 = 2000;
