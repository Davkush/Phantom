//! Pairwise pad store for DC-Net operation.
//!
//! Pad establishment: pairwise master secrets via X25519+Kyber (§4.1).
//! Pad derivation: BLAKE3 XOF per round (§4.2).
//! Pre-computation: W rounds computed at group epoch start (§4.3).

use std::collections::HashMap;
use zeroize::{Zeroize, ZeroizeOnDrop};
use thiserror::Error;

use phantom_core::crypto::NodeId;
use crate::{MESSAGE_SIZE, PRECOMPUTED_ROUNDS};

/// A single 1024-byte pad for one participant pair in one round.
#[derive(Clone, ZeroizeOnDrop)]
pub struct Pad(pub [u8; MESSAGE_SIZE]);

/// Pairwise master secret between two nodes.
#[derive(ZeroizeOnDrop)]
struct MasterSecret([u8; 32]);

/// The pad store: holds pre-computed pads for all peer pairs and rounds.
pub struct PadStore {
    local_id:       NodeId,
    /// master_secrets[peer_id] = 32-byte master secret
    master_secrets: HashMap<NodeId, MasterSecret>,
    /// pads[(peer_id, round)] = 1024-byte pad
    pads:           HashMap<(NodeId, u32), Pad>,
    group_epoch:    u32,
}

impl PadStore {
    /// Create a new empty pad store.
    pub fn new(local_id: NodeId) -> Self {
        PadStore {
            local_id,
            master_secrets: HashMap::new(),
            pads:           HashMap::new(),
            group_epoch:    0,
        }
    }

    /// Establish a master secret with a peer using a pre-shared secret.
    /// In production: derived from X25519+Kyber key agreement over Sphinx+ circuit.
    pub fn set_master_secret(&mut self, peer: NodeId, secret: [u8; 32]) {
        self.master_secrets.insert(peer, MasterSecret(secret));
    }

    /// Pre-compute pads for the next W rounds.
    /// Call this at the start of each group epoch.
    pub fn precompute(
        &mut self,
        peers:       &[NodeId],
        group_epoch: u32,
        start_round: u32,
        num_rounds:  u32,
    ) {
        self.group_epoch = group_epoch;
        for peer in peers {
            if let Some(ms) = self.master_secrets.get(peer) {
                for r in start_round..start_round + num_rounds {
                    let pad = derive_pad(&ms.0, group_epoch, r);
                    self.pads.insert((*peer, r), Pad(pad));
                }
            }
        }
    }

    /// Get the pad for a specific peer and round.
    pub fn get_pad(&self, peer: &NodeId, round: u32) -> Option<&Pad> {
        self.pads.get(&(*peer, round))
    }

    /// Compute the XOR sum of all pads for this node in a given round.
    /// This is what a non-sender broadcasts.
    pub fn compute_pad_sum(
        &self,
        peers:  &[NodeId],
        round:  u32,
        local:  &NodeId,
    ) -> Result<[u8; MESSAGE_SIZE], PadError> {
        let mut sum = [0u8; MESSAGE_SIZE];
        for peer in peers {
            if peer == local { continue; }
            let pad = self.get_pad(peer, round)
                .ok_or(PadError::PadNotFound { peer: *peer, round })?;
            // XOR with sign convention: node_id < peer_id → add, else subtract (XOR)
            for i in 0..MESSAGE_SIZE {
                sum[i] ^= pad.0[i];
            }
        }
        Ok(sum)
    }

    /// Zeroize all pads for rounds before the given round (forward secrecy).
    pub fn zeroize_before(&mut self, round: u32) {
        self.pads.retain(|(_, r), _| *r >= round);
    }
}

/// Derive a 1024-byte pad from master secret using BLAKE3 XOF.
fn derive_pad(master: &[u8; 32], group_epoch: u32, round: u32) -> [u8; MESSAGE_SIZE] {
    let mut out = [0u8; MESSAGE_SIZE];
    let mut h = blake3::Hasher::new_keyed(master);
    h.update(b"phantom-round-pad-v1");
    h.update(&group_epoch.to_be_bytes());
    h.update(&round.to_be_bytes());
    h.finalize_xof().fill(&mut out);
    out
}

#[derive(Debug, Error)]
pub enum PadError {
    #[error("Pad not found for peer {peer} round {round}")]
    PadNotFound { peer: NodeId, round: u32 },
    #[error("Master secret not established for peer {0}")]
    NoMasterSecret(NodeId),
}
