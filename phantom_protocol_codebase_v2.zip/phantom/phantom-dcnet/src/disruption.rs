//! Disruption detection and ejection (Spec № 4, §8).

use thiserror::Error;
use tracing::warn;

use phantom_core::crypto::NodeId;
use crate::round::{DcNetCiphertext, verify_ciphertext, RoundError};

/// Result of verifying a collection of ciphertexts.
pub struct VerificationResult {
    pub valid:     Vec<DcNetCiphertext>,
    pub disruptors: Vec<DisruptionEvent>,
}

/// Evidence of a disruption event.
#[derive(Clone, Debug)]
pub struct DisruptionEvent {
    pub offender:  NodeId,
    pub round:     u32,
    /// The invalid ciphertext itself (self-verifying evidence).
    pub evidence:  Vec<u8>,
    pub reason:    String,
}

/// Verify all ciphertexts in a round. Separate valid from invalid.
pub fn verify_all_ciphertexts(
    ciphertexts: Vec<DcNetCiphertext>,
    public_keys: &std::collections::HashMap<NodeId, ed25519_dalek::VerifyingKey>,
) -> VerificationResult {
    let mut valid     = Vec::new();
    let mut disruptors = Vec::new();

    for ct in ciphertexts {
        let pk = match public_keys.get(&ct.sender_id) {
            Some(pk) => pk,
            None => {
                warn!("No public key for participant {:?} — treating as disruption", ct.sender_id);
                disruptors.push(DisruptionEvent {
                    offender: ct.sender_id,
                    round:    ct.round,
                    evidence: postcard::to_allocvec(&ct).unwrap_or_default(),
                    reason:   "Unknown participant".into(),
                });
                continue;
            }
        };

        match verify_ciphertext(&ct, pk) {
            Ok(()) => valid.push(ct),
            Err(e) => {
                warn!("Disruption detected from {:?}: {}", ct.sender_id, e);
                disruptors.push(DisruptionEvent {
                    offender: ct.sender_id,
                    round:    ct.round,
                    evidence: postcard::to_allocvec(&ct).unwrap_or_default(),
                    reason:   e.to_string(),
                });
            }
        }
    }

    VerificationResult { valid, disruptors }
}

#[derive(Debug, Error)]
pub enum DisruptionError {
    #[error("Evidence serialisation failed")]
    EvidenceSerialise,
}
