//! Anonymous slot reservation protocol (Spec № 4, §5).
//!
//! Uses a nested DC-Net over {0,1} to anonymously claim a transmission slot.
//! An observer learns only COUNT (how many want to send), never WHO.

use thiserror::Error;
use tracing::{debug, info};

use phantom_core::crypto::NodeId;
use crate::pad::PadStore;

/// Outcome of a reservation phase.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReservationOutcome {
    /// Exactly one sender; this node has the slot if it reserved.
    Granted { round: u32 },
    /// Nobody wants to send; skip data phase.
    Empty,
    /// Multiple senders; collision resolution needed.
    Collision { count: usize },
    /// Exceeded max contention rounds; batch abandoned.
    Abandoned,
}

/// Maximum reservation rounds before abandoning.
pub const MAX_CONTENTION_ROUNDS: u32 = 32;

/// Run the reservation protocol for one data round.
///
/// `want_to_send`: whether this node wants to transmit in this round.
/// `peers_reserve_bits`: the reservation bits received from all peers this round.
/// Returns the outcome and the resolved sender count.
pub fn run_reservation_round(
    want_to_send:       bool,
    peers_reserve_bits: &[(NodeId, u8)], // (peer_id, their XOR-masked bit)
    pad_store:          &PadStore,
    peers:              &[NodeId],
    local_id:           &NodeId,
    round:              u32,
    group_epoch:        u32,
) -> Result<ReservationOutcome, ReservationError> {
    // Compute this node's reservation pad sum (1-bit version)
    let pad_sum = compute_1bit_pad_sum(pad_store, peers, local_id, round, group_epoch);

    // Our broadcast bit: (want_to_send as u8) XOR pad_sum
    let our_bit = (want_to_send as u8) ^ pad_sum;

    // XOR all bits together
    let mut xor_all = our_bit;
    for (_, bit) in peers_reserve_bits {
        xor_all ^= bit;
    }

    // xor_all is the COUNT (mod 2) — if 1, odd number of senders; if 0, even
    // For full count we need round structure, but basic protocol reveals parity
    // Full impl: use a larger field (Z_N) for exact count
    let count = xor_all as usize; // simplified: 0 or 1+

    debug!("Reservation round {}: count={}", round, count);

    match count {
        0 => Ok(ReservationOutcome::Empty),
        1 => Ok(ReservationOutcome::Granted { round }),
        n => Ok(ReservationOutcome::Collision { count: n }),
    }
}

/// Collision resolution: flip a coin to decide whether to retry.
/// Returns true if this node should retry in the next reservation slot.
pub fn should_retry_after_collision() -> bool {
    use rand::Rng;
    rand::thread_rng().gen_bool(0.5)
}

/// Compute the XOR of all 1-bit pads for reservation.
fn compute_1bit_pad_sum(
    pad_store:   &PadStore,
    peers:       &[NodeId],
    local_id:    &NodeId,
    round:       u32,
    group_epoch: u32,
) -> u8 {
    let mut sum = 0u8;
    for peer in peers {
        if peer == local_id { continue; }
        if let Some(pad) = pad_store.get_pad(peer, round) {
            // Use first bit of the pad (BLAKE3 output is uniform)
            sum ^= pad.0[0] & 0x01;
        }
    }
    sum
}

#[derive(Debug, Error)]
pub enum ReservationError {
    #[error("Pad not available for reservation round {0}")]
    PadUnavailable(u32),
}
