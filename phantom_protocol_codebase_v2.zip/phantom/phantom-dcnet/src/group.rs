//! DC-Net group lifecycle: formation, membership, coordinator rotation.

use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{info, warn};

use phantom_core::crypto::NodeId;
use crate::{MIN_GROUP_SIZE, MAX_GROUP_SIZE, GROUP_EPOCH_SECS};

/// A unique group identifier.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct GroupId(pub [u8; 32]);

/// Requested group size tier.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GroupSize {
    Small,   // 8-16
    Medium,  // 17-64
    Large,   // 65-128
}

impl GroupSize {
    pub fn target_n(self) -> usize {
        match self {
            GroupSize::Small  => 16,
            GroupSize::Medium => 32,
            GroupSize::Large  => 64,
        }
    }
}

/// State of a DC-Net group.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum GroupState {
    Forming,
    PadEstablishment,
    Active,
    Dissolving,
}

/// A DC-Net group.
pub struct DcNetGroup {
    pub id:         GroupId,
    pub members:    Vec<NodeId>,
    pub local_id:   NodeId,
    pub state:      GroupState,
    pub round:      u32,
    pub group_epoch: u32,
    pub formed_at:  u64,
}

impl DcNetGroup {
    /// Create a new group.
    pub fn new(id: GroupId, members: Vec<NodeId>, local_id: NodeId) -> Self {
        DcNetGroup {
            id,
            members,
            local_id,
            state:       GroupState::Forming,
            round:       0,
            group_epoch: 0,
            formed_at:   unix_now(),
        }
    }

    /// Derive the group ID from sorted member join tokens.
    pub fn compute_id(join_tokens: &[[u8; 32]]) -> GroupId {
        let mut sorted = join_tokens.to_vec();
        sorted.sort();
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-group-id-v1");
        for t in &sorted { h.update(t); }
        GroupId(*h.finalize().as_bytes())
    }

    /// Select round coordinator via deterministic VRF-like function.
    /// In production: use ECVRF (RFC 9381) for verifiable, unpredictable selection.
    pub fn coordinator_for_round(&self, round: u32) -> NodeId {
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-coordinator-v1");
        h.update(&self.id.0);
        h.update(&self.group_epoch.to_be_bytes());
        h.update(&round.to_be_bytes());
        let digest = h.finalize();
        // Select member by digest[0] % N
        let idx = (digest.as_bytes()[0] as usize) % self.members.len();
        self.members[idx]
    }

    /// Check if this node is the coordinator for the current round.
    pub fn is_coordinator(&self) -> bool {
        self.coordinator_for_round(self.round) == self.local_id
    }

    /// Remove a member (e.g. after disruption or absence).
    pub fn remove_member(&mut self, member: NodeId) {
        self.members.retain(|m| *m != member);
        if self.members.len() < MIN_GROUP_SIZE {
            warn!("Group {:?} fell below minimum size — dissolving", self.id);
            self.state = GroupState::Dissolving;
        }
    }

    /// Advance to the next round.
    pub fn advance_round(&mut self) {
        self.round += 1;
    }

    /// Check if group epoch has expired.
    pub fn epoch_expired(&self) -> bool {
        unix_now() - self.formed_at > GROUP_EPOCH_SECS
    }
}

fn unix_now() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs()
}

#[derive(Debug, Error)]
pub enum GroupError {
    #[error("Group too small: {0} < {}", MIN_GROUP_SIZE)]
    TooSmall(usize),
    #[error("Group too large: {0} > {}", MAX_GROUP_SIZE)]
    TooLarge(usize),
    #[error("Group dissolved")]
    Dissolved,
}
