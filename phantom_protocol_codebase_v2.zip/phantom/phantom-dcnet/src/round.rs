//! DC-Net data round: verifiable ciphertext construction and recovery.
//!
//! Implements §6 (verifiable ciphertexts over BLS12-381) and §7 (broadcast + recovery).

use ark_bls12_381::{G1Affine, G1Projective, Fr};
use ark_ec::{AffineRepr, CurveGroup};
use ark_ff::{Field, PrimeField, UniformRand};
use ark_serialize::{CanonicalSerialize, CanonicalDeserialize};
use rand::thread_rng;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::debug;

use phantom_core::crypto::NodeId;
use crate::pad::PadStore;
use crate::MESSAGE_SIZE;

/// A verifiable DC-Net ciphertext for one participant in one round.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DcNetCiphertext {
    /// Round number.
    pub round:     u32,
    /// Group ID.
    pub group_id:  [u8; 32],
    /// Broadcasting participant.
    pub sender_id: NodeId,
    /// BLS12-381 G1 broadcast value (48 bytes compressed).
    pub C:         Vec<u8>,  // serialised G1Affine
    /// ZK proof of correct formation.
    pub proof:     PadProof,
    /// Ed25519 signature over (round || group_id || C || proof).
    pub sig_ed25519: [u8; 64],
}

/// Schnorr ZK proof that ciphertext is correctly formed.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PadProof {
    /// Randomness commitment R = r_nonce * G.
    pub commitment_r: Vec<u8>,  // serialised G1Affine
    /// Fiat-Shamir challenge.
    pub challenge:    Vec<u8>,  // serialised Fr
    /// Schnorr response s = r_nonce + challenge * scalar.
    pub response:     Vec<u8>,  // serialised Fr
}

/// Generate a DC-Net ciphertext for a non-sender.
pub fn generate_nonsender_ciphertext(
    round:      u32,
    group_id:   &[u8; 32],
    pad_sum:    &[u8; MESSAGE_SIZE],
    local_id:   NodeId,
    signing_key: &ed25519_dalek::SigningKey,
) -> Result<DcNetCiphertext, RoundError> {
    let mut rng = thread_rng();

    // Encode pad_sum as BLS12-381 scalar
    let scalar = bytes_to_fr(pad_sum);

    // C = scalar * G
    let G = G1Affine::generator();
    let C_proj: G1Projective = G.mul_bigint(scalar.into_bigint());
    let C_affine = C_proj.into_affine();

    // ZK proof: prove knowledge of scalar (Schnorr)
    let proof = schnorr_prove(&C_affine, &scalar, round, group_id, &mut rng)?;

    let mut ct = DcNetCiphertext {
        round,
        group_id:    *group_id,
        sender_id:   local_id,
        C:           g1_to_bytes(&C_affine),
        proof,
        sig_ed25519: [0u8; 64],
    };

    // Sign
    let hash = ct.compute_hash();
    use ed25519_dalek::Signer;
    let sig = signing_key.sign(&hash);
    ct.sig_ed25519 = sig.to_bytes();

    Ok(ct)
}

/// Generate a DC-Net ciphertext for the sender with message M.
pub fn generate_sender_ciphertext(
    round:       u32,
    group_id:    &[u8; 32],
    message:     &[u8; MESSAGE_SIZE],
    pad_sum:     &[u8; MESSAGE_SIZE],
    local_id:    NodeId,
    signing_key: &ed25519_dalek::SigningKey,
) -> Result<DcNetCiphertext, RoundError> {
    let mut rng = thread_rng();

    // Encode message XOR pad_sum as scalar (unconditional anonymity)
    let mut combined = [0u8; MESSAGE_SIZE];
    for i in 0..MESSAGE_SIZE { combined[i] = message[i] ^ pad_sum[i]; }
    let scalar = bytes_to_fr(&combined);

    // C = scalar * G  (= (M_scalar + pad_sum_scalar) * G)
    let G = G1Affine::generator();
    let C_proj: G1Projective = G.mul_bigint(scalar.into_bigint());
    let C_affine = C_proj.into_affine();

    // Proof structure is IDENTICAL to non-sender — observer cannot distinguish
    let proof = schnorr_prove(&C_affine, &scalar, round, group_id, &mut rng)?;

    let mut ct = DcNetCiphertext {
        round,
        group_id:    *group_id,
        sender_id:   local_id,
        C:           g1_to_bytes(&C_affine),
        proof,
        sig_ed25519: [0u8; 64],
    };

    let hash = ct.compute_hash();
    use ed25519_dalek::Signer;
    let sig = signing_key.sign(&hash);
    ct.sig_ed25519 = sig.to_bytes();

    Ok(ct)
}

/// Verify a DC-Net ciphertext. Returns Ok if the proof is valid.
pub fn verify_ciphertext(
    ct:     &DcNetCiphertext,
    pk_ed:  &ed25519_dalek::VerifyingKey,
) -> Result<(), RoundError> {
    // 1. Verify Ed25519 signature
    use ed25519_dalek::Verifier;
    let hash = ct.compute_hash();
    let sig  = ed25519_dalek::Signature::from_bytes(&ct.sig_ed25519);
    pk_ed.verify(&hash, &sig)
        .map_err(|_| RoundError::SignatureInvalid)?;

    // 2. Deserialise C
    let C_affine = bytes_to_g1(&ct.C)
        .ok_or(RoundError::CiphertextMalformed)?;

    // 3. Verify Schnorr proof
    schnorr_verify(&C_affine, &ct.proof, ct.round, &ct.group_id)?;

    Ok(())
}

/// The output of a completed DC-Net data round.
#[derive(Clone, Debug)]
pub struct RoundOutput {
    pub round:      u32,
    pub message:    [u8; MESSAGE_SIZE],
    pub c_total:    Vec<u8>,  // serialised G1Affine
}

/// Recover the round message from a collection of verified ciphertexts.
pub fn recover_round_output(
    round:       u32,
    ciphertexts: &[DcNetCiphertext],
) -> Result<RoundOutput, RoundError> {
    if ciphertexts.is_empty() {
        return Err(RoundError::EmptyBatch);
    }

    // Sum all G1 elements: C_total = sum_k(C_k)
    let mut C_total = G1Projective::from(G1Affine::identity());
    for ct in ciphertexts {
        let c = bytes_to_g1(&ct.C).ok_or(RoundError::CiphertextMalformed)?;
        C_total += G1Projective::from(c);
    }
    let C_total_affine = C_total.into_affine();

    // Recover message from C_total = M_scalar * G
    // For the stub: extract from hash (real impl uses baby-step-giant-step)
    let message = recover_message_from_point(&C_total_affine);

    debug!("Round {} recovered: {} bytes", round, MESSAGE_SIZE);

    Ok(RoundOutput {
        round,
        message,
        c_total: g1_to_bytes(&C_total_affine),
    })
}

// ── Schnorr helpers ───────────────────────────────────────────────────────

fn schnorr_prove(
    C:        &G1Affine,
    scalar:   &Fr,
    round:    u32,
    group_id: &[u8; 32],
    rng:      &mut impl rand::RngCore,
) -> Result<PadProof, RoundError> {
    let G = G1Affine::generator();

    // r_nonce * G
    let r_nonce = Fr::rand(rng);
    let R_proj: G1Projective = G.mul_bigint(r_nonce.into_bigint());
    let R = R_proj.into_affine();

    // Fiat-Shamir challenge
    let x = fiat_shamir_challenge(&R, C, round, group_id);

    // Response: s = r_nonce + x * scalar
    let s = r_nonce + x * scalar;

    Ok(PadProof {
        commitment_r: g1_to_bytes(&R),
        challenge:    fr_to_bytes(&x),
        response:     fr_to_bytes(&s),
    })
}

fn schnorr_verify(
    C:        &G1Affine,
    proof:    &PadProof,
    round:    u32,
    group_id: &[u8; 32],
) -> Result<(), RoundError> {
    let G  = G1Affine::generator();
    let R  = bytes_to_g1(&proof.commitment_r).ok_or(RoundError::ProofMalformed)?;
    let x  = bytes_to_fr(&proof.challenge);
    let s  = bytes_to_fr(&proof.response);

    // Recompute challenge
    let x_check = fiat_shamir_challenge(&R, C, round, group_id);
    if x != x_check {
        return Err(RoundError::ProofChallengeMismatch);
    }

    // Verify: s*G == R + x*C
    let lhs: G1Projective = G.mul_bigint(s.into_bigint());
    let rhs: G1Projective = G1Projective::from(R) + G1Projective::from(*C).mul_bigint(x.into_bigint());

    if lhs.into_affine() != rhs.into_affine() {
        return Err(RoundError::ProofEquationFailed);
    }
    Ok(())
}

fn fiat_shamir_challenge(
    R:        &G1Affine,
    C:        &G1Affine,
    round:    u32,
    group_id: &[u8; 32],
) -> Fr {
    let mut h = blake3::Hasher::new();
    h.update(b"phantom-dcnet-proof-v1");
    h.update(&round.to_be_bytes());
    h.update(group_id);
    h.update(&g1_to_bytes(C));
    h.update(&g1_to_bytes(R));
    let digest = h.finalize();
    bytes_to_fr(digest.as_bytes())
}

// ── Serialisation helpers ─────────────────────────────────────────────────

fn g1_to_bytes(p: &G1Affine) -> Vec<u8> {
    let mut buf = Vec::new();
    p.serialize_compressed(&mut buf).unwrap_or_default();
    buf
}

fn bytes_to_g1(b: &[u8]) -> Option<G1Affine> {
    G1Affine::deserialize_compressed(b).ok()
}

fn fr_to_bytes(f: &Fr) -> Vec<u8> {
    let mut buf = Vec::new();
    f.serialize_compressed(&mut buf).unwrap_or_default();
    buf
}

fn bytes_to_fr(b: &[u8]) -> Fr {
    // Take up to 32 bytes, reduce mod q
    let mut arr = [0u8; 32];
    let copy_len = b.len().min(32);
    arr[..copy_len].copy_from_slice(&b[..copy_len]);
    Fr::from_le_bytes_mod_order(&arr)
}

fn bytes_to_fr_padded(b: &[u8; MESSAGE_SIZE]) -> Fr {
    // Use first 31 bytes (safe < q) for the scalar encoding
    bytes_to_fr(&b[..31])
}

fn recover_message_from_point(p: &G1Affine) -> [u8; MESSAGE_SIZE] {
    // Stub: in production, use baby-step-giant-step discrete log recovery
    // or hash-to-curve inversion table
    let bytes = g1_to_bytes(p);
    let mut msg = [0u8; MESSAGE_SIZE];
    let copy = bytes.len().min(MESSAGE_SIZE);
    msg[..copy].copy_from_slice(&bytes[..copy]);
    msg
}

impl DcNetCiphertext {
    fn compute_hash(&self) -> Vec<u8> {
        let mut h = blake3::Hasher::new();
        h.update(b"phantom-dcnet-ct-v1");
        h.update(&self.round.to_be_bytes());
        h.update(&self.group_id);
        h.update(self.sender_id.as_bytes());
        h.update(&self.C);
        // proof components
        h.update(&self.proof.commitment_r);
        h.update(&self.proof.challenge);
        h.update(&self.proof.response);
        h.finalize().as_bytes().to_vec()
    }
}

#[derive(Debug, Error)]
pub enum RoundError {
    #[error("Empty ciphertext batch")]
    EmptyBatch,
    #[error("Ciphertext signature invalid")]
    SignatureInvalid,
    #[error("Ciphertext malformed")]
    CiphertextMalformed,
    #[error("Proof malformed")]
    ProofMalformed,
    #[error("Proof Fiat-Shamir challenge mismatch — disruption detected")]
    ProofChallengeMismatch,
    #[error("Proof Schnorr equation failed — disruption detected")]
    ProofEquationFailed,
}
