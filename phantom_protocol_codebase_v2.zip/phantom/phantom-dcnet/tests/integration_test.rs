//! Integration tests for phantom-dcnet.

use phantom_core::crypto::NodeId;
use phantom_dcnet::pad::PadStore;
use phantom_dcnet::group::{DcNetGroup, GroupId, GroupSize};
use phantom_dcnet::round::{
    generate_nonsender_ciphertext,
    generate_sender_ciphertext,
    verify_ciphertext,
    recover_round_output,
};
use phantom_dcnet::{MESSAGE_SIZE, MIN_GROUP_SIZE, MAX_GROUP_SIZE};

fn make_node() -> (NodeId, ed25519_dalek::SigningKey) {
    use rand::RngCore;
    let kp = phantom_core::crypto::HybridKeypair::generate();
    let sk = ed25519_dalek::SigningKey::generate(&mut rand::thread_rng());
    (kp.node_id, sk)
}

#[test]
fn test_message_size_constant() {
    assert_eq!(MESSAGE_SIZE, 1024);
}

#[test]
fn test_group_size_bounds() {
    assert!(MIN_GROUP_SIZE >= 2);
    assert!(MAX_GROUP_SIZE <= 256);
    assert!(MIN_GROUP_SIZE < MAX_GROUP_SIZE);
}

#[test]
fn test_group_id_deterministic_from_tokens() {
    let tokens: Vec<[u8; 32]> = (0..4u8).map(|i| [i; 32]).collect();
    let id1 = DcNetGroup::compute_id(&tokens);
    let id2 = DcNetGroup::compute_id(&tokens);
    assert_eq!(id1, id2, "Group ID must be deterministic");
}

#[test]
fn test_group_id_different_for_different_tokens() {
    let t1: Vec<[u8; 32]> = vec![[1u8; 32], [2u8; 32]];
    let t2: Vec<[u8; 32]> = vec![[1u8; 32], [3u8; 32]];
    let id1 = DcNetGroup::compute_id(&t1);
    let id2 = DcNetGroup::compute_id(&t2);
    assert_ne!(id1, id2);
}

#[test]
fn test_group_coordinator_is_deterministic() {
    let (local, _) = make_node();
    let members: Vec<NodeId> = (0..4).map(|i| NodeId([i as u8; 32])).collect();
    let group = DcNetGroup::new(GroupId([0u8; 32]), members, local);

    let c1 = group.coordinator_for_round(1);
    let c2 = group.coordinator_for_round(1);
    assert_eq!(c1, c2, "Coordinator for same round must be deterministic");
}

#[test]
fn test_coordinator_rotates_across_rounds() {
    let (local, _) = make_node();
    let members: Vec<NodeId> = (0..8).map(|i| NodeId([i as u8; 32])).collect();
    let group = DcNetGroup::new(GroupId([7u8; 32]), members, local);

    // Coordinators for different rounds should not all be the same
    let coords: Vec<NodeId> = (0..8).map(|r| group.coordinator_for_round(r)).collect();
    let distinct: std::collections::HashSet<NodeId> = coords.iter().cloned().collect();
    // Should have at least 2 distinct coordinators across 8 rounds
    assert!(distinct.len() >= 2, "Coordinator must vary across rounds");
}

#[test]
fn test_pad_store_compute_pad_sum_empty_peers() {
    let local = NodeId([0u8; 32]);
    let store = PadStore::new(local);
    let sum = store.compute_pad_sum(&[], 0, &local);
    assert!(sum.is_ok());
    assert_eq!(sum.unwrap(), [0u8; MESSAGE_SIZE], "Empty peer set → zero pad sum");
}

#[test]
fn test_pad_derivation_is_deterministic() {
    let local = NodeId([0u8; 32]);
    let peer  = NodeId([1u8; 32]);
    let mut store1 = PadStore::new(local);
    let mut store2 = PadStore::new(local);

    let secret = [42u8; 32];
    store1.set_master_secret(peer, secret);
    store2.set_master_secret(peer, secret);

    store1.precompute(&[peer], 1, 0, 5);
    store2.precompute(&[peer], 1, 0, 5);

    let pad1 = store1.get_pad(&peer, 2).expect("pad should exist");
    let pad2 = store2.get_pad(&peer, 2).expect("pad should exist");
    assert_eq!(pad1.0, pad2.0, "Pad derivation must be deterministic");
}

#[test]
fn test_pad_derivation_different_rounds() {
    let local = NodeId([0u8; 32]);
    let peer  = NodeId([1u8; 32]);
    let mut store = PadStore::new(local);
    store.set_master_secret(peer, [11u8; 32]);
    store.precompute(&[peer], 1, 0, 10);

    let pad0 = store.get_pad(&peer, 0).unwrap();
    let pad1 = store.get_pad(&peer, 1).unwrap();
    assert_ne!(pad0.0, pad1.0, "Pads for different rounds must differ");
}

#[test]
fn test_nonsender_ciphertext_verifies() {
    use ed25519_dalek::SigningKey;
    let (local, sk) = make_node();
    let group_id = [9u8; 32];
    let pad_sum  = [3u8; MESSAGE_SIZE];

    let ct = generate_nonsender_ciphertext(0, &group_id, &pad_sum, local, &sk)
        .expect("non-sender ciphertext should be generated");

    let pk = sk.verifying_key();
    let result = verify_ciphertext(&ct, &pk);
    assert!(result.is_ok(), "Valid non-sender ciphertext must verify: {:?}", result.err());
}

#[test]
fn test_sender_ciphertext_verifies() {
    use ed25519_dalek::SigningKey;
    let (local, sk) = make_node();
    let group_id = [5u8; 32];
    let message  = [0xABu8; MESSAGE_SIZE];
    let pad_sum  = [0x12u8; MESSAGE_SIZE];

    let ct = generate_sender_ciphertext(0, &group_id, &message, &pad_sum, local, &sk)
        .expect("sender ciphertext should be generated");

    let pk = sk.verifying_key();
    let result = verify_ciphertext(&ct, &pk);
    assert!(result.is_ok(), "Valid sender ciphertext must verify: {:?}", result.err());
}

#[test]
fn test_sender_nonsender_ciphertexts_are_structurally_indistinguishable() {
    use ed25519_dalek::SigningKey;
    let (local, sk) = make_node();
    let group_id = [0u8; 32];
    let pad_sum  = [1u8; MESSAGE_SIZE];
    let message  = [2u8; MESSAGE_SIZE];

    let ct_nonsender = generate_nonsender_ciphertext(0, &group_id, &pad_sum, local, &sk).unwrap();
    let ct_sender    = generate_sender_ciphertext(0, &group_id, &message, &pad_sum, local, &sk).unwrap();

    // Both proofs have the same structure (commitment_r, challenge, response)
    assert_eq!(ct_nonsender.proof.commitment_r.len(), ct_sender.proof.commitment_r.len());
    assert_eq!(ct_nonsender.proof.challenge.len(),    ct_sender.proof.challenge.len());
    assert_eq!(ct_nonsender.proof.response.len(),     ct_sender.proof.response.len());
    assert_eq!(ct_nonsender.C.len(),                  ct_sender.C.len());

    // The VALUES differ (different message → different C) — information-theoretic anonymity
    // comes from the observer not knowing pad_sum, not from identical ciphertexts
    assert_ne!(ct_nonsender.C, ct_sender.C, "C values must differ for different inputs");
}

#[test]
fn test_tampered_ciphertext_fails_verification() {
    use ed25519_dalek::SigningKey;
    let (local, sk) = make_node();
    let group_id = [0u8; 32];
    let pad_sum  = [0u8; MESSAGE_SIZE];

    let mut ct = generate_nonsender_ciphertext(0, &group_id, &pad_sum, local, &sk).unwrap();

    // Tamper with the C value
    if !ct.C.is_empty() { ct.C[0] ^= 0xFF; }

    let pk     = sk.verifying_key();
    let result = verify_ciphertext(&ct, &pk);
    assert!(result.is_err(), "Tampered ciphertext must fail verification");
}

#[test]
fn test_dc_net_xor_cancellation_property() {
    // Mathematical core: XOR of all pad-sums cancels, revealing sender message.
    // This is the proof of DC-Net correctness (Spec №4, §2.2).
    
    const N: usize = 4; // small group for test
    let mut pads = [[0u8; 8]; N * N]; // pads[i][j] = pad between participant i and j
    
    // Generate random pairwise pads
    use rand::RngCore;
    let mut rng = rand::thread_rng();
    for i in 0..N {
        for j in (i+1)..N {
            let mut p = [0u8; 8];
            rng.fill_bytes(&mut p);
            pads[i * N + j] = p;
            pads[j * N + i] = p; // symmetric
        }
    }
    
    // Sender is participant 0, message = M
    let message = [0xDE, 0xAD, 0xBE, 0xEF, 0x01, 0x02, 0x03, 0x04u8];
    
    let mut broadcasts = [[0u8; 8]; N];
    
    // Non-senders: XOR their pads
    for k in 1..N {
        let mut broadcast = [0u8; 8];
        for j in 0..N {
            if j == k { continue; }
            for b in 0..8 { broadcast[b] ^= pads[k * N + j][b]; }
        }
        broadcasts[k] = broadcast;
    }
    
    // Sender (k=0): message XOR their pad sum
    let mut sender_broadcast = message;
    for j in 1..N {
        for b in 0..8 { sender_broadcast[b] ^= pads[0 * N + j][b]; }
    }
    broadcasts[0] = sender_broadcast;
    
    // Recover: XOR all broadcasts
    let mut recovered = [0u8; 8];
    for k in 0..N {
        for b in 0..8 { recovered[b] ^= broadcasts[k][b]; }
    }
    
    assert_eq!(recovered, message, 
        "DC-Net XOR cancellation must recover the original message.          This proves the information-theoretic anonymity property (Spec №4 §2.2).");
}
