# Phantom Protocol

**The first anonymous communication protocol that is simultaneously:**
- Post-quantum (CRYSTALS-Kyber + Dilithium, deployed from day 1)
- Verifiably mixing (ZK shuffle proofs — no trust in relay nodes)
- Fully trustless (no directory authorities, pure DHT-based PKI)
- P2P-native (every client is a routing node)
- GPA-resistant (DC-Net extreme mode for unconditional anonymity)
- Hidden-service capable (anonymous server hosting)

## Crates

| Crate | Description |
|---|---|
| `phantom-core` | Sphinx⁺ packet format, hybrid crypto, mix node, ZK shuffle, cover traffic |
| `phantom-dpki` | Trustless DHT-based PKI, node identity, Sybil resistance, gossip ejection |
| `phantom-dcnet` | DC-Net Extreme Mode — information-theoretic anonymity against GPA |
| `phantom-cli`   | Node daemon and CLI (`phantom node`, `phantom client`, `phantom keygen`) |

## Technical Specifications

- **Spec № 1** — Protocol Whitepaper
- **Spec № 2** — Sphinx⁺ Extended Packet Format & ZK Verifiable Shuffle
- **Spec № 3** — DHT-Based Trustless PKI
- **Spec № 4** — DC-Net Extreme Mode

## Quick Start

```bash
# Build the workspace
cargo build --release

# Generate a node identity
./target/release/phantom keygen

# Start a full mix node
./target/release/phantom node

# Start as a client-only node
./target/release/phantom client

# Enable debug logging
RUST_LOG=phantom=debug ./target/release/phantom node
```

## Architecture

```
phantom-cli
    ├── phantom-core   (Sphinx⁺, crypto, mix, cover)
    ├── phantom-dpki   (DHT, identity, puzzle, gossip)
    └── phantom-dcnet  (DC-Net, pads, rounds, disruption)
```

## Cryptographic Stack

| Function | Classical | Post-Quantum |
|---|---|---|
| Key Exchange | X25519 | CRYSTALS-Kyber-1024 (FIPS 203) |
| Signatures | Ed25519 | CRYSTALS-Dilithium-3 (FIPS 204) |
| Symmetric | ChaCha20-Poly1305 | — (already secure) |
| Hash | BLAKE3 | — (already secure) |
| ZK Proofs | Groth16 / BLS12-381 | STARK (roadmap) |

## Security Properties

- **Standard Mode**: computational anonymity, 200–800ms latency
- **Extreme Mode**: unconditional (information-theoretic) anonymity, 5–30s latency
- **GPA resistance**: DC-Net mode resists adversaries with unlimited compute
- **Post-quantum**: all key material safe against Shor's algorithm today
- **Verifiable mixing**: ZK proofs guarantee honest mixing, no trust in nodes
- **No directory authorities**: no legal attack surface at the PKI layer

## ⚠️ Status

This is a research prototype. Do NOT use for production anonymity without:
1. Independent cryptographic review of the Kyber fragment scheme (Spec №2 §3.4)
2. Full implementation of the Bayer-Groth shuffle argument (currently stubbed)
3. Real libp2p Kademlia integration (DHT currently in-memory)
4. Security audit of the DC-Net verifiable ciphertext construction

## License

MIT OR Apache-2.0
